<?php

namespace App\Http\Controllers;

use App\Services\SimuruClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CatalogController extends Controller
{
    public function index(Request $request, SimuruClient $api)
    {
        $markup = (float) setting('markup_percent', env('DEFAULT_MARKUP_PERCENT', 20));
        $services = [];
        $prices = [];
        $error = null;

        try {
            $services = $api->services();
            $prices = $api->pricelist();
        } catch (\Throwable $e) {
            Log::warning('Katalog SIMURU gagal dimuat.', [
                'exception' => get_class($e),
            ]);
            $error = 'Katalog belum dapat dimuat. Silakan muat ulang beberapa saat lagi.';
        }

        $serviceMap = [];
        foreach ($services as $service) {
            $id = (string) ($service['service_id'] ?? $service['id'] ?? $service['slug'] ?? '');
            if ($id === '') {
                continue;
            }

            $serviceMap[$id] = [
                'id' => $id,
                'name' => $service['service_name'] ?? $service['name'] ?? $service['slug'] ?? $id,
                'image' => $service['service_image'] ?? $service['image'] ?? null,
                'servers' => [],
            ];
        }

        foreach ($prices as $price) {
            $id = (string) ($price['service_id'] ?? $price['id'] ?? '');
            $base = (float) ($price['price'] ?? 0);
            $countryId = $price['country_id'] ?? null;

            if ($id === '' || $base <= 0 || $countryId === null) {
                continue;
            }

            if (!isset($serviceMap[$id])) {
                $serviceMap[$id] = [
                    'id' => $id,
                    'name' => $price['service_name'] ?? $id,
                    'image' => $price['service_image'] ?? null,
                    'servers' => [],
                ];
            }

            $serviceMap[$id]['servers'][] = [
                'country_id' => (string) $countryId,
                'country' => $price['country_name'] ?? $price['country'] ?? 'Negara tidak diketahui',
                'iso' => $price['country_iso'] ?? '',
                'base' => $base,
                'selling' => (int) ceil($base * (1 + $markup / 100)),
            ];
        }

        foreach ($serviceMap as &$service) {
            usort($service['servers'], fn ($a, $b) => $a['selling'] <=> $b['selling']);
        }
        unset($service);

        $catalog = array_values(array_filter(
            $serviceMap,
            fn ($service) => count($service['servers']) > 0
        ));

        // Filter katalog berdasarkan nama layanan, kode, atau negara/server.
        $q = trim((string) request()->query('q', ''));

        if ($q !== '') {
            $term = mb_strtolower($q);

            $catalog = array_values(array_filter($catalog, function ($service) use ($term) {
                $text = mb_strtolower(
                    ($service['name'] ?? '') . ' ' .
                    ($service['code'] ?? '') . ' ' .
                    ($service['slug'] ?? '')
                );

                if (str_contains($text, $term)) {
                    return true;
                }

                foreach (($service['servers'] ?? []) as $server) {
                    $serverText = mb_strtolower(
                        ($server['country'] ?? '') . ' ' .
                        ($server['iso'] ?? '') . ' ' .
                        ($server['country_id'] ?? '') . ' ' .
                        ($server['id'] ?? '')
                    );

                    if (str_contains($serverText, $term)) {
                        return true;
                    }
                }

                return false;
            }));
        }

        usort($catalog, fn ($a, $b) => strcasecmp($a['name'], $b['name']));

        // Pagination: kirim maksimal 20 layanan ke tampilan.
        $total = count($catalog);
        $perPage = 20;
        $lastPage = max(1, (int) ceil($total / $perPage));
        $currentPage = min(
            $lastPage,
            max(1, (int) request()->query('page', 1))
        );

        $pageItems = array_slice(
            $catalog,
            ($currentPage - 1) * $perPage,
            $perPage
        );

        $catalog = new \Illuminate\Pagination\LengthAwarePaginator(
            $pageItems,
            $total,
            $perPage,
            $currentPage,
            [
                'path' => request()->url(),
                'query' => request()->query(),
            ]
        );

        return view('catalog.index', [
            'catalog' => $catalog,
            'q' => $q ?? trim((string) request()->query('q', '')),
            'markup' => $markup,
            'error' => $error,
        ]);
    }
}
