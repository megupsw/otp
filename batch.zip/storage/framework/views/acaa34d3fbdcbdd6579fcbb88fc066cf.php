<?php $__env->startSection('title', 'Katalog Layanan OTP'); ?>
<?php $__env->startSection('crumb', 'KATALOG'); ?>
<?php $__env->startSection('heading', 'Katalog Layanan OTP'); ?>

<?php $__env->startSection('content'); ?>
<style>
.catalog-tools{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}
.catalog-tools input{flex:1;min-width:220px}
.catalog-summary{font-size:12px;color:var(--muted-color,#8d9bb5);margin-bottom:16px}
.catalog-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.catalog-card{min-width:0;padding:16px;border:1px solid var(--border-color,#263248);border-radius:14px;background:var(--card-bg,rgba(127,146,180,.035))}
.catalog-service-head{display:flex;align-items:center;gap:11px;margin-bottom:14px}
.catalog-logo{width:40px;height:40px;object-fit:contain;border-radius:9px}
.catalog-service-name{font-weight:700;overflow-wrap:anywhere}
.catalog-service-id{font-size:11px;color:var(--muted-color,#8d9bb5);overflow-wrap:anywhere}
.catalog-server{padding:12px 0;border-top:1px solid var(--border-color,rgba(127,146,180,.18))}
.catalog-server-top{display:flex;justify-content:space-between;gap:12px;align-items:start}
.catalog-server-name{font-size:13px;font-weight:600;overflow-wrap:anywhere}
.catalog-server-id{font-size:11px;color:var(--muted-color,#8d9bb5);margin-top:4px}
.catalog-price{text-align:right;white-space:nowrap;color:#6688ff;font-weight:700}
.catalog-base{font-size:11px;color:var(--muted-color,#8d9bb5);font-weight:400;margin-top:4px}
.catalog-empty{padding:24px;text-align:center}
@media(max-width:700px){.catalog-grid{grid-template-columns:minmax(0,1fr)}}
</style>

<div class="page-intro">
    <div>
        <h2>Semua layanan dan server</h2>
        
    </div>
    <a class="btn" href="<?php echo e(route('order')); ?>">Pesan OTP →</a>
</div>

<?php if($error): ?>
    <div class="alert error"><?php echo e($error); ?></div>
<?php endif; ?>

<div class="catalog-tools">
    <form method="GET" action="<?php echo e(url('/catalog')); ?>" class="catalog-search">
    <div class="catalog-search-box">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m16 16 4 4"></path></svg>
        <input type="search" name="q" value="<?php echo e(request('q')); ?>"
               placeholder="Cari layanan, aplikasi, atau negara..."
               aria-label="Cari layanan OTP">
        <?php if(request('q')): ?>
            <a class="catalog-reset" href="<?php echo e(url('/catalog')); ?>">Reset</a>
        <?php endif; ?>
    </div>
    <button type="submit" class="catalog-search-btn">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m16 16 4 4"></path></svg>
        <span>Cari layanan</span>
    </button>
</form>
<style>
.catalog-search{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:22px 0 18px}
.catalog-search-box{display:flex;align-items:center;gap:10px;flex:1;min-width:220px;max-width:560px;padding:0 14px;height:48px;border:1px solid #29364d;border-radius:13px;background:#0c1220;transition:border-color .2s,box-shadow .2s}
.catalog-search-box:focus-within{border-color:#5685ff;box-shadow:0 0 0 3px #5685ff22}
.catalog-search-box svg,.catalog-search-btn svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.8;flex-shrink:0}
.catalog-search-box svg{color:#7e9cff}
.catalog-search-box input{width:100%;min-width:0;background:transparent;border:0;outline:0;color:#f4f7ff;font-size:14px}
.catalog-search-box input::placeholder{color:#77849d}
.catalog-search-btn{height:48px;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:0 20px;border:1px solid #5685ff;border-radius:13px;background:linear-gradient(135deg,#477cff,#315be7);color:white;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 5px 16px #315be733;transition:transform .2s,filter .2s}
.catalog-search-btn:hover{filter:brightness(1.12);transform:translateY(-1px)}
.catalog-reset{color:#9db5ff;font-size:12px;text-decoration:none;white-space:nowrap}
.catalog-reset:hover{color:white}
@media(max-width:600px){.catalog-search{align-items:stretch}.catalog-search-box{max-width:none;flex-basis:100%}.catalog-search-btn{width:100%}}
</style>
</div>
<div class="catalog-summary">
    <span><?php echo e($catalog->total()); ?></span> layanan ditemukan · Menampilkan <?php echo e($catalog->count()); ?> layanan per halaman.
</div>

<div class="catalog-grid" id="catalogGrid">
    <?php $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="catalog-card" data-search="<?php echo e(strtolower($service['name'].' '.$service['id'].' '.implode(' ', array_map(fn($s) => $s['country'].' '.$s['iso'].' '.$s['country_id'], $service['servers'])))); ?>">
            <div class="catalog-service-head">
                <?php if(is_string($service['image']) && filter_var($service['image'], FILTER_VALIDATE_URL)): ?>
                    <img class="catalog-logo" src="<?php echo e($service['image']); ?>" alt="" loading="lazy">
                <?php endif; ?>
                <div>
                    <div class="catalog-service-name"><?php echo e($service['name']); ?></div>
                    <div class="catalog-service-id"><?php echo e($service['id']); ?> · <?php echo e(count($service['servers'])); ?> server</div>
                </div>
            </div>

            <?php $__currentLoopData = $service['servers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="catalog-server">
                    <div class="catalog-server-top">
                        <div>
                            <div class="catalog-server-name">
                                <?php echo e($server['country']); ?>

                                <?php if($server['iso']): ?> (<?php echo e($server['iso']); ?>) <?php endif; ?>
                            </div>
                            <div class="catalog-server-id">ID server: <?php echo e($server['country_id']); ?></div>
                        </div>
                        <div class="catalog-price">
                            <?php echo e(rupiah($server['selling'])); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php if($catalog->hasPages()): ?>
    <div class="catalog-pagination" style="display:flex;justify-content:center;align-items:center;gap:14px;flex-wrap:wrap;margin:24px 0">
        <?php if($catalog->onFirstPage()): ?>
            <span class="btn" style="opacity:.45">← Sebelumnya</span>
        <?php else: ?>
            <a class="btn" href="<?php echo e($catalog->previousPageUrl()); ?>">← Sebelumnya</a>
        <?php endif; ?>

        <span>Halaman <?php echo e($catalog->currentPage()); ?> dari <?php echo e($catalog->lastPage()); ?></span>

        <?php if($catalog->hasMorePages()): ?>
            <a class="btn" href="<?php echo e($catalog->nextPageUrl()); ?>">Berikutnya →</a>
        <?php else: ?>
            <span class="btn" style="opacity:.45">Berikutnya →</span>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="panel catalog-empty" id="catalogEmpty" hidden>
    Tidak ada layanan atau server yang cocok dengan pencarian.
</div>


<?php $__env->stopSection(); ?>


<style>
/* Pagination premium DEPUKA OTP */
.pagination, nav[role="navigation"] .pagination {
    display:flex;
    align-items:center;
    justify-content:center;
    flex-wrap:wrap;
    gap:8px;
    margin:28px 0 18px;
    padding:0;
}
.pagination .page-item {list-style:none;margin:0}
.pagination .page-link {
    display:flex;
    align-items:center;
    justify-content:center;
    min-width:40px;
    height:40px;
    padding:0 13px;
    border:1px solid #273650;
    border-radius:11px;
    background:#101827;
    color:#b9c8e6;
    font-size:13px;
    font-weight:600;
    text-decoration:none;
    transition:all .18s ease;
}
.pagination .page-link:hover {
    color:#fff;
    border-color:#5685ff;
    background:#1b2b49;
    transform:translateY(-1px);
}
.pagination .page-item.active .page-link,
.pagination .page-link[aria-current="page"] {
    color:#fff;
    border-color:#5685ff;
    background:linear-gradient(135deg,#5685ff,#315be7);
    box-shadow:0 4px 14px #315be744;
}
.pagination .page-item.disabled .page-link {
    color:#536078;
    border-color:#202a3b;
    background:#0b111c;
    cursor:not-allowed;
    transform:none;
}
.pagination svg {width:16px;height:16px}
nav[role="navigation"] p,
nav[role="navigation"] span,
nav[role="navigation"] a {font-size:13px}
@media(max-width:600px) {
    .pagination {gap:5px}
    .pagination .page-link {min-width:35px;height:36px;padding:0 9px;border-radius:9px}
}
</style>


<style>
/* Pagination DEPUKA OTP */
.catalog-pagination {
    display:flex;
    justify-content:center;
    align-items:center;
    flex-wrap:wrap;
    gap:12px;
    margin:32px 0 24px !important;
    padding:16px;
    border:1px solid #202c42;
    border-radius:16px;
    background:linear-gradient(145deg,#101725,#0b111c);
}
.catalog-pagination .btn {
    display:inline-flex !important;
    align-items:center;
    justify-content:center;
    gap:8px;
    min-width:138px;
    min-height:44px;
    padding:0 18px !important;
    border:1px solid #344766 !important;
    border-radius:12px !important;
    background:#172237 !important;
    color:#dce7ff !important;
    font-size:13px !important;
    font-weight:700 !important;
    text-decoration:none !important;
    box-shadow:0 3px 10px #00000020;
    transition:all .2s ease;
}
.catalog-pagination a.btn:hover {
    color:#fff !important;
    border-color:#5685ff !important;
    background:linear-gradient(135deg,#477cff,#315be7) !important;
    box-shadow:0 5px 18px #315be744;
    transform:translateY(-2px);
}
.catalog-pagination .btn:focus-visible {
    outline:2px solid #80a5ff;
    outline-offset:3px;
}
.catalog-pagination .btn[style*="opacity"] {
    color:#59677e !important;
    background:#0c1220 !important;
    border-color:#202a3b !important;
    box-shadow:none;
    cursor:not-allowed;
}
.catalog-pagination > span:not(.btn) {
    display:inline-flex;
    align-items:center;
    justify-content:center;
    min-height:42px;
    padding:0 18px;
    border:1px solid #304568;
    border-radius:12px;
    background:#111d32;
    color:#8fb0ff;
    font-size:13px;
    font-weight:700;
    letter-spacing:.2px;
}
@media(max-width:520px) {
    .catalog-pagination {gap:8px;padding:12px}
    .catalog-pagination .btn {min-width:0;flex:1;padding:0 10px !important}
    .catalog-pagination > span:not(.btn) {order:-1;flex-basis:100%}
}
</style>


<style id="catalog-pagination-theme-fix">
/* Light mode: pagination mengikuti tema terang */
.catalog-pagination {
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    box-shadow: 0 5px 20px rgba(15, 23, 42, .05);
}
.catalog-pagination .btn {
    color: #334155 !important;
    background: #f8fafc !important;
    border-color: #dbe3ef !important;
    box-shadow: none !important;
}
.catalog-pagination a.btn:hover {
    color: #ffffff !important;
    background: linear-gradient(135deg, #477cff, #315be7) !important;
    border-color: #477cff !important;
    box-shadow: 0 5px 15px rgba(49, 91, 231, .2) !important;
}
.catalog-pagination .btn[style*="opacity"] {
    color: #94a3b8 !important;
    background: #f1f5f9 !important;
    border-color: #e2e8f0 !important;
}
.catalog-pagination > span:not(.btn) {
    color: #315be7 !important;
    background: #eff6ff !important;
    border-color: #dbeafe !important;
}

/* Dark mode: aktifkan saat tema gelap menggunakan salah satu selector ini */
html.dark .catalog-pagination,
body.dark .catalog-pagination,
html.dark-mode .catalog-pagination,
body.dark-mode .catalog-pagination,
html[data-theme="dark"] .catalog-pagination,
body[data-theme="dark"] .catalog-pagination,
[data-bs-theme="dark"] .catalog-pagination {
    background: #0b111c !important;
    border-color: #202c42 !important;
}
html.dark .catalog-pagination .btn,
body.dark .catalog-pagination .btn,
html.dark-mode .catalog-pagination .btn,
body.dark-mode .catalog-pagination .btn,
html[data-theme="dark"] .catalog-pagination .btn,
body[data-theme="dark"] .catalog-pagination .btn,
[data-bs-theme="dark"] .catalog-pagination .btn {
    color: #dce7ff !important;
    background: #172237 !important;
    border-color: #344766 !important;
}
html.dark .catalog-pagination a.btn:hover,
body.dark .catalog-pagination a.btn:hover,
html.dark-mode .catalog-pagination a.btn:hover,
body.dark-mode .catalog-pagination a.btn:hover,
html[data-theme="dark"] .catalog-pagination a.btn:hover,
body[data-theme="dark"] .catalog-pagination a.btn:hover,
[data-bs-theme="dark"] .catalog-pagination a.btn:hover {
    color: #ffffff !important;
    background: linear-gradient(135deg, #477cff, #315be7) !important;
    border-color: #5685ff !important;
}
html.dark .catalog-pagination > span:not(.btn),
body.dark .catalog-pagination > span:not(.btn),
html.dark-mode .catalog-pagination > span:not(.btn),
body.dark-mode .catalog-pagination > span:not(.btn),
html[data-theme="dark"] .catalog-pagination > span:not(.btn),
body[data-theme="dark"] .catalog-pagination > span:not(.btn),
[data-bs-theme="dark"] .catalog-pagination > span:not(.btn) {
    color: #8fb0ff !important;
    background: #111d32 !important;
    border-color: #304568 !important;
}
</style>


<style id="catalog-search-theme-fix">
/* Light mode */
.catalog-search-box {
    background: #ffffff !important;
    border-color: #dbe3ef !important;
    box-shadow: 0 2px 8px rgba(15,23,42,.04);
}
.catalog-search-box:focus-within {
    border-color: #5685ff !important;
    box-shadow: 0 0 0 3px rgba(86,133,255,.15) !important;
}
.catalog-search-box input {
    background: transparent !important;
    color: #172033 !important;
    caret-color: #315be7;
}
.catalog-search-box input::placeholder {
    color: #94a3b8 !important;
    opacity: 1;
}
.catalog-search-box svg {
    color: #64748b !important;
}
.catalog-search-box .catalog-reset {
    color: #315be7 !important;
}

/* Dark mode */
html.dark .catalog-search-box,
body.dark .catalog-search-box,
html.dark-mode .catalog-search-box,
body.dark-mode .catalog-search-box,
html[data-theme="dark"] .catalog-search-box,
body[data-theme="dark"] .catalog-search-box,
[data-bs-theme="dark"] .catalog-search-box {
    background: #0c1220 !important;
    border-color: #29364d !important;
}
html.dark .catalog-search-box input,
body.dark .catalog-search-box input,
html.dark-mode .catalog-search-box input,
body.dark-mode .catalog-search-box input,
html[data-theme="dark"] .catalog-search-box input,
body[data-theme="dark"] .catalog-search-box input,
[data-bs-theme="dark"] .catalog-search-box input {
    color: #f4f7ff !important;
}
html.dark .catalog-search-box input::placeholder,
body.dark .catalog-search-box input::placeholder,
html.dark-mode .catalog-search-box input::placeholder,
body.dark-mode .catalog-search-box input::placeholder,
html[data-theme="dark"] .catalog-search-box input::placeholder,
body[data-theme="dark"] .catalog-search-box input::placeholder,
[data-bs-theme="dark"] .catalog-search-box input::placeholder {
    color: #77849d !important;
}
</style>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/catalog/index.blade.php ENDPATH**/ ?>