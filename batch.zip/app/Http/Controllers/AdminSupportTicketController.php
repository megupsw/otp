<?php

namespace App\Http\Controllers;

use App\Models\SupportTicket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class AdminSupportTicketController extends Controller
{
    public function index()
    {
        $tickets = SupportTicket::with('user')
            ->latest()
            ->paginate(20);

        return view('admin.support-tickets', compact('tickets'));
    }

    public function update(Request $request, SupportTicket $ticket)
    {
        $data = $request->validate([
            'status' => [
                'required',
                Rule::in(['baru', 'diproses', 'menunggu_pengguna', 'selesai']),
            ],
            'admin_reply' => ['nullable', 'string', 'max:5000'],
        ]);

        $ticket->update($data);

        return redirect()
            ->route('admin.support-tickets')
            ->with('success', 'Tiket berhasil diperbarui.');
    }

    public function attachment(SupportTicket $ticket)
    {
        abort_unless($ticket->attachment_path, 404);

        $disk = Storage::disk('local');
        abort_unless($disk->exists($ticket->attachment_path), 404);

        return $disk->response($ticket->attachment_path);
    }

}
