<?php
namespace App\Services;
use Illuminate\Support\Facades\Http;
use RuntimeException;
class MidtransSnap {
    public function create(string $orderId, int $amount, string $email, string $name): array {
        $key=config('services.midtrans.server_key');
        if (!$key) throw new RuntimeException('MIDTRANS_SERVER_KEY belum diatur.');
        $base=rtrim(config('services.midtrans.base_url'),'/');
        $response=Http::withBasicAuth($key,'')->acceptJson()->asJson()->timeout(15)->post($base.config('services.midtrans.snap_path'),[
            'transaction_details'=>['order_id'=>$orderId,'gross_amount'=>$amount],
            'customer_details'=>['first_name'=>$name,'email'=>$email],
            'payment_type'=>'qris',
            'enabled_payments'=>['qris'],
            'callbacks'=>['finish'=>url('/topup')],
        ]);
        if (!$response->successful()) throw new RuntimeException('Midtrans Snap gagal: '.$response->status());
        return $response->json();
    }
    public function validSignature(array $payload): bool {
        $key=config('services.midtrans.server_key');
        $expected=hash('sha512',($payload['order_id'] ?? '').($payload['status_code'] ?? '').($payload['gross_amount'] ?? '').$key);
        return $key && isset($payload['signature_key']) && hash_equals($expected,(string)$payload['signature_key']);
    }
}
