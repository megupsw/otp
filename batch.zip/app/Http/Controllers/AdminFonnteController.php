<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Services\WhatsAppGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class AdminFonnteController extends Controller
{
    public function index()
    {
        return view('admin.fonnte', [
            'phone' => Setting::where('key', 'fonnte_admin_phone')->value('value'),
            'configured' => filled(Setting::where('key', 'fonnte_token')->value('value')),
            'gateway' => Setting::where('key', 'whatsapp_gateway')->value('value') ?: 'fonnte',
            'openwaUrl' => Setting::where('key', 'openwa_base_url')->value('value'),
            'openwaSession' => Setting::where('key', 'openwa_session_id')->value('value'),
            'openwaConfigured' => filled(Setting::where('key', 'openwa_api_key')->value('value')),
        ]);
    }

    public function save(Request $request)
    {
        $data = $request->validate([
            'gateway' => ['required', 'in:fonnte,openwa'],
            'token' => ['nullable', 'string', 'max:500'],
            'phone' => ['required', 'regex:/^628[0-9]{7,13}$/'],
            'openwa_base_url' => ['nullable', 'url', 'max:500'],
            'openwa_api_key' => ['nullable', 'string', 'max:1000'],
            'openwa_session_id' => ['nullable', 'string', 'max:150'],
        ], [
            'phone.regex' => 'Nomor harus memakai format 628xxxxxxxxxx.',
            'openwa_base_url.url' => 'Base URL OpenWA harus berupa URL yang valid.',
        ]);

        $token = trim((string) ($data['token'] ?? ''));
        if ($token !== '') {
            Setting::updateOrCreate(
                ['key' => 'fonnte_token'],
                ['value' => encrypt($token)]
            );
        }

        Setting::updateOrCreate(
            ['key' => 'fonnte_admin_phone'],
            ['value' => $data['phone']]
        );

        $url = trim((string) ($data['openwa_base_url'] ?? ''));
        $key = trim((string) ($data['openwa_api_key'] ?? ''));
        $session = trim((string) ($data['openwa_session_id'] ?? ''));

        if ($url !== '') {
            Setting::updateOrCreate(['key' => 'openwa_base_url'], ['value' => rtrim($url, '/')]);
        }
        if ($key !== '') {
            Setting::updateOrCreate(['key' => 'openwa_api_key'], ['value' => encrypt($key)]);
        }
        if ($session !== '') {
            Setting::updateOrCreate(['key' => 'openwa_session_id'], ['value' => $session]);
        }

        if ($data['gateway'] === 'openwa') {
            $savedUrl = Setting::where('key', 'openwa_base_url')->value('value');
            $savedKey = Setting::where('key', 'openwa_api_key')->value('value');
            $savedSession = Setting::where('key', 'openwa_session_id')->value('value');

            if (!$savedUrl || !$savedKey || !$savedSession) {
                return back()->withInput()->withErrors([
                    'openwa' => 'Untuk mengaktifkan OpenWA, isi Base URL, API Key, dan Session ID terlebih dahulu.',
                ]);
            }
        }

        Setting::updateOrCreate(
            ['key' => 'whatsapp_gateway'],
            ['value' => $data['gateway']]
        );

        return redirect()->route('admin.fonnte')
            ->with('success', 'Pengaturan WhatsApp berhasil disimpan.');
    }

    public function test(Request $request, WhatsAppGateway $gateway)
    {
        $phone = Setting::where('key', 'fonnte_admin_phone')->value('value');

        if (!$phone) {
            return back()->withErrors(['fonnte' => 'Simpan nomor WhatsApp admin terlebih dahulu.']);
        }

        $active = $gateway->activeGateway();
        $ok = $gateway->send(
            $phone,
            "Tes WhatsApp DEPUKA OTP berhasil.\nGateway aktif: " . strtoupper($active) . "."
        );

        if ($ok) {
            return back()->with('success', 'API menerima pesan tes melalui ' . strtoupper($active) . '. Periksa WhatsApp admin.');
        }

        return back()->withErrors([
            'fonnte' => 'Pesan tes gagal dikonfirmasi. Periksa gateway, konfigurasi, status sesi OpenWA, dan log Laravel.',
        ]);
    }
}
