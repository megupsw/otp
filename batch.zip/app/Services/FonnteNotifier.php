<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class FonnteNotifier
{
    public function sendAdmin(string $message): void
    {
        try {
            $encryptedToken = Setting::where('key', 'fonnte_token')
                ->value('value');

            $phone = Setting::where('key', 'fonnte_admin_phone')
                ->value('value');

            if (!$encryptedToken || !$phone) {
                Log::warning('Fonnte belum dikonfigurasi melalui panel admin.');
                return;
            }

            $token = decrypt($encryptedToken);

            $response = Http::timeout(10)
                ->withHeaders(['Authorization' => $token])
                ->asForm()
                ->post('https://api.fonnte.com/send', [
                    'target' => $phone,
                    'message' => $message,
                ]);

            if (!$response->successful()) {
                Log::warning('Pengiriman Fonnte gagal.', [
                    'http_status' => $response->status(),
                ]);
            }
        } catch (\Throwable $e) {
            Log::warning('Kesalahan notifikasi Fonnte.', [
                'error' => $e->getMessage(),
            ]);
        }
    }
}
