@extends('layouts.app')
@section('title','Dashboard')@section('crumb','OVERVIEW')@section('heading','Dashboard')
@section('content')
<div class="welcome-banner"><div class="banner-copy"><span class="pill">● SISTEM ONLINE</span><h2>Halo, {{ auth()->user()->name }} 👋</h2><p>Kelola kebutuhan OTP kamu lebih cepat dan mudah.</p><a class="btn primary" href="{{ route('order') }}">Mulai Order <span>→</span></a></div><div class="banner-orb"><div class="orb-ring">✦</div></div></div>
<div class="stats-grid"><div class="stat-card"><span class="stat-icon blue">↗</span><span class="muted">Saldo tersedia</span><strong>{{ rupiah(auth()->user()->balance) }}</strong><a href="{{ route('topup') }}">Tambah saldo →</a></div><div class="stat-card"><span class="stat-icon purple">▣</span><span class="muted">Total order</span><strong>{{ $stats['orders'] }}</strong><small class="muted">Seluruh transaksi</small></div><div class="stat-card"><span class="stat-icon green">◉</span><span class="muted">OTP aktif</span><strong>{{ $stats['active'] }}</strong><a href="{{ route('otp') }}">Lihat OTP →</a></div><div class="stat-card"><span class="stat-icon orange">✓</span><span class="muted">Top up berhasil</span><strong>{{ $stats['topups'] }}</strong><small class="muted">Pembayaran terverifikasi</small></div></div>

@if(auth()->user()->role !== 'admin')
<style>
.dashboard-catalog-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:24px}
.dashboard-catalog-item{min-width:0;padding:15px;border:1px solid var(--line);border-radius:15px;background:var(--panel)}
.dashboard-catalog-item img{width:38px;height:38px;object-fit:contain;border-radius:9px;margin-bottom:10px}
.dashboard-catalog-item .catalog-name{font-weight:750;font-size:13px;overflow-wrap:anywhere;min-height:36px}
.dashboard-catalog-item .catalog-price{font-weight:850;font-size:16px;margin:8px 0;color:var(--blue)}
.dashboard-catalog-item small{display:block;color:var(--muted);font-size:11px;margin-bottom:10px}
@media(max-width:800px){.dashboard-catalog-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style>
<div class="section-head">
    <div><h2>Katalog layanan OTP</h2><p class="muted">Harga jual sudah termasuk markup yang ditetapkan admin.</p></div>
    <a class="text-link" href="{{ route('catalog') }}">Lihat semua →</a>
</div>
@if($dashboardCatalogError)
    <div class="panel" style="padding:16px;margin-bottom:20px">
        <p class="muted">Katalog sementara tidak tersedia. Silakan buka halaman order untuk mencoba kembali.</p>
        <a class="btn primary" href="{{ route('order') }}">Buka katalog order</a>
    </div>
@elseif(count($dashboardCatalog))
    <div class="dashboard-catalog-grid">
        @foreach($dashboardCatalog as $item)
            <div class="dashboard-catalog-item">
                @if(is_string($item['image'] ?? null) && filter_var($item['image'], FILTER_VALIDATE_URL))
                    <img src="{{ $item['image'] }}" alt="" loading="lazy">
                @else
                    <div style="font-size:25px;margin-bottom:10px">📱</div>
                @endif
                <div class="catalog-name">{{ $item['name'] }}</div>
                <div class="catalog-price">{{ rupiah($item['selling_price']) }}</div>
                <small>Harga termurah yang tersedia</small>
                <a class="btn secondary full" href="{{ route('order') }}">Pilih layanan →</a>
            </div>
        @endforeach
    </div>
@else
    <div class="panel" style="padding:16px;margin-bottom:20px">
        <p class="muted">Belum ada layanan dengan harga tersedia.</p>
        <a class="btn primary" href="{{ route('order') }}">Buka halaman order</a>
    </div>
@endif
@endif

@if(auth()->user()->role === 'admin' && $adminStats)
<style>
.admin-ops-grid {
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:14px;
    margin-bottom:24px;
}
.admin-ops-card {
    display:flex;
    flex-direction:column;
    gap:9px;
    min-width:0;
    padding:19px;
    border:1px solid var(--line);
    border-radius:16px;
    background:var(--panel);
    transition:transform .2s ease,border-color .2s ease;
}
.admin-ops-card:hover { transform:translateY(-3px);border-color:var(--blue); }
.admin-ops-icon {
    display:flex;align-items:center;justify-content:center;
    flex:0 0 40px;width:40px;height:40px;border-radius:12px;
    background:rgba(79,109,245,.18);
    color:#7793ff;font-size:21px;line-height:1;
}
.admin-ops-icon i {
    display:inline-block;font-size:21px;line-height:1;
    font-style:normal;visibility:visible;opacity:1;
}
.admin-ops-icon.green { color:#16b889;background:rgba(22,184,137,.13); }
.admin-ops-icon.orange { color:#f59e0b;background:rgba(245,158,11,.13); }
.admin-ops-icon.purple { color:#a78bfa;background:rgba(167,139,250,.14); }
.admin-ops-label { color:var(--muted);font-size:12px; }
.admin-ops-value { font-size:clamp(19px,2vw,25px);font-weight:850;letter-spacing:-.5px;overflow-wrap:anywhere; }
.admin-ops-note { color:var(--muted);font-size:11px;line-height:1.5; }
.admin-ops-links {
    display:grid;grid-template-columns:repeat(3,minmax(0,1fr));
    gap:12px;margin-bottom:25px;
}
.admin-ops-link {
    display:flex;align-items:center;gap:12px;
    padding:15px;border:1px solid var(--line);
    border-radius:14px;background:var(--panel);
    transition:border-color .2s ease,transform .2s ease;
}
.admin-ops-link:hover { border-color:var(--blue);transform:translateY(-2px); }
.admin-ops-link i { color:var(--blue);font-size:20px; }
.admin-ops-link b { display:block;font-size:12px; }
.admin-ops-link small { display:block;margin-top:4px;color:var(--muted);font-size:11px; }
@media(max-width:1000px) {
    .admin-ops-grid { grid-template-columns:repeat(2,minmax(0,1fr)); }
}
@media(max-width:560px) {
    .admin-ops-grid { gap:9px; }
    .admin-ops-card { padding:13px; }
    .admin-ops-value { font-size:19px; }
    .admin-ops-links { grid-template-columns:1fr;gap:9px; }
}
</style>

<div class="section-head">
    <div>
        <h2>Ringkasan Operasional</h2>
        <p class="muted">Statistik sistem dan aktivitas keuangan Depuka OTP</p>
    </div>
</div>

<div class="admin-ops-grid">
    <div class="admin-ops-card">
        <span class="admin-ops-icon"><i class="bi bi-people"></i></span>
        <span class="admin-ops-label">Total pengguna</span>
        <strong class="admin-ops-value">{{ number_format($adminStats['users'], 0, ',', '.') }}</strong>
        <span class="admin-ops-note">Seluruh akun terdaftar</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon green"><i class="bi bi-wallet2"></i></span>
        <span class="admin-ops-label">Total saldo pengguna</span>
        <strong class="admin-ops-value">{{ rupiah($adminStats['balance']) }}</strong>
        <span class="admin-ops-note">Akumulasi saldo seluruh akun</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon purple"><i class="bi bi-phone"></i></span>
        <span class="admin-ops-label">Order OTP aktif</span>
        <strong class="admin-ops-value">{{ number_format($adminStats['activeOrders'], 0, ',', '.') }}</strong>
        <span class="admin-ops-note">Dari {{ number_format($adminStats['orders'], 0, ',', '.') }} order keseluruhan</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon orange"><i class="bi bi-hourglass-split"></i></span>
        <span class="admin-ops-label">Pengajuan top up</span>
        <strong class="admin-ops-value">{{ number_format($adminStats['pendingTopups'], 0, ',', '.') }}</strong>
        <span class="admin-ops-note">{{ rupiah($adminStats['pendingAmount']) }} menunggu pemeriksaan</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon green"><i class="bi bi-check-circle"></i></span>
        <span class="admin-ops-label">Top up berhasil</span>
        <strong class="admin-ops-value">{{ number_format($adminStats['paidTopups'], 0, ',', '.') }}</strong>
        <span class="admin-ops-note">{{ rupiah($adminStats['paidAmount']) }} telah disetujui</span>
    </div>
</div>

<div class="section-head">
    <div>
        <h2>Akses administrasi</h2>
        <p class="muted">Pintasan untuk mengelola aktivitas sistem</p>
    </div>
</div>

<div class="admin-ops-links">
    <a class="admin-ops-link" href="{{ route('admin.users') }}">
        <i class="bi bi-people"></i>
        <span><b>Kelola pengguna</b><small>Lihat akun dan saldo pengguna</small></span>
    </a>
    <a class="admin-ops-link" href="{{ route('admin.topups') }}">
        <i class="bi bi-wallet"></i>
        <span><b>Pengajuan top up</b><small>Periksa dan verifikasi pembayaran</small></span>
    </a>
    <a class="admin-ops-link" href="{{ route('admin.orders') }}">
        <i class="bi bi-receipt"></i>
        <span><b>Riwayat order</b><small>Pantau pesanan seluruh pengguna</small></span>
    </a>
</div>
@else
<div class="section-head">
    <div><h2>Akses cepat</h2><p class="muted">Fitur utama Depuka OTP</p></div>
</div>
<div class="quick-grid">
    <a class="quick-card" href="{{ route('order') }}"><span class="quick-icon">＋</span><b>Order nomor</b><small>Pilih layanan dan negara</small><span class="arrow">↗</span></a>
    <a class="quick-card" href="{{ route('otp') }}"><span class="quick-icon violet">▣</span><b>Pesan OTP</b><small>Pantau SMS dan sisa waktu</small><span class="arrow">↗</span></a>
    <a class="quick-card" href="{{ route('topup') }}"><span class="quick-icon mint">◈</span><b>Top up saldo</b><small>Bayar cepat melalui QRIS</small><span class="arrow">↗</span></a>
</div>
@endif
<div class="section-head"><div><h2>Order terbaru</h2><p class="muted">Aktivitas pesanan terakhir</p></div><a class="text-link" href="{{ route('history') }}">Lihat semua →</a></div><div class="panel table-wrap"><table><thead><tr><th>Layanan</th><th>Nomor</th><th>Harga</th><th>Status</th><th></th></tr></thead><tbody>@forelse($recentOrders as $o)<tr><td><b>{{ $o->service_name }}</b><small>{{ $o->country_name }}</small></td><td>{{ $o->phone_number ?? 'Menunggu nomor' }}</td><td>{{ rupiah($o->selling_price) }}</td><td><span class="status {{ $o->status }}">{{ $o->status }}</span></td><td><a class="text-link" href="{{ route('otp') }}">Detail</a></td></tr>@empty<tr><td colspan="5" class="empty">Belum ada order. Mulai order pertamamu.</td></tr>@endforelse</tbody></table></div>
@endsection
