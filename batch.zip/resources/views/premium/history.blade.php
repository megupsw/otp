@extends('layouts.app')

@section('content')
<div class="premium-page">
    <div class="premium-heading">
        <div>
            <h1>Riwayat App Premium</h1>
            <p>Pantau status pesanan aplikasi premium kamu.</p>
        </div>
        <a href="{{ route('premium.index') }}">Kembali ke katalog</a>
    </div>

    @if(session('success'))
        <div class="premium-notice">{{ session('success') }}</div>
    @endif
    @if(session('warning'))
        <div class="premium-notice">{{ session('warning') }}</div>
    @endif

    @forelse($orders as $order)
        <article class="premium-card" style="margin-bottom:12px">
            <h3>{{ $order->app_name }} — {{ $order->package_name }}</h3>
            <p>Order: #{{ $order->id }}</p>
            <p>Harga: Rp {{ number_format($order->price, 0, ',', '.') }}</p>
            <p>Status: <strong>{{ strtoupper($order->status) }}</strong></p>
            @if($order->email)
                <p>Email tujuan: {{ $order->email }}</p>
            @endif
            @if($order->status === 'completed' && $order->account_details)
                <p>Detail akun:</p>
                <pre style="white-space:pre-wrap;overflow-wrap:anywhere">{{ $order->account_details }}</pre>
            @endif
            <p class="premium-meta">{{ $order->created_at->format('d/m/Y H:i') }}</p>
        </article>
    @empty
        <div class="premium-empty">Belum ada pesanan App Premium.</div>
    @endforelse

    {{ $orders->links() }}
</div>
@endsection
