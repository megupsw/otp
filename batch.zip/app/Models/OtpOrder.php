<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class OtpOrder extends Model {
    protected $fillable=['user_id','provider_order_id','external_provider_order_id','service_id','service_name','country_id','country_name','operator','phone_number','provider_price','selling_price','status','sms_code','sms_data','remaining_seconds','provider_payload','whatsapp_notified_code'];
    protected function casts(): array { return ['provider_price'=>'integer','selling_price'=>'integer','remaining_seconds'=>'integer','sms_data'=>'array','provider_payload'=>'array']; }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
