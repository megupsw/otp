<?php $__env->startSection('title', 'Tiket Bantuan'); ?>
<?php $__env->startSection('crumb', 'ADMIN / CUSTOMER SUPPORT'); ?>
<?php $__env->startSection('heading', 'Pusat Bantuan CS'); ?>

<?php $__env->startSection('content'); ?>
<style>
.admin-support{max-width:1250px;margin:0 auto;color:var(--text)}
.as-hero{padding:25px;border-radius:19px;background:linear-gradient(115deg,#202f69,#4058d8 62%,#7049d8);color:#fff;margin-bottom:22px;position:relative;overflow:hidden}
.as-hero:after{content:"";position:absolute;width:220px;height:220px;border:1px solid #ffffff30;border-radius:50%;right:-55px;top:-115px;box-shadow:0 0 0 28px #ffffff0b,0 0 0 58px #ffffff08;pointer-events:none}
.as-kicker{font-size:10px;letter-spacing:2px;font-weight:800;color:#cdd8ff}
.as-hero h2{font-size:clamp(22px,3vw,30px);margin:10px 0 7px;color:#fff}
.as-hero p{margin:0;color:#e0e7ff;font-size:13px;line-height:1.7}
.as-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:13px;margin-bottom:22px}
.as-stat{background:var(--panel);border:1px solid var(--line);border-radius:15px;padding:17px;min-width:0}
.as-stat-top{display:flex;align-items:center;justify-content:space-between;gap:8px;color:var(--muted);font-size:12px}
.as-stat-icon{width:35px;height:35px;display:grid;place-items:center;border-radius:11px;background:#5873ff1c;color:#8195ff;font-size:17px}
.as-stat strong{display:block;font-size:27px;line-height:1.2;margin-top:12px;font-variant-numeric:tabular-nums}
.as-stat small{display:block;color:var(--muted);font-size:11px;margin-top:5px}
.as-list-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:15px}
.as-list-head h2{font-size:19px;margin:0 0 5px}
.as-muted{color:var(--muted);font-size:12px;line-height:1.65}
.as-ticket{background:var(--panel);border:1px solid var(--line);border-radius:17px;margin-bottom:15px;overflow:hidden;box-shadow:0 6px 24px #00000008}
.as-ticket-head{padding:17px 20px;display:flex;justify-content:space-between;align-items:flex-start;gap:12px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.as-ticket-id{font-size:10px;letter-spacing:.7px;color:var(--muted);font-weight:800;margin-bottom:5px}
.as-ticket-title{font-size:16px;font-weight:800;overflow-wrap:anywhere}
.as-status{display:inline-flex;align-items:center;gap:7px;padding:7px 11px;border-radius:30px;font-size:11px;font-weight:800;white-space:nowrap;background:#5573ff1b;color:#8ca0ff}
.as-status:before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor}
.as-status-diproses{background:#f59e0b1c;color:#fbbf24}
.as-status-menunggu_pengguna{background:#8b5cf61c;color:#b39aff}
.as-status-selesai{background:#16a34a1b;color:#4ade80}
.as-status-baru{background:#5573ff1b;color:#8ca0ff}
.as-ticket-body{padding:19px 20px}
.as-user{display:flex;align-items:center;gap:11px;margin-bottom:17px;min-width:0}
.as-avatar{width:41px;height:41px;flex:0 0 41px;border-radius:13px;background:linear-gradient(135deg,#526ef5,#8054e8);display:grid;place-items:center;color:#fff;font-weight:800}
.as-user-name{font-size:13px;font-weight:800;overflow-wrap:anywhere}
.as-user-meta{font-size:11px;color:var(--muted);margin-top:4px;overflow-wrap:anywhere}
.as-category{margin-left:auto;padding:6px 10px;border:1px solid var(--line);border-radius:9px;font-size:10px;color:var(--muted);white-space:nowrap}
.as-message{padding:15px;border-radius:12px;background:var(--bg);border:1px solid var(--line);font-size:13px;line-height:1.8;white-space:pre-wrap;overflow-wrap:anywhere}
.as-reply-label{display:block;font-size:12px;font-weight:800;margin-bottom:8px}
.as-form{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(180px,.6fr);gap:15px;margin-top:18px}
.as-field{min-width:0}
.as-field textarea,.as-field select{width:100%;max-width:100%;box-sizing:border-box;border:1px solid var(--line);border-radius:11px;padding:12px 13px;background:var(--bg);color:var(--text);font:inherit;font-size:13px;outline:none}
.as-field textarea{min-height:104px;resize:vertical;line-height:1.7}
.as-field select{min-height:45px}
.as-field textarea:focus,.as-field select:focus{border-color:#6378ff;box-shadow:0 0 0 3px #6378ff20}
.as-form-actions{display:flex;justify-content:flex-end;margin-top:13px}
.as-submit{border:0;border-radius:10px;padding:12px 17px;background:linear-gradient(100deg,#4967f5,#7651e8);color:#fff;font-size:12px;font-weight:800;cursor:pointer}
.as-submit:hover{filter:brightness(1.08)}
.as-admin-reply{margin-top:15px;padding:13px 15px;border-radius:11px;border:1px solid #627aff40;background:#5573ff0d}
.as-admin-reply strong{font-size:11px;color:#8ca0ff}
.as-admin-reply p{font-size:13px;line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere;margin:7px 0 0}
.as-empty{background:var(--panel);border:1px dashed var(--line);border-radius:16px;padding:38px 18px;text-align:center;color:var(--muted)}
.as-alert{padding:13px 15px;border-radius:11px;margin-bottom:15px;font-size:13px}
.as-success{background:#16a34a18;color:#4ade80;border:1px solid #16a34a50}
.as-error{background:#ef444418;color:#f87171;border:1px solid #ef444450}
@media(max-width:900px){.as-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.as-form{grid-template-columns:1fr}}
@media(max-width:520px){.as-hero{padding:20px}.as-ticket-head,.as-ticket-body{padding:15px}.as-user{align-items:flex-start;flex-wrap:wrap}.as-category{margin-left:0}.as-form-actions .as-submit{width:100%}}
</style>

<div class="admin-support">
    <section class="as-hero">
        <div class="as-kicker">CUSTOMER SUPPORT CENTER</div>
        <h2>Kelola laporan pengguna dengan mudah.</h2>
        <p>Tinjau kendala, berikan solusi, dan pantau progres setiap tiket bantuan dari satu tempat.</p>
    </section>

    <?php if(session('success')): ?>
        <div class="as-alert as-success"><i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="as-alert as-error">
            <strong>Pembaruan belum berhasil.</strong>
            <ul style="margin:7px 0 0;padding-left:20px">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php
        $allTickets = $tickets->getCollection();
        $totalTickets = $tickets->total();
        $newTickets = $allTickets->where('status', 'baru')->count();
        $processingTickets = $allTickets->where('status', 'diproses')->count();
        $waitingTickets = $allTickets->where('status', 'menunggu_pengguna')->count();
        $closedTickets = $allTickets->where('status', 'selesai')->count();
    ?>

    <div class="as-stats">
        <div class="as-stat">
            <div class="as-stat-top"><span>Total tiket</span><span class="as-stat-icon"><i class="bi bi-inbox"></i></span></div>
            <strong><?php echo e($totalTickets); ?></strong><small>Seluruh laporan masuk</small>
        </div>
        <div class="as-stat">
            <div class="as-stat-top"><span>Tiket baru</span><span class="as-stat-icon"><i class="bi bi-bell"></i></span></div>
            <strong><?php echo e($newTickets); ?></strong><small>Di halaman ini</small>
        </div>
        <div class="as-stat">
            <div class="as-stat-top"><span>Diproses</span><span class="as-stat-icon"><i class="bi bi-arrow-repeat"></i></span></div>
            <strong><?php echo e($processingTickets); ?></strong><small>Di halaman ini</small>
        </div>
        <div class="as-stat">
            <div class="as-stat-top"><span>Selesai</span><span class="as-stat-icon"><i class="bi bi-check2-circle"></i></span></div>
            <strong><?php echo e($closedTickets); ?></strong><small>Di halaman ini</small>
        </div>
    </div>

    <div class="as-list-head">
        <div>
            <h2><i class="bi bi-ticket-detailed" style="color:#8195ff"></i> Daftar tiket bantuan</h2>
            <div class="as-muted">Periksa detail laporan dan kirim balasan kepada pengguna.</div>
        </div>
        <span class="as-muted"><?php echo e($tickets->firstItem() ?? 0); ?>–<?php echo e($tickets->lastItem() ?? 0); ?> dari <?php echo e($totalTickets); ?> tiket</span>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="as-ticket">
            <header class="as-ticket-head">
                <div>
                    <div class="as-ticket-id"><?php echo e($ticket->ticket_number); ?></div>
                    <div class="as-ticket-title"><?php echo e($ticket->subject); ?></div>
                </div>
                <span class="as-status as-status-<?php echo e($ticket->status); ?>"><?php echo e(str_replace('_', ' ', ucfirst($ticket->status))); ?></span>
            </header>

            <div class="as-ticket-body">
                <div class="as-user">
                    <div class="as-avatar"><?php echo e(strtoupper(substr($ticket->user->name ?? '?', 0, 1))); ?></div>
                    <div style="min-width:0">
                        <div class="as-user-name"><?php echo e($ticket->user->name ?? 'Pengguna dihapus'); ?></div>
                        <div class="as-user-meta"><?php echo e($ticket->user->email ?? '-'); ?> · <?php echo e($ticket->created_at->format('d/m/Y H:i')); ?></div>
                    </div>
                    <span class="as-category"><i class="bi bi-tag"></i> <?php echo e(ucfirst($ticket->category)); ?></span>
                </div>

                <div class="as-message"><?php echo e($ticket->message); ?></div>

                <?php if($ticket->attachment_path): ?>
                    <p style="margin:12px 0">
                        <a href="<?php echo e(route('admin.support-tickets.attachment', $ticket)); ?>" target="_blank" rel="noopener">
                            <i class="bi bi-image"></i> Lihat gambar lampiran pengguna
                        </a>
                    </p>
                <?php endif; ?>

                <?php if($ticket->admin_reply): ?>
                    <div class="as-admin-reply">
                        <strong><i class="bi bi-reply-fill"></i> BALASAN ADMIN SEBELUMNYA</strong>
                        <p><?php echo e($ticket->admin_reply); ?></p>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.support-tickets.update', $ticket)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="as-form">
                        <div class="as-field">
                            <label class="as-reply-label" for="reply-<?php echo e($ticket->id); ?>">Balasan untuk pengguna</label>
                            <textarea id="reply-<?php echo e($ticket->id); ?>" name="admin_reply" maxlength="5000" placeholder="Tuliskan solusi atau informasi untuk pengguna..."><?php echo e(old('admin_reply', $ticket->admin_reply)); ?></textarea>
                        </div>

                        <div class="as-field">
                            <label class="as-reply-label" for="status-<?php echo e($ticket->id); ?>">Status penanganan</label>
                            <select id="status-<?php echo e($ticket->id); ?>" name="status" required>
                                <?php $__currentLoopData = ['baru'=>'Baru','diproses'=>'Sedang diproses','menunggu_pengguna'=>'Menunggu pengguna','selesai'=>'Selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php if(old('status', $ticket->status) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="as-muted" style="margin-top:8px">Pilih status terbaru sebelum menyimpan.</div>
                        </div>
                    </div>

                    <div class="as-form-actions">
                        <button class="as-submit" type="submit"><i class="bi bi-check2-circle"></i> Simpan pembaruan tiket</button>
                    </div>
                </form>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="as-empty">
            <div style="font-size:35px;margin-bottom:12px"><i class="bi bi-inbox"></i></div>
            <strong>Belum ada laporan masuk</strong>
            <p class="as-muted" style="margin:8px 0 0">Laporan baru dari pengguna akan muncul di halaman ini.</p>
        </div>
    <?php endif; ?>

    <div style="margin-top:18px"><?php echo e($tickets->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/admin/support-tickets.blade.php ENDPATH**/ ?>