<?php
namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Topup;
use App\Models\WalletTransaction;
use App\Models\Setting;
use App\Models\OtpOrder;
use Illuminate\Http\Request;
class AdminController extends Controller {
    public function index(){ return view('admin.index',['users'=>User::count(),'blocked'=>User::where('is_blocked',true)->count(),'topups'=>Topup::where('status','paid')->sum('amount'),'orders'=>OtpOrder::count(),'recent'=>Topup::with('user')->latest()->take(10)->get()]); }
    public function users(Request $request)
    {
        $search = trim((string) $request->query('search', ''));

        $query = User::query();

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', '%' . $search . '%')
                  ->orWhere('email', 'like', '%' . $search . '%');
            });
        }

        $users = $query->latest()->paginate(25)->withQueryString();

        return view('admin.users', compact('users', 'search'));
    }
    public function toggleBlock(User $user){ abort_if($user->role==='admin',403); $user->update(['is_blocked'=>!$user->is_blocked]); return back()->with('success','Status akun diperbarui.'); }

    public function addBalance(Request $request, User $user)
    {
        abort_if($user->role === 'admin', 403, 'Saldo akun admin tidak dapat diubah dari fitur ini.');

        $data = $request->validate([
            'amount' => ['required', 'integer', 'min:1000', 'max:100000000'],
            'transaction_type' => ['required', 'in:admin_credit,refund'],
            'description' => ['nullable', 'string', 'max:200'],
        ]);

        \Illuminate\Support\Facades\DB::transaction(function () use ($user, $data) {
            $lockedUser = User::whereKey($user->id)->lockForUpdate()->firstOrFail();
            $lockedUser->increment('balance', (int) $data['amount']);

            \App\Models\WalletTransaction::create([
                'user_id' => $lockedUser->id,
                'topup_id' => null,
                'type' => $data['transaction_type'],
                'amount' => (int) $data['amount'],
                'description' => ($data['transaction_type'] === 'refund'
                    ? 'Refund saldo oleh admin'
                    : 'Top up oleh admin') .
                    (empty($data['description']) ? '' : ': ' . $data['description']),
            ]);
        });

        return back()->with('success', 'Saldo ' . $user->name . ' berhasil ditambah Rp' .
            number_format((int) $data['amount'], 0, ',', '.') . '.');
    }

    public function deductBalance(Request $request, User $user)
    {
        abort_if($user->role === 'admin', 403, 'Saldo akun admin tidak dapat diubah dari fitur ini.');

        $data = $request->validate([
            'amount' => ['required', 'integer', 'min:1', 'max:100000000'],
            'description' => ['required', 'string', 'max:200'],
        ]);

        $result = \Illuminate\Support\Facades\DB::transaction(function () use ($user, $data) {
            $lockedUser = User::whereKey($user->id)->lockForUpdate()->firstOrFail();
            $amount = (int) $data['amount'];

            if ((int) $lockedUser->balance < $amount) {
                return false;
            }

            $lockedUser->decrement('balance', $amount);

            \App\Models\WalletTransaction::create([
                'user_id' => $lockedUser->id,
                'topup_id' => null,
                'type' => 'admin_debit',
                'amount' => $amount,
                'description' => 'Pengurangan saldo oleh admin: ' . $data['description'],
            ]);

            return true;
        });

        if (!$result) {
            return back()->withErrors([
                'balance' => 'Saldo user tidak mencukupi. Saldo tidak diubah.'
            ]);
        }

        return back()->with(
            'success',
            'Saldo ' . $user->name . ' berhasil dikurangi Rp' .
            number_format((int) $data['amount'], 0, ',', '.') . '.'
        );
    }

    public function pricing(){ return view('admin.pricing',['markup'=>setting('markup_percent',env('DEFAULT_MARKUP_PERCENT',20))]); }
    public function savePricing(Request $r){ $data=$r->validate(['markup_percent'=>'required|numeric|min:0|max:300']); Setting::updateOrCreate(['key'=>'markup_percent'],['value'=>(string)$data['markup_percent']]); return back()->with('success','Markup berhasil disimpan.'); }
    public function saveTopupMethods(Request $request)
    {
        $data = $request->validate([
            'topup_qris_enabled' => ['nullable', 'in:1'],
            'topup_gopay_enabled' => ['nullable', 'in:1'],
            'topup_shopeepay_enabled' => ['nullable', 'in:1'],
        ]);

        foreach ([
            'topup_qris_enabled',
            'topup_gopay_enabled',
            'topup_shopeepay_enabled',
        ] as $key) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $request->boolean($key) ? '1' : '0']
            );
        }

        // Kompatibilitas dengan pengaturan otomatis lama.
        $automatic = $request->boolean('topup_gopay_enabled')
            || $request->boolean('topup_shopeepay_enabled');

        Setting::updateOrCreate(
            ['key' => 'auto_topup_enabled'],
            ['value' => $automatic ? '1' : '0']
        );

        return back()->with('success', 'Pengaturan metode Top Up berhasil disimpan.');
    }

    public function toggleAutoTopup(\Illuminate\Http\Request $request)
    {
        $enabled = $request->input('auto_topup') === '1';

        \App\Models\Setting::updateOrCreate(
            ['key' => 'auto_topup_enabled'],
            ['value' => $enabled ? '1' : '0']
        );

        return back()->with(
            'success',
            $enabled
                ? 'Top up otomatis diaktifkan.'
                : 'Top up otomatis dimatikan.'
        );
    }

    public function topups(){ return view('admin.topups',['topups'=>Topup::with('user')->latest()->paginate(30)]); }


    public function orders(Request $request)
    {
        $query = OtpOrder::with('user')->latest();

        if ($request->filled('q')) {
            $term = trim((string) $request->input('q'));
            $query->where(function ($q) use ($term) {
                $q->where('service_name', 'like', '%' . $term . '%')
                  ->orWhere('phone_number', 'like', '%' . $term . '%')
                  ->orWhere('provider_order_id', 'like', '%' . $term . '%')
                  ->orWhereHas('user', function ($u) use ($term) {
                      $u->where('name', 'like', '%' . $term . '%')
                        ->orWhere('email', 'like', '%' . $term . '%');
                  });

                if (ctype_digit($term)) {
                    $q->orWhere('id', (int) $term);
                }
            });
        }

        $allowedStatuses = ['active', 'pending', 'completed', 'success', 'canceled', 'cancelled', 'failed', 'expired'];
        if ($request->filled('status') && in_array(strtolower($request->input('status')), $allowedStatuses, true)) {
            $query->whereRaw('LOWER(status) = ?', [strtolower($request->input('status'))]);
        }

        return view('admin.orders', [
            'orders' => $query->paginate(15)->withQueryString(),
            'search' => (string) $request->input('q', ''),
            'statusFilter' => (string) $request->input('status', ''),
        ]);
    }

    public function cancelOrder(Request $request, OtpOrder $order, \App\Services\SimuruClient $api)
    {
        if (!in_array(strtolower((string) $order->status), ['active', 'pending'], true)) {
            return back()->withErrors(['order' => 'Order ini sudah tidak aktif atau sudah diproses.']);
        }

        // Order simulasi tidak memiliki order sungguhan di SIMURU dan tidak mendapat refund.
        if (str_starts_with((string) $order->provider_order_id, 'TEST-')) {
            $changed = \Illuminate\Support\Facades\DB::transaction(function () use ($order) {
                $locked = OtpOrder::whereKey($order->id)->lockForUpdate()->firstOrFail();

                if (!in_array(strtolower((string) $locked->status), ['active', 'pending'], true)) {
                    return false;
                }

                $locked->update(['status' => 'canceled']);
                return true;
            });

            return $changed
                ? back()->with('success', 'Order simulasi berhasil ditandai dibatalkan. Tidak ada refund.')
                : back()->withErrors(['order' => 'Status order sudah berubah.']);
        }

        try {
            $detail = $api->activeDetail((int) $order->provider_order_id);
            $smsCode = $detail['sms_code'] ?? $order->sms_code;
            $smsData = $detail['sms_data'] ?? $order->sms_data;
            $providerStatus = strtolower((string) ($detail['status'] ?? $order->status));

            $order->update([
                'phone_number' => $detail['phone_number'] ?? $order->phone_number,
                'sms_code' => $smsCode,
                'sms_data' => $smsData,
                'status' => $detail['status'] ?? $order->status,
                'remaining_seconds' => $detail['remaining_seconds'] ?? $order->remaining_seconds,
                'provider_payload' => $detail,
            ]);

            if (!empty($smsCode) || !empty($smsData)) {
                return back()->withErrors(['order' => 'SMS sudah masuk. Order tidak dibatalkan agar kode OTP tidak hilang.']);
            }

            if (!in_array($providerStatus, ['active', 'pending'], true)) {
                return back()->withErrors(['order' => 'Status order di provider sudah berubah. Muat ulang riwayat sebelum mencoba lagi.']);
            }

            // Hubungi provider dahulu; saldo baru diproses setelah provider menerima pembatalan.
            $api->cancel((int) $order->provider_order_id);

            $refunded = \Illuminate\Support\Facades\DB::transaction(function () use ($order) {
                $locked = OtpOrder::whereKey($order->id)->lockForUpdate()->firstOrFail();

                if (!in_array(strtolower((string) $locked->status), ['active', 'pending'], true)) {
                    return false;
                }

                $locked->update(['status' => 'canceled']);

                $user = User::whereKey($locked->user_id)->lockForUpdate()->firstOrFail();

                // Hanya order milik pengguna biasa yang mendapat refund.
                if ($user->role !== 'admin') {
                    $user->increment('balance', (int) $locked->selling_price);

                    WalletTransaction::create([
                        'user_id' => $user->id,
                        'topup_id' => null,
                        'type' => 'refund',
                        'amount' => (int) $locked->selling_price,
                        'description' => 'Refund pembatalan OTP oleh admin, order #' . $locked->id,
                    ]);
                }

                return true;
            });

            if (!$refunded) {
                return back()->withErrors(['order' => 'Status order lokal sudah berubah. Refund tidak dilakukan dua kali.']);
            }

            return back()->with('success', 'Order #' . $order->id . ' dibatalkan. Refund pengguna diproses bila memenuhi syarat.');
        } catch (\Throwable $e) {
            $message = $e->getMessage();

            if (str_contains($message, 'HTTP 422') && str_contains(strtolower($message), 'batas waktu minimum')) {
                return back()->withErrors(['order' => 'Provider belum mengizinkan pembatalan. Tunggu beberapa saat lalu coba lagi. Status dan saldo tidak diubah menjadi batal/refund.']);
            }

            report($e);
            return back()->withErrors(['order' => 'Pembatalan belum terkonfirmasi dari provider. Status saldo tidak boleh dianggap berhasil dibatalkan.']);
        }
    }

    public function topupProof(Topup $topup)
    {
        abort_unless($topup->proof_path, 404);
        abort_unless(\Illuminate\Support\Facades\Storage::disk('local')->exists($topup->proof_path), 404);

        return \Illuminate\Support\Facades\Storage::disk('local')->response($topup->proof_path);
    }

    public function approveTopup(Request $request, Topup $topup)
    {
        $credited = \Illuminate\Support\Facades\DB::transaction(function () use ($request, $topup) {
            $locked = Topup::whereKey($topup->id)->lockForUpdate()->firstOrFail();

            abort_unless($locked->payment_type === 'manual_qris', 422, 'Ini bukan top up QRIS manual.');
            abort_unless($locked->status === 'pending', 422, 'Transaksi sudah diproses.');
            abort_unless($locked->proof_path, 422,
                'Pastikan bukti pembayaran dan referensi sudah diperiksa.');

            // Hanya satu proses yang dapat mengubah status pending menjadi paid.
            $changed = Topup::whereKey($locked->id)
                ->where('status', 'pending')
                ->update([
                    'status' => 'paid',
                    'paid_at' => now(),
                    'reviewed_by' => $request->user()->id,
                    'reviewed_at' => now(),
                    'updated_at' => now(),
                ]);

            if ($changed !== 1) {
                return false;
            }

            $user = User::whereKey($locked->user_id)->lockForUpdate()->firstOrFail();
            $user->increment('balance', (int) $locked->amount);

            WalletTransaction::create([
                'user_id' => $user->id,
                'topup_id' => $locked->id,
                'type' => 'credit',
                'amount' => (int) $locked->amount,
                'description' => 'Top up QRIS manual ' . $locked->order_id,
            ]);

            return true;
        });

        return back()->with(
            $credited ? 'success' : 'error',
            $credited ? 'Top up disetujui dan saldo dikreditkan.' : 'Transaksi sudah diproses sebelumnya.'
        );
    }

    public function rejectTopup(Request $request, Topup $topup)
    {
        $data = $request->validate([
            'rejection_reason' => ['required', 'string', 'max:500'],
        ]);

        $changed = Topup::whereKey($topup->id)
            ->where('payment_type', 'manual_qris')
            ->where('status', 'pending')
            ->update([
                'status' => 'rejected',
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
                'rejection_reason' => $data['rejection_reason'],
                'updated_at' => now(),
            ]);

        if (!$changed) {
            return back()->withErrors(['topup' => 'Transaksi sudah diproses atau bukan QRIS manual.']);
        }

        return back()->with('success', 'Permintaan top up ditolak tanpa menambah saldo.');
    }



    public function resetPassword(User $user)
    {
        abort_if($user->role === 'admin', 403, 'Password administrator tidak dapat direset dari menu ini.');

        $temporaryPassword = \Illuminate\Support\Str::random(16);

        $user->forceFill([
            'password' => \Illuminate\Support\Facades\Hash::make($temporaryPassword),
        ])->save();

        return redirect()->route('admin.users')
            ->with('success', 'Password pengguna berhasil direset.')
            ->with('reset_password', [
                'name' => $user->name,
                'email' => $user->email,
                'password' => $temporaryPassword,
            ]);
    }

}
