<!doctype html>
<html lang="id" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <title>Daftar · <?php echo e(setting('site_name', 'Digistore OTP')); ?></title>

    <script>
        try {
            document.documentElement.dataset.theme =
                localStorage.getItem('depuka-login-theme') === 'dark' ? 'dark' : 'light';
        } catch (e) {}
    </script>

    <style>
        :root {
            color-scheme: light;
            --bg:#f4f7fc; --surface:rgba(255,255,255,.94);
            --text:#172033; --muted:#788397; --border:#e5eaf2;
            --input:#f8faff; --accent:#4f6df5; --accent2:#7658ee;
            --shadow:0 24px 80px rgba(37,55,100,.12);
        }
        html[data-theme="dark"] {
            color-scheme:dark;
            --bg:#0b1020; --surface:rgba(19,27,47,.96);
            --text:#f0f4ff; --muted:#9aa8c2; --border:#2a3550;
            --input:#111a2e; --accent:#8294ff; --accent2:#a28bff;
            --shadow:0 24px 80px rgba(0,0,0,.3);
        }
        *{box-sizing:border-box}
        body{
            margin:0;min-height:100vh;padding:24px 16px;display:grid;place-items:center;
            font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
            color:var(--text);
            background:radial-gradient(ellipse at 12% 12%,rgba(87,112,255,.13),transparent 38%),
            radial-gradient(ellipse at 90% 88%,rgba(135,94,255,.12),transparent 34%),var(--bg);
            transition:background .25s,color .25s
        }
        button,input{font:inherit}
        .shell{
            width:min(100%,1000px);display:grid;grid-template-columns:1fr 1fr;
            overflow:hidden;border:1px solid var(--border);border-radius:28px;
            background:var(--surface);box-shadow:var(--shadow);backdrop-filter:blur(18px)
        }
        .welcome{
            position:relative;isolation:isolate;overflow:hidden;display:flex;flex-direction:column;
            justify-content:space-between;min-height:650px;padding:42px;color:#fff;
            background:linear-gradient(145deg,#304ee1,#6555e9 52%,#8b5cf6)
        }
        .welcome:before{
            content:"";position:absolute;z-index:-1;width:360px;height:360px;right:-145px;top:120px;
            border:1px solid #ffffff35;border-radius:50%;
            box-shadow:0 0 0 35px #ffffff09,0 0 0 75px #ffffff06
        }
        .brand{display:inline-flex;align-items:center;gap:12px;color:inherit;text-decoration:none;font-size:19px;font-weight:800}
        .brand-mark{display:grid;place-items:center;width:43px;height:43px;border:1px solid #ffffff45;border-radius:14px;background:#ffffff20;font-size:22px}
        .brand small{display:block;margin-top:2px;font-size:10px;letter-spacing:3px;opacity:.75}
        .welcome-copy{margin:45px 0}
        .pill{display:inline-block;padding:8px 12px;border:1px solid #ffffff45;border-radius:999px;background:#ffffff18;font-size:10px;font-weight:800;letter-spacing:2px}
        .welcome h2{max-width:390px;margin:22px 0 14px;font-size:clamp(30px,4vw,43px);line-height:1.13;letter-spacing:-1.8px}
        .welcome p{max-width:330px;color:#ffffffcc;font-size:14px;line-height:1.9}
        .foot{color:#ffffffb3;font-size:11px}
        .form-panel{padding:32px clamp(25px,4vw,52px);display:flex;flex-direction:column;justify-content:center;min-width:0}
        .top{display:flex;justify-content:flex-end;margin-bottom:27px}
        .theme{
            display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border:1px solid var(--border);
            border-radius:999px;color:var(--text);background:var(--surface);cursor:pointer;font-size:12px;font-weight:650
        }
        .heading .eyebrow{margin:0 0 10px;color:var(--accent);font-size:11px;font-weight:800;letter-spacing:2px}
        h1{margin:0;font-size:30px;letter-spacing:-1px}
        .sub{margin:9px 0 23px;color:var(--muted);font-size:13px;line-height:1.7}
        .field{margin-bottom:15px}
        .field label{display:block;margin-bottom:8px;font-size:12px;font-weight:750}
        .input-wrap{position:relative}
        .input-wrap input{
            width:100%;height:47px;padding:0 76px 0 13px;border:1px solid var(--border);
            border-radius:12px;outline:none;color:var(--text);background:var(--input);font-size:13px;transition:.2s
        }
        .input-wrap input:focus{border-color:var(--accent);box-shadow:0 0 0 3px #5c6ff522}
        .input-wrap input::placeholder{color:var(--muted);opacity:.8}
        .toggle{
            position:absolute;right:8px;top:50%;transform:translateY(-50%);border:0;padding:7px;
            color:var(--muted);background:transparent;cursor:pointer;font-size:11px;font-weight:700
        }
        .submit{
            display:flex;justify-content:center;align-items:center;gap:12px;width:100%;min-height:49px;
            margin-top:5px;border:0;border-radius:12px;color:white;
            background:linear-gradient(100deg,#4e68ee,#7959ed);
            box-shadow:0 9px 22px #535ee238;cursor:pointer;font-size:13px;font-weight:800;transition:.2s
        }
        .submit:hover{transform:translateY(-1px);box-shadow:0 12px 26px #535ee24d}
        .submit span{font-size:18px}
        .error{
            margin:0 0 15px;padding:12px 14px;border:1px solid #f4b8bd;border-radius:10px;
            color:#c92f40;background:#fff0f1;font-size:12px;line-height:1.6
        }
        html[data-theme="dark"] .error{border-color:#733b4a;color:#ff9ba7;background:#321d2b}
        .auth-foot{margin:22px 0 0;text-align:center;color:var(--muted);font-size:12px}
        .auth-foot a{color:var(--accent);font-weight:800;text-decoration:none}
        .auth-foot a:hover{text-decoration:underline}
        @media(max-width:760px){
            body{padding:14px 10px}
            .shell{width:min(100%,460px);grid-template-columns:1fr;border-radius:23px}
            .welcome{min-height:auto;padding:24px 25px 26px}
            .welcome-copy{margin:28px 0 8px}
            .welcome h2{margin:14px 0 9px;font-size:29px}
            .welcome p{margin-bottom:0;font-size:12px}
            .foot{display:none}
            .form-panel{padding:24px 25px 28px}
            .top{margin-bottom:20px}
            h1{font-size:27px}
        }
        @media(prefers-reduced-motion:reduce){*,*:before,*:after{transition:none!important}}
    </style>
</head>
<body>
<main class="shell">
    <section class="welcome">
        <a class="brand" href="<?php echo e(url('/')); ?>">
            <span class="brand-mark">D</span>
            <span><?php echo e(setting('brand_name', 'Digistore')); ?><small>OTP PLATFORM</small></span>
        </a>
        <div class="welcome-copy">
            <span class="pill">JOIN <?php echo e(strtoupper(setting('brand_name', 'Digistore'))); ?></span>
            <h2>Mulai perjalananmu bersama kami.</h2>
            <p>Buat akun baru untuk menikmati pengelolaan layanan OTP yang praktis dalam satu dashboard.</p>
        </div>
        <div class="foot">© <?php echo e(date('Y')); ?> <?php echo e(setting('footer_name', 'Digistore OTP')); ?> · Your account, your control</div>
    </section>

    <section class="form-panel">
        <div class="top">
            <button class="theme" type="button" id="themeToggle">
                <span id="themeIcon">☾</span><span id="themeLabel">Mode gelap</span>
            </button>
        </div>

        <div class="heading">
            <p class="eyebrow">BUAT AKUN BARU</p>
            <h1>Daftar sekarang</h1>
            <p class="sub">Lengkapi data di bawah untuk membuat akun <?php echo e(setting('site_name', 'Digistore OTP')); ?>.</p>
        </div>

        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="field">
                <label for="name">Nama lengkap</label>
                <div class="input-wrap">
                    <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>"
                           placeholder="Masukkan nama lengkap" autocomplete="name" maxlength="100" required autofocus>
                </div>
            </div>

            <div class="field">
                <label for="email">Alamat email</label>
                <div class="input-wrap">
                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>"
                           placeholder="nama@email.com" autocomplete="email" required>
                </div>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <div class="input-wrap">
                    <input id="password" type="password" name="password"
                           placeholder="Minimal 10 karakter" autocomplete="new-password" minlength="10" required>
                    <button type="button" class="toggle" data-toggle="password">Lihat</button>
                </div>
            </div>

            <div class="field">
                <label for="password_confirmation">Konfirmasi password</label>
                <div class="input-wrap">
                    <input id="password_confirmation" type="password" name="password_confirmation"
                           placeholder="Ulangi password" autocomplete="new-password" minlength="10" required>
                    <button type="button" class="toggle" data-toggle="password_confirmation">Lihat</button>
                </div>
            </div>

            <?php if($errors->any()): ?>
                <div class="error" role="alert"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <button type="button" class="submit" id="openConsent">Buat akun <span aria-hidden="true">→</span></button>
        </form>

        <p class="auth-foot">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk di sini</a></p>
    </section>
</main>

<script>
(function(){
    const root=document.documentElement;
    const themeButton=document.getElementById('themeToggle');
    const themeIcon=document.getElementById('themeIcon');
    const themeLabel=document.getElementById('themeLabel');

    function refreshTheme(){
        const dark=root.dataset.theme==='dark';
        themeIcon.textContent=dark?'☀':'☾';
        themeLabel.textContent=dark?'Mode terang':'Mode gelap';
        themeButton.setAttribute('aria-pressed',String(dark));
    }
    refreshTheme();

    themeButton.addEventListener('click',function(){
        const next=root.dataset.theme==='dark'?'light':'dark';
        root.dataset.theme=next;
        try{localStorage.setItem('depuka-login-theme',next)}catch(e){}
        refreshTheme();
    });

    document.querySelectorAll('[data-toggle]').forEach(function(button){
        button.addEventListener('click',function(){
            const input=document.getElementById(button.dataset.toggle);
            const show=input.type==='password';
            input.type=show?'text':'password';
            button.textContent=show?'Sembunyi':'Lihat';
            button.setAttribute('aria-pressed',String(show));
        });
    });
})();
</script>

<style>
.consent-modal[hidden] { display:none !important; }
.consent-modal {
    position:fixed;inset:0;z-index:99999;
    display:grid;place-items:center;padding:18px;
}
.consent-backdrop {
    position:absolute;inset:0;
    background:rgba(8,15,32,.68);
    backdrop-filter:blur(6px);
}
.consent-dialog {
    position:relative;width:min(100%,470px);
    max-height:min(88vh,720px);overflow-y:auto;
    padding:28px;border:1px solid var(--border);
    border-radius:22px;background:#fff;color:#172033;
    box-shadow:0 28px 90px rgba(0,0,0,.3);
    animation:consentPop .2s ease-out;
}
.consent-icon {
    display:grid;place-items:center;width:54px;height:54px;
    margin-bottom:18px;border-radius:16px;
    background:#e8efff;color:#405ff0;font-size:25px;
}
.consent-dialog h2 {
    margin:0 0 9px;font-size:23px;letter-spacing:-.6px;
}
.consent-description {
    margin:0;color:#66738a;font-size:13px;line-height:1.7;
}
.consent-list {
    display:grid;gap:12px;margin:20px 0;padding:0;list-style:none;
}
.consent-list li {
    display:flex;gap:10px;align-items:flex-start;
    padding:12px;border:1px solid #e3e9f3;
    border-radius:12px;background:#f7f9fd;
    color:#46546c;font-size:12px;line-height:1.65;
}
.consent-list li svg { flex:0 0 18px;color:#16845d;margin-top:1px; }
.consent-check {
    display:flex;align-items:flex-start;gap:10px;
    margin-top:18px;padding:13px;border-radius:12px;
    border:1px solid #dbe4f5;background:#f1f5ff;
    color:#263653;font-size:12px;line-height:1.6;cursor:pointer;
}
.consent-check input { margin-top:3px;accent-color:#4f6df5; }
.consent-actions {
    display:flex;justify-content:flex-end;gap:10px;margin-top:22px;
}
.consent-button {
    min-height:44px;padding:0 16px;border-radius:11px;
    font:inherit;font-size:12px;font-weight:800;cursor:pointer;
}
.consent-back {
    color:#263653;background:#fff;border:1px solid #cbd5e4;
}
.consent-agree {
    display:inline-flex;align-items:center;justify-content:center;gap:8px;
    color:#fff;background:linear-gradient(110deg,#4e68ee,#7959ed);
    border:1px solid transparent;box-shadow:0 7px 18px #535ee230;
}
.consent-agree:disabled { opacity:.45;cursor:not-allowed;box-shadow:none; }
html[data-theme="dark"] .consent-dialog {
    background:#131b2f;color:#f0f4ff;border-color:#2a3550;
}
html[data-theme="dark"] .consent-description { color:#a8b5cc; }
html[data-theme="dark"] .consent-list li {
    color:#c4cfe2;background:#19243a;border-color:#2b3955;
}
html[data-theme="dark"] .consent-check {
    color:#e1e8f8;background:#1b2943;border-color:#354665;
}
html[data-theme="dark"] .consent-back {
    color:#f0f4ff;background:#1b2943;border-color:#435575;
}
@keyframes consentPop {
    from { opacity:0;transform:translateY(8px) scale(.98); }
    to { opacity:1;transform:translateY(0) scale(1); }
}
@media(max-width:480px) {
    .consent-dialog { padding:22px;border-radius:18px; }
    .consent-dialog h2 { font-size:21px; }
    .consent-actions { flex-direction:column-reverse; }
    .consent-button { width:100%;min-height:46px; }
}
@media(prefers-reduced-motion:reduce) {
    .consent-dialog { animation:none; }
}
</style>

<div class="consent-modal" id="consentModal" hidden>
    <div class="consent-backdrop" data-consent-close></div>
    <section class="consent-dialog" role="dialog" aria-modal="true"
        aria-labelledby="consentTitle" aria-describedby="consentDescription">
        <div class="consent-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="28" height="28" fill="none"
                stroke="currentColor" stroke-width="1.8"
                stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 3 19 6v5c0 4.5-3 7.5-7 10-4-2.5-7-5.5-7-10V6l7-3Z"/>
                <path d="m9 12 2 2 4-4"/>
            </svg>
        </div>
        <h2 id="consentTitle">Persetujuan pendaftaran</h2>
        <p class="consent-description" id="consentDescription">
            Sebelum membuat akun <?php echo e(setting('site_name', 'Digistore OTP')); ?>, silakan baca dan setujui ketentuan berikut.
        </p>

        <ul class="consent-list">
            <li>
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none"
                    stroke="currentColor" stroke-width="2"><path d="m5 12 4 4L19 6"/></svg>
                <span>Saya memahami bahwa layanan OTP tidak menjamin keberhasilan 100%. Kode OTP bisa saja tidak diterima atau tidak masuk.</span>
            </li>
            <li>
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none"
                    stroke="currentColor" stroke-width="2"><path d="m5 12 4 4L19 6"/></svg>
                <span>Saya memahami bahwa keberhasilan penerimaan OTP dapat dipengaruhi oleh layanan tujuan, operator, negara, dan kondisi jaringan.</span>
            </li>
            <li>
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none"
                    stroke="currentColor" stroke-width="2"><path d="m5 12 4 4L19 6"/></svg>
                <span>Saya memahami bahwa waktu penerimaan kode dapat berbeda-beda dan menggunakan layanan <?php echo e(setting('site_name', 'Digistore OTP')); ?> dengan risiko tersebut.</span>
            </li>
        </ul>

        <label class="consent-check">
            <input type="checkbox" id="consentAccepted">
            <span>Saya telah membaca, memahami, dan menyetujui ketentuan pendaftaran di atas.</span>
        </label>

        <div class="consent-actions">
            <button type="button" class="consent-button consent-back" data-consent-close>
                Kembali
            </button>
            <button type="button" class="consent-button consent-agree"
                id="confirmRegistration" disabled>
                Setuju &amp; Daftar <span aria-hidden="true">→</span>
            </button>
        </div>
    </section>
</div>

<script>
(function () {
    const form = document.querySelector('.form-panel form');
    const openButton = document.getElementById('openConsent');
    const modal = document.getElementById('consentModal');
    const checkbox = document.getElementById('consentAccepted');
    const confirmButton = document.getElementById('confirmRegistration');
    if (!form || !openButton || !modal || !checkbox || !confirmButton) return;

    let previousFocus = null;

    function closeModal() {
        modal.hidden = true;
        checkbox.checked = false;
        confirmButton.disabled = true;
        openButton.focus();
    }

    openButton.addEventListener('click', function () {
        if (!form.reportValidity()) return;
        previousFocus = document.activeElement;
        modal.hidden = false;
        checkbox.focus();
    });

    checkbox.addEventListener('change', function () {
        confirmButton.disabled = !checkbox.checked;
    });

    modal.querySelectorAll('[data-consent-close]').forEach(function (button) {
        button.addEventListener('click', closeModal);
    });

    confirmButton.addEventListener('click', function () {
        if (!checkbox.checked) return;
        confirmButton.disabled = true;
        confirmButton.textContent = 'Memproses pendaftaran...';
        form.submit();
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && !modal.hidden) closeModal();
    });
})();
</script>

</body>
</html>
<?php /**PATH /root/digistore-project/digistore-otp/resources/views/auth/register.blade.php ENDPATH**/ ?>