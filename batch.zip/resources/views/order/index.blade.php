@extends('layouts.app')
@section('title','Order OTP')@section('crumb','LAYANAN')@section('heading','Order OTP')
@section('content')

<style>
.order-layout {
    display: grid;
    grid-template-columns: minmax(320px, 560px) minmax(0, 1fr);
    gap: 20px;
    align-items: start;
}
.order-form, .otp-insights-panel { min-width: 0; }
.otp-insights-panel { padding: 22px; }
.otp-insights-head { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; margin-bottom:20px; }
.otp-insights-head h3 { margin:0 0 6px; }
.otp-insights-head p { margin:0; font-size:12px; }
.otp-insights-live { display:inline-flex; align-items:center; gap:6px; white-space:nowrap; font-size:11px; color:#43d6a0; background:rgba(67,214,160,.09); border:1px solid rgba(67,214,160,.2); border-radius:20px; padding:6px 9px; }
.otp-insights-live span { width:6px; height:6px; border-radius:50%; background:#43d6a0; }
.otp-insights-list { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; }
.otp-insights-item { min-width:0; padding:14px; border:1px solid var(--border,#263248); border-radius:12px; background:rgba(127,146,180,.035); }
.otp-insights-row { display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:12px; }
.otp-insights-row strong { font-size:13px; overflow-wrap:anywhere; }
.otp-insights-rate { color:#43d6a0; font-size:18px; white-space:nowrap; }
.otp-insights-track { height:6px; border-radius:10px; background:rgba(127,146,180,.16); overflow:hidden; }
.otp-insights-track span { display:block; height:100%; border-radius:10px; background:linear-gradient(90deg,#4268ed,#43d6a0); }
.otp-insights-country,.otp-insights-hot { font-size:11px; line-height:1.6; margin:10px 0 0; overflow-wrap:anywhere; }
.otp-insights-hot { color:#43d6a0; }
.otp-insights-foot { font-size:11px; line-height:1.6; margin:16px 0 0; }
.otp-insights-empty { text-align:center; padding:48px 12px; }
.otp-insights-empty-icon { display:block; font-size:28px; color:#8da8ff; margin-bottom:12px; }
.otp-insights-empty p { font-size:12px; }
@media(max-width:1050px) {
    .order-layout { grid-template-columns:minmax(0,1fr); }
    .otp-insights-list { grid-template-columns:repeat(2,minmax(0,1fr)); }
}
@media(max-width:520px) {
    .otp-insights-list { grid-template-columns:minmax(0,1fr); }
    .otp-insights-head { flex-wrap:wrap; }
}


/* Country and operator dropdown refinements */
.picker-search-wrap{padding:10px 10px 8px;border-bottom:1px solid rgba(148,163,184,.12)}
.picker-search-wrap input{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #2c3d5c;border-radius:9px;background:#0b1220;color:#edf3ff;font-size:12px;outline:none}
.picker-search-wrap input:focus{border-color:#6087ff;box-shadow:0 0 0 3px rgba(75,115,255,.1)}
.country-picker{margin:8px 0 4px}
.country-picker .service-picker-options{max-height:250px}
#operatorPicker{margin:8px 0 12px}
#countryPickerIcon,#operatorPickerIcon{font-size:17px}

/* Premium custom service picker */
.service-picker{position:relative;margin:8px 0 12px;z-index:20}
.service-native-select{display:none!important}
.service-picker-trigger{width:100%;min-height:66px;display:flex;align-items:center;gap:12px;text-align:left;padding:12px 14px;border:1px solid var(--border-color, #29364d);border-radius:13px;background:linear-gradient(135deg,rgba(43,67,112,.32),rgba(15,23,42,.92));color:var(--text-color,#edf3ff);cursor:pointer;transition:border-color .18s,box-shadow .18s,transform .18s}
.service-picker-trigger:hover,.service-picker.is-open .service-picker-trigger{border-color:#6087ff;box-shadow:0 0 0 3px rgba(75,115,255,.12)}
.service-picker-trigger:active{transform:scale(.995)}
.service-picker-current-icon{width:42px;height:42px;flex:0 0 42px;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:12px;background:linear-gradient(135deg,#315be9,#7c6cff);color:white;font-size:19px;font-weight:800;box-shadow:0 5px 16px rgba(49,91,233,.2)}
.service-picker-current-icon img,.service-picker-option-icon img{width:100%;height:100%;object-fit:contain;padding:5px;background:#fff;border-radius:inherit}
.service-picker-current-text{min-width:0;flex:1;display:flex;flex-direction:column;gap:4px}
.service-picker-current-text strong{font-size:14px;line-height:1.35;overflow-wrap:anywhere}
.service-picker-current-text small{font-size:11px;color:var(--muted-color,#91a0ba);line-height:1.4}
.service-picker-chevron{font-size:20px;color:#91adff;transition:transform .18s}
.service-picker.is-open .service-picker-chevron{transform:rotate(180deg)}
.service-picker-menu{position:absolute;top:calc(100% + 8px);left:0;right:0;z-index:100;overflow:hidden;border:1px solid #2c3d5c;border-radius:14px;background:#101827;box-shadow:0 18px 48px rgba(0,0,0,.45)}
.service-picker-menu[hidden]{display:none}
.service-picker-menu-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 14px;border-bottom:1px solid rgba(148,163,184,.13);font-size:12px;font-weight:800;color:#e5edff}
.service-picker-menu-head span{font-size:11px;font-weight:500;color:#91a0ba}
.service-picker-options{max-height:290px;overflow-y:auto;padding:6px;overscroll-behavior:contain}
.service-picker-option{width:100%;display:flex;align-items:center;gap:11px;padding:10px;border:1px solid transparent;border-radius:10px;background:transparent;color:#e7edfa;text-align:left;cursor:pointer;transition:background .15s,border-color .15s}
.service-picker-option:hover{background:rgba(76,112,210,.13);border-color:rgba(104,139,255,.24)}
.service-picker-option.is-selected{background:rgba(64,103,224,.2);border-color:rgba(104,139,255,.48)}
.service-picker-option-icon{width:36px;height:36px;flex:0 0 36px;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:10px;background:#202d46;color:#a9bdff;font-size:14px;font-weight:800}
.service-picker-option-text{min-width:0;flex:1;display:block;font-size:12px;font-weight:700;overflow-wrap:anywhere}
.service-picker-option-check{color:#82a2ff;font-size:16px}
.service-picker-empty{padding:22px 12px;text-align:center;color:#98a7bf;font-size:12px}
.service-picker-empty[hidden]{display:none}
@media(max-width:600px){.service-picker-menu{max-height:55vh}.service-picker-options{max-height:45vh}}


/* FIX: dropdown negara tidak bertabrakan dengan operator */
#servicePicker { position: relative; z-index: 20; }
#servicePicker.is-open { z-index: 100; }

#countryPicker { position: relative; z-index: 20; }
#countryPicker.is-open { z-index: 1000; }
#countryPicker.is-open .service-picker-menu {
    z-index: 1001;
    background: #101827;
    opacity: 1;
}
#countryPicker .service-picker-options {
    background: #101827;
}
#operatorPicker { position: relative; z-index: 10; }
#operatorPicker.is-open { z-index: 100; }
#operatorPicker.is-open .service-picker-menu {
    z-index: 101;
    background: #101827;
}


/* FIX: dropdown tidak boleh menutupi sidebar mobile */
.service-picker,
#servicePicker,
#countryPicker,
#operatorPicker {
    z-index: 1 !important;
}
.service-picker.is-open,
#servicePicker.is-open,
#countryPicker.is-open,
#operatorPicker.is-open {
    z-index: 2 !important;
}
#servicePicker.is-open .service-picker-menu,
#countryPicker.is-open .service-picker-menu,
#operatorPicker.is-open .service-picker-menu {
    z-index: 3 !important;
}



/* Perbaikan isi dropdown negara dan operator pada tema LIGHT */
html[data-theme="light"] .picker-search-wrap,
html[data-theme="light"] .service-picker-menu .picker-search-wrap {
    background: #ffffff !important;
}

html[data-theme="light"] .service-picker-menu input,
html[data-theme="light"] .service-picker-menu input[type="search"],
html[data-theme="light"] #countryPickerSearch,
html[data-theme="light"] #operatorPickerSearch {
    background: #f8faff !important;
    color: #172033 !important;
    border-color: #d7dfed !important;
    caret-color: #172033 !important;
}

html[data-theme="light"] .service-picker-menu input::placeholder {
    color: #8491a7 !important;
}

html[data-theme="light"] .service-picker-options {
    background: #ffffff !important;
}

html[data-theme="light"] .service-picker-option-text,
html[data-theme="light"] .service-picker-option-text strong,
html[data-theme="light"] .service-picker-option-text small {
    color: #243047 !important;
}

html[data-theme="light"] .service-picker-option-icon {
    background: #edf2ff !important;
    color: #405fe5 !important;
}

html[data-theme="light"] .service-picker-option-check {
    color: #405fe5 !important;
}

/* Jika tema ditetapkan pada body, bukan html */
body[data-theme="light"] .service-picker-menu input,
body[data-theme="light"] #countryPickerSearch,
body[data-theme="light"] #operatorPickerSearch {
    background: #f8faff !important;
    color: #172033 !important;
    border-color: #d7dfed !important;
}

body[data-theme="light"] .service-picker-options {
    background: #ffffff !important;
}

/* Dropdown mengikuti tema aplikasi: LIGHT */
html[data-theme="light"] .service-picker-trigger,
body[data-theme="light"] .service-picker-trigger {
    background: linear-gradient(135deg, #ffffff, #f1f5ff) !important;
    color: #172033 !important;
    border-color: #d6deee !important;
}
html[data-theme="light"] .service-picker-current-text strong,
body[data-theme="light"] .service-picker-current-text strong {
    color: #172033 !important;
}
html[data-theme="light"] .service-picker-current-text small,
body[data-theme="light"] .service-picker-current-text small {
    color: #64748b !important;
}
html[data-theme="light"] .service-picker-menu,
body[data-theme="light"] .service-picker-menu {
    background: #ffffff !important;
    border-color: #dbe3f0 !important;
    box-shadow: 0 18px 40px rgba(15, 23, 42, .14) !important;
}
html[data-theme="light"] .service-picker-menu-head,
body[data-theme="light"] .service-picker-menu-head {
    color: #172033 !important;
    border-bottom-color: #e2e8f0 !important;
}
html[data-theme="light"] .service-picker-menu-head span,
body[data-theme="light"] .service-picker-menu-head span {
    color: #64748b !important;
}
html[data-theme="light"] .service-picker-option,
body[data-theme="light"] .service-picker-option {
    color: #243047 !important;
}
html[data-theme="light"] .service-picker-option:hover,
body[data-theme="light"] .service-picker-option:hover {
    background: #eff4ff !important;
    border-color: #d7e2ff !important;
}
html[data-theme="light"] .service-picker-option.is-selected,
body[data-theme="light"] .service-picker-option.is-selected {
    background: #e5edff !important;
    border-color: #9bb6ff !important;
}
html[data-theme="light"] .service-picker-option-icon,
body[data-theme="light"] .service-picker-option-icon {
    background: #edf2ff !important;
    color: #405fe5 !important;
}
html[data-theme="light"] .service-picker-empty,
body[data-theme="light"] .service-picker-empty {
    color: #64748b !important;
}
html[data-theme="light"] .service-picker-chevron,
body[data-theme="light"] .service-picker-chevron {
    color: #405fe5 !important;
}

</style>

<style>
.otp-country-services{display:flex;flex-direction:column}
.otp-country-service{padding:14px 0;border-bottom:1px solid var(--border-color,rgba(255,255,255,.09))}
.otp-country-service:last-child{border-bottom:0}
.otp-country-service-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}
.otp-country-service-head strong{font-size:14px;color:var(--text-color,inherit)}
.otp-country-average{font-size:12px;color:var(--muted-color,#999);white-space:nowrap}
.otp-country-average b{color:#ffb84d}
.otp-country-badges{display:flex;flex-wrap:wrap;gap:7px}
.otp-country-badge{display:inline-flex;align-items:center;gap:4px;padding:6px 10px;border:1px solid var(--border-color,rgba(255,255,255,.12));border-radius:999px;background:rgba(255,255,255,.035);font-size:11px;color:var(--text-color,inherit)}
.otp-country-badge b{color:#ffbf47;font-weight:700}
.otp-country-badge.is-best b{color:#31dba0}
.otp-country-badge.is-low{color:#ff7777}
.otp-country-badge.is-low b{color:#ff6666}
@media(max-width:600px){.otp-country-service-head{align-items:flex-start}.otp-country-badges{gap:6px}.otp-country-badge{font-size:10px;padding:6px 8px}}
</style>



@if(setting('otp_notice_enabled', '1') === '1' && trim((string) setting('otp_notice_message', '')) !== '')
    <section class="otp-admin-notice" role="status">
        <div class="otp-admin-notice-icon" aria-hidden="true">ⓘ</div>
        <div class="otp-admin-notice-content">
            <h3>{{ setting('otp_notice_title', 'Informasi Penting') }}</h3>
            <p>{{ setting('otp_notice_message') }}</p>
        </div>
    </section>
@endif

<style>
.otp-admin-notice {
    display:flex;
    align-items:flex-start;
    gap:14px;
    margin:0 0 22px;
    padding:17px 19px;
    border:1px solid #bfdbfe;
    border-left:4px solid #3b82f6;
    border-radius:14px;
    background:linear-gradient(120deg,#eff6ff,#f8fbff);
    color:#1e3a5f;
    box-shadow:0 5px 18px rgba(37,99,235,.06);
}
.otp-admin-notice-icon {
    display:flex;
    align-items:center;
    justify-content:center;
    flex:0 0 34px;
    width:34px;
    height:34px;
    border-radius:10px;
    background:#dbeafe;
    color:#2563eb;
    font-size:23px;
    font-weight:800;
}
.otp-admin-notice-content {min-width:0}
.otp-admin-notice-content h3 {
    margin:1px 0 6px;
    font-size:15px;
    font-weight:800;
    color:inherit;
}
.otp-admin-notice-content p {
    margin:0;
    font-size:13px;
    line-height:1.75;
    white-space:pre-line;
    overflow-wrap:anywhere;
    color:inherit;
}
html.dark .otp-admin-notice,
body.dark .otp-admin-notice,
html.dark-mode .otp-admin-notice,
body.dark-mode .otp-admin-notice,
html[data-theme="dark"] .otp-admin-notice,
body[data-theme="dark"] .otp-admin-notice,
[data-bs-theme="dark"] .otp-admin-notice {
    background:linear-gradient(120deg,#111e35,#101827);
    border-color:#294a7c;
    border-left-color:#5685ff;
    color:#dbeafe;
    box-shadow:0 5px 18px rgba(0,0,0,.12);
}
html.dark .otp-admin-notice-icon,
body.dark .otp-admin-notice-icon,
html.dark-mode .otp-admin-notice-icon,
body.dark-mode .otp-admin-notice-icon,
html[data-theme="dark"] .otp-admin-notice-icon,
body[data-theme="dark"] .otp-admin-notice-icon,
[data-bs-theme="dark"] .otp-admin-notice-icon {
    background:#1d3358;
    color:#8fb0ff;
}
@media(max-width:600px) {
    .otp-admin-notice {padding:14px;gap:11px}
    .otp-admin-notice-icon {flex-basis:30px;width:30px;height:30px}
}
</style>

<div class="page-intro"><div><h2>Temukan layananmu</h2><p class="muted">Pilih layanan, negara, dan operator sesuai ketersediaan.</p></div><div class="pill">Markup aktif {{ $markup }}%</div></div>
@if($error)<div class="alert error">Layanan sedang belum tersedia. Silakan coba kembali beberapa saat lagi.</div>@endif
<div class="order-layout"><div class="panel order-form"><h3>Konfigurasi order</h3><form method="POST" action="{{ route('order.store') }}" id="orderForm">@csrf<label>Cari layanan</label><input id="serviceSearch" placeholder="Cari WhatsApp, Telegram..." autocomplete="off"><label>Layanan</label>
<div class="service-picker" id="servicePicker">
    <button type="button" class="service-picker-trigger" id="servicePickerTrigger"
            aria-expanded="false" aria-controls="servicePickerList">
        <span class="service-picker-current-icon" id="servicePickerCurrentIcon">✦</span>
        <span class="service-picker-current-text">
            <strong id="servicePickerCurrentName">Pilih layanan</strong>
            <small id="servicePickerCurrentHint">Pilih layanan OTP yang kamu butuhkan</small>
        </span>
        <span class="service-picker-chevron">⌄</span>
    </button>
    <div class="service-picker-menu" id="servicePickerMenu" hidden>
        <div class="service-picker-menu-head">Daftar layanan <span id="servicePickerCount"></span></div>
        <div class="service-picker-options" id="servicePickerList" role="listbox" aria-label="Daftar layanan"></div>
        <div class="service-picker-empty" id="servicePickerEmpty" hidden>Layanan tidak ditemukan.</div>
    </div>
</div>
<select name="service_id" id="service" class="service-native-select" aria-hidden="true" tabindex="-1"><option value="">Pilih layanan</option>@foreach($services as $s)<option value="{{ $s['service_id'] ?? $s['slug'] ?? $s['id'] ?? '' }}" data-logo="{{ $s['service_image'] ?? $s['image'] ?? '' }}">{{ $s['name'] ?? $s['service_name'] ?? $s['slug'] ?? 'Layanan' }}</option>@endforeach</select>
<div id="selectedServiceLogo" style="display:flex;align-items:center;gap:10px;margin:10px 0">
    <img id="selectedServiceLogoImg" alt="Logo layanan" style="width:38px;height:38px;object-fit:contain;border-radius:8px;display:none">
    <span id="selectedServiceLogoName" style="font-size:13px;opacity:.8">Pilih layanan untuk melihat logo</span>
</div>
<label>Negara & server</label>

<div class="service-picker country-picker" id="countryPicker">
    <button type="button" class="service-picker-trigger" id="countryPickerTrigger" aria-expanded="false" aria-controls="countryPickerMenu">
        <span class="service-picker-current-icon" id="countryPickerIcon">◎</span>
        <span class="service-picker-current-text">
            <strong id="countryPickerName">Pilih negara</strong>
            <small id="countryPickerHint">Pilih negara atau server OTP</small>
        </span>
        <span class="service-picker-chevron">⌄</span>
    </button>
    <div class="service-picker-menu" id="countryPickerMenu" hidden>
        <div class="picker-search-wrap"><input type="search" id="countryPickerSearch" placeholder="Cari negara..." autocomplete="off" aria-label="Cari negara"></div>
        <div class="service-picker-menu-head">Negara &amp; server <span id="countryPickerCount"></span></div>
        <div class="service-picker-options" id="countryPickerList" role="listbox" aria-label="Daftar negara"></div>
        <div class="service-picker-empty" id="countryPickerEmpty" hidden>Negara tidak ditemukan.</div>
    </div>
<select name="country_id" id="country" class="service-native-select" required>
    <option value="">Pilih negara</option>
    @foreach($countries as $c)
        @php
            $countryId = $c['id'] ?? $c['country_id'] ?? '';
            $countryLabel = $c['name'] ?? $c['country_name'] ?? $c['country'] ?? null;
            $countryIso = $c['iso'] ?? $c['iso_code'] ?? $c['country_iso'] ?? null;
        @endphp
        @if($countryId !== '' && $countryLabel)
            <option value="{{ $countryId }}">{{ $countryLabel }}{{ $countryIso ? ' ('.$countryIso.')' : '' }}</option>
        @endif
    @endforeach
</select></div>

<div id="indonesiaPriceList" class="muted tiny" style="margin-top:8px;line-height:1.8">
    Pilih layanan untuk melihat harga jual Indonesia.
</div>
<label>Operator / server (jika didukung)</label>
<div class="service-picker" id="operatorPicker">
    <button type="button" class="service-picker-trigger" id="operatorPickerTrigger" aria-expanded="false" aria-controls="operatorPickerMenu">
        <span class="service-picker-current-icon" id="operatorPickerIcon">↗</span>
        <span class="service-picker-current-text">
            <strong id="operatorPickerName">Otomatis / random</strong>
            <small id="operatorPickerHint">Pilih operator jika tersedia</small>
        </span>
        <span class="service-picker-chevron">⌄</span>
    </button>
    <div class="service-picker-menu" id="operatorPickerMenu" hidden>
        <div class="picker-search-wrap"><input type="search" id="operatorPickerSearch" placeholder="Cari operator..." autocomplete="off" aria-label="Cari operator"></div>
        <div class="service-picker-menu-head">Pilih operator <span id="operatorPickerCount"></span></div>
        <div class="service-picker-options" id="operatorPickerList" role="listbox" aria-label="Daftar operator"></div>
        <div class="service-picker-empty" id="operatorPickerEmpty" hidden>Operator tidak ditemukan.</div>
    </div>
    <select name="operator" id="operatorSelect" class="service-native-select">
        <option value="random">Otomatis / random</option>
        @foreach(['telkomsel','indosat','axis','xl','smartfren'] as $op)
            <option value="{{ $op }}">{{ ucfirst($op) }}</option>
        @endforeach
    </select>
</div><div class="price-preview"><small>Estimasi harga jual</small><strong id="pricePreview">Pilih layanan dan negara</strong><small class="muted">Harga dapat berubah mengikuti stok upstream.</small></div><button class="btn primary full" @if(empty($prices)) disabled @endif>Pesan nomor <span>→</span></button></form></div>
<div class="panel otp-insights-panel">
    <div class="otp-insights-head">
        <div>
            <h3>Statistik Keberhasilan OTP</h3>
            <p class="muted">Peringkat negara berdasarkan layanan</p>
        </div>
        <span class="otp-insights-live"><span></span> Statistik OTP</span>
    </div>

    @php
        $serviceStats = array_slice($insights['services'] ?? [], 0, 4);
    @endphp

    @if(count($serviceStats))
        <div class="otp-country-services">
            @foreach($serviceStats as $service)
                @php
                    $countries = $service['countries'] ?? [];
                    usort($countries, fn($a, $b) => (float)($b['success_rate'] ?? 0) <=> (float)($a['success_rate'] ?? 0));
                    $topCountries = array_slice($countries, 0, 3);
                    $lowestCountry = count($countries) ? $countries[count($countries) - 1] : null;
                    $average = max(0, min(100, (float)($service['success_rate'] ?? 0)));
                @endphp

                <div class="otp-country-service">
                    <div class="otp-country-service-head">
                        <strong>{{ $service['service_name'] ?? 'Layanan OTP' }}</strong>
                        <span class="otp-country-average">
                            rata-rata <b>{{ rtrim(rtrim(number_format($average, 1, '.', ''), '0'), '.') }}%</b>
                        </span>
                    </div>

                    <div class="otp-country-badges">
                        @foreach($topCountries as $index => $country)
                            @php $countryRate = max(0, min(100, (float)($country['success_rate'] ?? 0))); @endphp
                            <span class="otp-country-badge {{ $index === 0 ? 'is-best' : '' }}">
                                @if($index === 0) ★ @endif
                                {{ $country['country'] ?? 'Negara' }}
                                <b>{{ rtrim(rtrim(number_format($countryRate, 1, '.', ''), '0'), '.') }}%</b>
                            </span>
                        @endforeach

                        @if($lowestCountry)
                            @php $lowRate = max(0, min(100, (float)($lowestCountry['success_rate'] ?? 0))); @endphp
                            <span class="otp-country-badge is-low">
                                ⚠ hindari {{ $lowestCountry['country'] ?? 'Negara' }}
                                <b>{{ rtrim(rtrim(number_format($lowRate, 1, '.', ''), '0'), '.') }}%</b>
                            </span>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>

        <p class="muted otp-insights-foot">
            Peringkat berdasarkan statistik historis. Keberhasilan OTP berikutnya tidak dijamin.
        </p>
    @else
        <div class="otp-insights-empty">
            <strong>Statistik belum tersedia</strong>
            <p class="muted">Data negara akan ditampilkan saat tersedia.</p>
        </div>
    @endif
</div></div>
<script>

/* DIGISTORE_ORDER_AJAX_SAFE_INIT */
(function () {
    // Bersihkan listener document dari kunjungan Order OTP sebelumnya.
    if (window.__digistoreOrderCleanup) {
        window.__digistoreOrderCleanup();
    }

    const __orderDocumentCleanups = [];

    function addOrderDocumentListener(type, handler, options) {
        document.addEventListener(type, handler, options);

        __orderDocumentCleanups.push(function () {
            document.removeEventListener(type, handler, options);
        });
    }

    window.__digistoreOrderCleanup = function () {
        __orderDocumentCleanups.forEach(function (cleanup) {
            cleanup();
        });
        __orderDocumentCleanups.length = 0;
    };


@php
$priceData = array_map(function ($p) {
    return [
        'service_id' => (string) ($p['service_id'] ?? $p['id'] ?? ''),
        'country_id' => (string) ($p['country_id'] ?? ''),
        'selling_price' => (int) ($p['selling_price'] ?? ceil((float) ($p['price'] ?? 0) * (1 + (float) $markup / 100))),
    ];
}, $prices);
@endphp
const prices = @json($priceData);
const svc=document.getElementById('service'),cty=document.getElementById('country'),preview=document.getElementById('pricePreview');
function updatePrice(){
    const serviceId = String(svc.value).trim().toLowerCase();
    const countryId = String(cty.value).trim();
    const p = prices.find(x =>
        String(x.service_id).trim().toLowerCase() === serviceId &&
        String(x.country_id).trim() === countryId
    );

    preview.textContent = p
        ? 'Rp ' + Number(p.selling_price).toLocaleString('id-ID')
        : 'Harga belum tersedia untuk kombinasi ini';

    const list = document.getElementById('indonesiaPriceList');
    if (!list) return;

    if (!serviceId || !countryId) {
        list.textContent = 'Pilih layanan dan negara untuk melihat harga jual bermargin.';
    } else if (p) {
        list.textContent = 'Harga jual ' + cty.options[cty.selectedIndex].text
            + ': Rp ' + Number(p.selling_price).toLocaleString('id-ID');
    } else {
        list.textContent = 'Harga layanan ini belum tersedia untuk negara yang dipilih.';
    }
}
svc.addEventListener('change',updatePrice);cty.addEventListener('change',updatePrice);
document.getElementById('serviceSearch').addEventListener('input',e=>{
    const q=e.target.value.toLowerCase().trim();
    [...svc.options].forEach((o,i)=>{
        if(i>0) o.hidden=!o.text.toLowerCase().includes(q);
    });
});

const countrySearch = document.getElementById('countrySearch');
const countrySearchInfo = document.getElementById('countrySearchInfo');

if (countrySearch) countrySearch.addEventListener('input', () => {
    const q = countrySearch.value.toLocaleLowerCase('id-ID').trim();
    let shown = 0;

    [...cty.options].forEach((option, index) => {
        if (index === 0) {
            option.hidden = false;
            return;
        }

        const match = option.text.toLocaleLowerCase('id-ID').includes(q);
        option.hidden = !match;
        if (match) shown++;
    });

    countrySearchInfo.textContent = q
        ? (shown ? shown + ' negara/server cocok dengan pencarian.' : 'Negara/server tidak ditemukan.')
        : 'Semua negara/server yang tersedia ditampilkan.';

    if (cty.selectedIndex > 0 && cty.options[cty.selectedIndex].hidden) {
        cty.value = '';
        updatePrice();
    }
});

const serviceLogoMap = @json($serviceLogos ?? []);
const serviceSelect = document.getElementById('service');
const serviceLogoImg = document.getElementById('selectedServiceLogoImg');
const serviceLogoName = document.getElementById('selectedServiceLogoName');

function updateSelectedServiceLogo() {
    const opt = serviceSelect.options[serviceSelect.selectedIndex];
    const id = opt ? opt.value : '';
    const logo = serviceLogoMap[id] || (opt ? opt.dataset.logo : '') || '';
    serviceLogoName.textContent = opt && opt.value ? opt.textContent.trim() : 'Pilih layanan untuk melihat logo';
    if (logo && /^https?:\/\//i.test(logo)) {
        serviceLogoImg.src = logo;
        serviceLogoImg.style.display = 'block';
        serviceLogoImg.onerror = () => { serviceLogoImg.style.display = 'none'; };
    } else {
        serviceLogoImg.removeAttribute('src');
        serviceLogoImg.style.display = 'none';
    }
}
serviceSelect.addEventListener('change', updateSelectedServiceLogo);
updateSelectedServiceLogo();

// Custom dropdown: pilihan tetap disimpan pada select asli untuk order.store.
(function () {
    const picker = document.getElementById('servicePicker');
    const trigger = document.getElementById('servicePickerTrigger');
    const menu = document.getElementById('servicePickerMenu');
    const list = document.getElementById('servicePickerList');
    const currentIcon = document.getElementById('servicePickerCurrentIcon');
    const currentName = document.getElementById('servicePickerCurrentName');
    const currentHint = document.getElementById('servicePickerCurrentHint');
    const count = document.getElementById('servicePickerCount');
    const empty = document.getElementById('servicePickerEmpty');
    const search = document.getElementById('serviceSearch');

    if (!picker || !trigger || !menu || !list || !svc) return;

    function logoFor(option) {
        const map = typeof serviceLogoMap !== 'undefined' ? serviceLogoMap : {};
        return map[option.value] || option.dataset.logo || '';
    }

    function setIcon(container, option, small) {
        container.replaceChildren();
        const logo = logoFor(option);
        if (logo && /^https?:\/\//i.test(logo)) {
            const img = document.createElement('img');
            img.src = logo;
            img.alt = '';
            img.loading = 'lazy';
            img.onerror = () => {
                container.replaceChildren();
                container.textContent = (option.textContent.trim().charAt(0) || '✦').toUpperCase();
            };
            container.appendChild(img);
        } else {
            container.textContent = (option.textContent.trim().charAt(0) || '✦').toUpperCase();
        }
    }

    function syncCurrent() {
        const option = svc.options[svc.selectedIndex];
        if (!option || !option.value) {
            currentIcon.textContent = '✦';
            currentName.textContent = 'Pilih layanan';
            currentHint.textContent = 'Pilih layanan OTP yang kamu butuhkan';
            return;
        }
        setIcon(currentIcon, option, false);
        currentName.textContent = option.textContent.trim();
        currentHint.textContent = 'Layanan dipilih · siap dikonfigurasi';
    }

    function renderOptions() {
        const q = (search.value || '').toLocaleLowerCase('id-ID').trim();
        list.replaceChildren();
        let visible = 0;

        Array.from(svc.options).forEach(option => {
            if (!option.value || option.hidden || !option.textContent.trim()) return;
            if (!option.textContent.toLocaleLowerCase('id-ID').includes(q)) return;

            visible++;
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'service-picker-option' +
                (option.value === svc.value ? ' is-selected' : '');
            button.setAttribute('role', 'option');
            button.setAttribute('aria-selected', option.value === svc.value ? 'true' : 'false');

            const icon = document.createElement('span');
            icon.className = 'service-picker-option-icon';
            setIcon(icon, option, true);

            const name = document.createElement('span');
            name.className = 'service-picker-option-text';
            name.textContent = option.textContent.trim();

            const check = document.createElement('span');
            check.className = 'service-picker-option-check';
            check.textContent = option.value === svc.value ? '✓' : '';

            button.append(icon, name, check);
            button.addEventListener('click', () => {
                svc.value = option.value;
                svc.dispatchEvent(new Event('change', { bubbles: true }));
                syncCurrent();
                renderOptions();
                closeMenu();
            });
            list.appendChild(button);
        });

        count.textContent = visible + ' layanan';
        empty.hidden = visible !== 0;
    }

    function openMenu() {
        menu.hidden = false;
        picker.classList.add('is-open');
        trigger.setAttribute('aria-expanded', 'true');
        renderOptions();
    }

    function closeMenu() {
        menu.hidden = true;
        picker.classList.remove('is-open');
        trigger.setAttribute('aria-expanded', 'false');
    }

    trigger.addEventListener('click', () => menu.hidden ? openMenu() : closeMenu());
    search.addEventListener('input', renderOptions);
    svc.addEventListener('change', () => {
        syncCurrent();
        renderOptions();
    });

    addOrderDocumentListener('click', event => {
        if (!picker.contains(event.target)) closeMenu();
    });

    addOrderDocumentListener('keydown', event => {
        if (event.key === 'Escape' && !menu.hidden) {
            closeMenu();
            trigger.focus();
        }
    });

    const form = document.getElementById('orderForm');
    if (form) {
        form.addEventListener('submit', event => {
            if (!svc.value) {
                event.preventDefault();
                openMenu();
                trigger.focus();
                currentHint.textContent = 'Pilih layanan terlebih dahulu';
            }
        });
    }

    syncCurrent();
    renderOptions();
})();


// Custom dropdown negara dan operator; select asli tetap menjadi sumber nilai form.
(function () {
    function setupPicker(cfg) {
        const select = document.getElementById(cfg.select);
        const root = document.getElementById(cfg.root);
        const trigger = document.getElementById(cfg.trigger);
        const menu = document.getElementById(cfg.menu);
        const list = document.getElementById(cfg.list);
        const icon = document.getElementById(cfg.icon);
        const name = document.getElementById(cfg.name);
        const hint = document.getElementById(cfg.hint);
        const search = document.getElementById(cfg.search);
        const count = document.getElementById(cfg.count);
        const empty = document.getElementById(cfg.empty);
        if (!select || !root || !trigger || !menu || !list) return;

        function sync() {
            const opt = select.options[select.selectedIndex];
            name.textContent = opt && opt.value ? opt.textContent.trim() : cfg.placeholder;
            hint.textContent = opt && opt.value ? cfg.selectedHint : cfg.defaultHint;
            icon.textContent = cfg.symbol;
            if (opt && opt.value && cfg.operator) {
                const symbols = {random:'↗',telkomsel:'T',indosat:'I',axis:'A',xl:'XL',smartfren:'S'};
                icon.textContent = symbols[opt.value] || cfg.symbol;
            }
        }

        function render() {
            const q = (search ? search.value : '').toLocaleLowerCase('id-ID').trim();
            list.replaceChildren();
            let total = 0;
            Array.from(select.options).forEach(opt => {
                if (!opt.value || opt.hidden) return;
                if (!opt.textContent.toLocaleLowerCase('id-ID').includes(q)) return;
                total++;
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'service-picker-option' + (opt.value === select.value ? ' is-selected' : '');
                btn.setAttribute('role','option');
                btn.setAttribute('aria-selected', opt.value === select.value ? 'true' : 'false');

                const ico = document.createElement('span');
                ico.className = 'service-picker-option-icon';
                if (cfg.operator) {
                    const symbols = {random:'↗',telkomsel:'T',indosat:'I',axis:'A',xl:'XL',smartfren:'S'};
                    ico.textContent = symbols[opt.value] || opt.textContent.trim().charAt(0).toUpperCase();
                } else {
                    ico.textContent = (opt.textContent.trim().match(/\(([^)]+)\)/)?.[1] || opt.textContent.trim().charAt(0)).toUpperCase();
                }

                const label = document.createElement('span');
                label.className = 'service-picker-option-text';
                label.textContent = opt.textContent.trim();
                const check = document.createElement('span');
                check.className = 'service-picker-option-check';
                check.textContent = opt.value === select.value ? '✓' : '';
                btn.append(ico,label,check);
                btn.addEventListener('click', () => {
                    select.value = opt.value;
                    select.dispatchEvent(new Event('change',{bubbles:true}));
                    sync();
                    render();
                    close();
                });
                list.appendChild(btn);
            });
            count.textContent = total + (cfg.operator ? ' operator' : ' negara');
            empty.hidden = total !== 0;
        }

        function open() {
            menu.hidden = false;
            root.classList.add('is-open');
            trigger.setAttribute('aria-expanded','true');
            render();
            if (search) search.focus();
        }
        function close() {
            menu.hidden = true;
            root.classList.remove('is-open');
            trigger.setAttribute('aria-expanded','false');
        }

        trigger.addEventListener('click', () => menu.hidden ? open() : close());
        if (search) search.addEventListener('input', render);
        select.addEventListener('change', () => { sync(); render(); });
        addOrderDocumentListener('click', e => { if (!root.contains(e.target)) close(); });
        addOrderDocumentListener('keydown', e => {
            if (e.key === 'Escape' && !menu.hidden) { close(); trigger.focus(); }
        });

        if (!cfg.operator) {
            const countrySearch = document.getElementById('countrySearch');
            if (countrySearch) countrySearch.addEventListener('input', render);
        }

        sync();
        render();
    }

    setupPicker({
        select:'country', root:'countryPicker', trigger:'countryPickerTrigger',
        menu:'countryPickerMenu', list:'countryPickerList', icon:'countryPickerIcon',
        name:'countryPickerName', hint:'countryPickerHint', search:'countryPickerSearch',
        count:'countryPickerCount', empty:'countryPickerEmpty', symbol:'◎',
        placeholder:'Pilih negara', defaultHint:'Pilih negara atau server OTP',
        selectedHint:'Negara dipilih · harga menyesuaikan ketersediaan', operator:false
    });
    setupPicker({
        select:'operatorSelect', root:'operatorPicker', trigger:'operatorPickerTrigger',
        menu:'operatorPickerMenu', list:'operatorPickerList', icon:'operatorPickerIcon',
        name:'operatorPickerName', hint:'operatorPickerHint', search:'operatorPickerSearch',
        count:'operatorPickerCount', empty:'operatorPickerEmpty', symbol:'↗',
        placeholder:'Pilih operator', defaultHint:'Pilih operator jika tersedia',
        selectedHint:'Operator dipilih', operator:true
    });
})();


// Unified dropdown interaction fix
(function () {
    const groups = [
        {root: 'servicePicker', trigger: 'servicePickerTrigger', menu: 'servicePickerMenu'},
        {root: 'countryPicker', trigger: 'countryPickerTrigger', menu: 'countryPickerMenu'},
        {root: 'operatorPicker', trigger: 'operatorPickerTrigger', menu: 'operatorPickerMenu'}
    ];

    function closeOthers(currentRoot) {
        groups.forEach(group => {
            if (group.root === currentRoot) return;
            const root = document.getElementById(group.root);
            const trigger = document.getElementById(group.trigger);
            const menu = document.getElementById(group.menu);
            if (root) root.classList.remove('is-open');
            if (menu) menu.hidden = true;
            if (trigger) trigger.setAttribute('aria-expanded', 'false');
        });
    }

    groups.forEach(group => {
        const root = document.getElementById(group.root);
        const trigger = document.getElementById(group.trigger);
        if (!root || !trigger) return;

        // Capture phase: close other menus before the existing toggle handler runs.
        trigger.addEventListener('click', function () {
            closeOthers(group.root);
        }, true);
    });
})();


})();
</script>
@endsection
