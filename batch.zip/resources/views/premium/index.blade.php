@extends('layouts.app')

@section('content')
<div class="premium-page">
    <div class="premium-heading">
        <div>
            <h1>Aplikasi Premium</h1>
            <p>Pilih aplikasi dan lihat paket yang tersedia.</p>
        </div>
        <a href="{{ route('premium.history') }}">Riwayat Pembelian</a>
    </div>

    @if($errors->has('premium'))
        <div class="premium-notice">{{ $errors->first('premium') }}</div>
    @endif

    <form method="GET" action="{{ route('premium.index') }}" class="premium-search">
        <input type="search" name="q" value="{{ $search }}"
               placeholder="Cari aplikasi premium..." aria-label="Cari aplikasi">
        <button type="submit">Cari</button>
    </form>

    @if($error)
        <div class="premium-notice">{{ $error }}</div>
    @elseif(empty($categories))
        <div class="premium-empty">Aplikasi tidak ditemukan.</div>
    @else
        @foreach($categories as $category)
            <section class="premium-category">
                <div class="premium-category-title">
                    @if(!empty($category['logo']))
                        <img class="premium-logo"
                             src="{{ $category['logo'] }}"
                             alt="{{ $category['app'] ?? 'Logo aplikasi' }}"
                             loading="eager" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex'">
                    @else
                        <span class="premium-logo-fallback">
                            {{ mb_strtoupper(mb_substr($category['app'] ?? 'A', 0, 1)) }}
                        </span>
                    @endif
                    <div>
                        <h2>{{ $category['app'] ?? 'Aplikasi' }}</h2>
                        <p>{{ (int) ($category['varian'] ?? count($category['items'] ?? [])) }} paket tersedia</p>
                    </div>
                </div>

                <div class="premium-grid">
                    @foreach(($category['items'] ?? []) as $item)
                        <article class="premium-card">
                            @if(!empty($item['logo']))
                                <img class="premium-card-logo"
                                     src="{{ $item['logo'] }}"
                                     alt="{{ $item['app'] ?? 'Logo aplikasi' }}"
                                     loading="eager" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex'">
                            @else
                                <span class="premium-card-logo premium-logo-fallback">
                                    {{ mb_strtoupper(mb_substr($item['app'] ?? 'A', 0, 1)) }}
                                </span>
                            @endif

                            <h3>{{ $item['nama'] ?? $item['app'] ?? 'Paket Premium' }}</h3>
                            @if(!empty($item['nama_penuh']))
                                <p class="premium-description">{{ $item['nama_penuh'] }}</p>
                            @endif
                            @if(!empty($item['durasi_hari']))
                                <p class="premium-meta">Durasi {{ (int) $item['durasi_hari'] }} hari</p>
                            @endif
                            <div class="premium-price">
                                {{ $item['harga_formatted'] ?? ('Rp ' . number_format((int) ($item['harga'] ?? 0), 0, ',', '.')) }}
                            </div>
                            @if(isset($item['stok']) && $item['stok'] !== null)
                                <p class="premium-meta">Stok: {{ (int) $item['stok'] }}</p>
                            @endif
                            <p class="premium-meta">
                                {{ !empty($item['butuh_email']) ? 'Memerlukan email tujuan' : 'Periksa keterangan paket sebelum memesan' }}
                            </p>

                            <form method="POST" action="{{ route('premium.purchase') }}" class="premium-buy-form">
                                @csrf
                                <input type="hidden" name="app_id" value="{{ (int) ($item['id'] ?? 0) }}">

                                @if(!empty($item['butuh_email']))
                                    <label class="premium-email-label">
                                        Email tujuan
                                        <input type="email" name="email" required maxlength="255"
                                               autocomplete="email" placeholder="nama@email.com">
                                    </label>
                                @endif

                                <button type="submit" class="premium-buy-button"
                                    @if(isset($item['stok']) && (int) $item['stok'] <= 0) disabled @endif>
                                    @if(isset($item['stok']) && (int) $item['stok'] <= 0)
                                        Stok Habis
                                    @else
                                        Beli Sekarang
                                    @endif
                                </button>
                            </form>
                        </article>
                    @endforeach
                </div>
            </section>
        @endforeach
    @endif
</div>
@endsection
