<?php $__env->startSection('title','Pengguna'); ?>
<?php $__env->startSection('crumb','ADMIN / USERS'); ?>
<?php $__env->startSection('heading','Pengelolaan Pengguna'); ?>

<style>
.users-mobile { display: none !important; }
.users-desktop { display: table !important; width: 100%; }
.users-desktop td { vertical-align: top; }
.users-actions { min-width: 210px; }
.users-actions form { margin: 8px 0; }
.users-actions input {
    box-sizing: border-box;
    max-width: 100%;
    padding: 10px;
    border-radius: 8px;
}
.users-actions button {
    min-height: 38px;
    padding: 9px 13px;
    border-radius: 8px;
    font: inherit;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
}
.users-mobile-card button { width: 100%; min-height: 42px; }
.users-mobile-card input { width: 100%; min-width: 0; }
.users-mobile-card .users-field {
    display: grid;
    grid-template-columns: 100px minmax(0, 1fr);
    gap: 8px;
    padding: 7px 0;
    font-size: 13px;
    overflow-wrap: anywhere;
}
.users-mobile-card .users-label { color: #94a3b8; }
.users-mobile-card {
    box-sizing: border-box;
    min-width: 0;
    padding: 16px;
    border: 1px solid #293449;
    border-radius: 14px;
    background: #111827;
    color: #e5e7eb;
    overflow-wrap: anywhere;
}
.users-mobile-card .users-card-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding-bottom: 12px;
    margin-bottom: 10px;
    border-bottom: 1px solid #293449;
}
.users-mobile-card .users-card-name { font-size: 16px; font-weight: 700; }
.users-mobile-card .users-card-email { color: #94a3b8; font-size: 12px; margin-top: 4px; }
.users-mobile-card .users-card-actions {
    margin-top: 14px;
    padding-top: 12px;
    border-top: 1px solid #293449;
}
.users-mobile-card .users-card-actions form { margin: 10px 0; }
.users-mobile-card .users-card-actions input {
    min-height: 42px;
    margin-bottom: 8px;
    font-size: 14px;
}
.users-mobile-card .users-card-actions button { margin-top: 4px; }
.users-mobile-list { display: none !important; }

@media (max-width: 768px) {
    .users-desktop { display: none !important; }
    .users-mobile-list {
        display: grid !important;
        grid-template-columns: minmax(0, 1fr);
        gap: 14px;
        width: 100%;
        box-sizing: border-box;
    }
}
</style>

<?php $__env->startSection('content'); ?>
<?php if(session('reset_password')): ?>
<div class="panel" style="margin-bottom:16px;padding:16px;border:1px solid #16a34a">
    <h3>Password baru berhasil dibuat</h3>
    <p>Pengguna: <b><?php echo e(session('reset_password.name')); ?></b> (<?php echo e(session('reset_password.email')); ?>)</p>
    <p>Berikan password ini secara pribadi kepada pemilik akun.</p>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <code id="temporary-reset-password" style="overflow-wrap:anywhere"><?php echo e(session('reset_password.password')); ?></code>
        <button type="button" class="btn" onclick="navigator.clipboard.writeText(document.getElementById('temporary-reset-password').innerText).then(()=>this.innerText='Tersalin').catch(()=>alert('Silakan salin password secara manual.'))">Salin Password</button>
    </div>
    <small>Catat password ini sekarang. Setelah halaman ditinggalkan, password tidak akan ditampilkan lagi.</small>
</div>
<?php endif; ?>

<div class="section-head">
    <div>
        <h2>Semua pengguna</h2>
        <p class="muted">Kelola akses akun dan pantau saldo.</p>
    </div>
</div>

<form method="GET" action="<?php echo e(route('admin.users')); ?>"
      style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:16px 0 20px">
    <div style="flex:1;min-width:220px;position:relative">
        <input
            type="search"
            name="search"
            value="<?php echo e($search ?? request('search', '')); ?>"
            placeholder="Cari nama atau email pengguna..."
            aria-label="Cari nama atau email pengguna"
            style="width:100%;box-sizing:border-box"
        >
    </div>
    <button class="btn" type="submit">⌕ Cari</button>
    <?php if(request()->filled('search')): ?>
        <a class="btn secondary" href="<?php echo e(route('admin.users')); ?>"
           style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center">
            Reset
        </a>
    <?php endif; ?>
</form>

<div class="panel table-wrap">
    
    <table class="users-desktop">
        <thead>
        <tr>
            <th>Pengguna</th>
            <th>Role</th>
            <th>Saldo</th>
            <th>Bergabung</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><b><?php echo e($u->name); ?></b><small><?php echo e($u->email); ?></small></td>
            <td><?php echo e($u->role); ?></td>
            <td><?php echo e(rupiah($u->balance)); ?></td>
            <td><?php echo e($u->created_at?->format('d/m/Y')); ?></td>
            <td><span class="status <?php echo e($u->is_blocked ? 'failed' : 'paid'); ?>"><?php echo e($u->is_blocked ? 'blocked' : 'active'); ?></span></td>
            <td class="users-actions">
                <?php if($u->role !== 'admin'): ?>
                <form method="POST" action="<?php echo e(route('admin.users.balance',$u)); ?>"
                      onsubmit="return confirm('Tambahkan saldo ke pengguna ini?')">
                    <?php echo csrf_field(); ?>
                    <select name="transaction_type" required>
                        <option value="admin_credit">Top Up Admin</option>
                        <option value="refund">Refund Saldo</option>
                    </select>
                    <input type="number" name="amount" min="1000" max="100000000"
                           step="1" required placeholder="Nominal Rp">
                    <input type="text" name="description" maxlength="200"
                           placeholder="Keterangan (opsional)">
                    <button class="btn" type="submit">＋ Proses Saldo</button>
                </form>
                <form method="POST" action="<?php echo e(route('admin.users.deduct-balance',$u)); ?>"
                      onsubmit="return confirm('Yakin kurangi saldo pengguna ini sesuai nominal yang dimasukkan?')">
                    <?php echo csrf_field(); ?>
                    <input type="number" name="amount" min="1" max="100000000"
                           step="1" required placeholder="Nominal pengurangan Rp">
                    <input type="text" name="description" maxlength="200"
                           required placeholder="Alasan pengurangan saldo">
                    <button class="btn danger" type="submit">− Kurangi Saldo</button>
                </form>

                <form method="POST" action="<?php echo e(route('admin.users.reset-password',$u)); ?>"
                      onsubmit="return confirm('Reset password <?php echo e(addslashes($u->name)); ?>? Password lama tidak akan berlaku lagi.')">
                    <?php echo csrf_field(); ?>
                    <button class="btn secondary" type="submit">↻ Reset Password</button>
                </form>
                <form method="POST" action="<?php echo e(route('admin.users.block',$u)); ?>"
                      onsubmit="return confirm('Ubah status akun ini?')">
                    <?php echo csrf_field(); ?>
                    <button class="btn <?php echo e($u->is_blocked ? 'secondary' : 'danger'); ?>" type="submit">
                        <?php echo e($u->is_blocked ? 'Buka blokir' : 'Blokir'); ?>

                    </button>
                </form>
                <?php else: ?>
                    <span class="muted">Akun administrator</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" class="empty">Belum ada pengguna.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>

    
    <div class="users-mobile-list">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="users-mobile-card">
            <div class="users-card-head">
                <div style="min-width:0">
                    <div class="users-card-name"><?php echo e($u->name); ?></div>
                    <div class="users-card-email"><?php echo e($u->email); ?></div>
                </div>
                <span class="status <?php echo e($u->is_blocked ? 'failed' : 'paid'); ?>">
                    <?php echo e($u->is_blocked ? 'blocked' : 'active'); ?>

                </span>
            </div>

            <div class="users-field">
                <span class="users-label">Role</span>
                <span><?php echo e($u->role); ?></span>
            </div>
            <div class="users-field">
                <span class="users-label">Saldo</span>
                <strong><?php echo e(rupiah($u->balance)); ?></strong>
            </div>
            <div class="users-field">
                <span class="users-label">Bergabung</span>
                <span><?php echo e($u->created_at?->format('d/m/Y')); ?></span>
            </div>

            <?php if($u->role !== 'admin'): ?>
            <div class="users-card-actions">
                <form method="POST" action="<?php echo e(route('admin.users.balance',$u)); ?>"
                      onsubmit="return confirm('Tambahkan saldo ke pengguna ini?')">
                    <?php echo csrf_field(); ?>
                    <label>Jenis transaksi</label>
                    <select name="transaction_type" required>
                        <option value="admin_credit">Top Up Admin</option>
                        <option value="refund">Refund Saldo</option>
                    </select>
                    <label>Nominal saldo (Rp)</label>
                    <input type="number" name="amount" min="1000" max="100000000"
                           step="1" required placeholder="Contoh: 10000">
                    <label>Keterangan (opsional)</label>
                    <input type="text" name="description" maxlength="200"
                           placeholder="Contoh: Refund atau koreksi saldo">
                    <button class="btn" type="submit">＋ Proses Saldo</button>
                </form>

                <form method="POST" action="<?php echo e(route('admin.users.deduct-balance',$u)); ?>"
                      onsubmit="return confirm('Yakin kurangi saldo pengguna ini sesuai nominal yang dimasukkan?')">
                    <?php echo csrf_field(); ?>
                    <label>Nominal pengurangan (Rp)</label>
                    <input type="number" name="amount" min="1" max="100000000"
                           step="1" required placeholder="Contoh: 5000">
                    <label>Alasan pengurangan</label>
                    <input type="text" name="description" maxlength="200"
                           required placeholder="Contoh: Koreksi saldo">
                    <button class="btn danger" type="submit">− Kurangi Saldo</button>
                </form>

                <form method="POST" action="<?php echo e(route('admin.users.reset-password',$u)); ?>"
                      onsubmit="return confirm('Reset password <?php echo e(addslashes($u->name)); ?>? Password lama tidak akan berlaku lagi.')">
                    <?php echo csrf_field(); ?>
                    <button class="btn secondary" type="submit">↻ Reset Password</button>
                </form>
                <form method="POST" action="<?php echo e(route('admin.users.block',$u)); ?>"
                      onsubmit="return confirm('Ubah status akun ini?')">
                    <?php echo csrf_field(); ?>
                    <button class="btn <?php echo e($u->is_blocked ? 'secondary' : 'danger'); ?>" type="submit">
                        <?php echo e($u->is_blocked ? 'Buka blokir akun' : 'Blokir akun'); ?>

                    </button>
                </form>
            </div>
            <?php endif; ?>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">Belum ada pengguna.</div>
        <?php endif; ?>
    </div>
</div>

<?php echo e($users->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/admin/users.blade.php ENDPATH**/ ?>