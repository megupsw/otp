<?php $__env->startSection('title','Top Up Pengguna'); ?>
<?php $__env->startSection('crumb','ADMIN / TOPUPS'); ?>
<?php $__env->startSection('heading','Verifikasi Top Up'); ?>

<style>
.topup-mobile-list { display: none !important; }
.topup-desktop-table { display: table !important; width: 100%; }
.topup-admin-actions { min-width: 190px; }
.topup-admin-actions form { margin: 8px 0; }
.topup-admin-actions input {
    width: 100%; min-width: 0; box-sizing: border-box;
    padding: 10px; border-radius: 8px;
}
.topup-admin-actions button {
    min-height: 38px; padding: 9px 14px; border: 0;
    border-radius: 8px; font: inherit; font-size: 12px;
    font-weight: 700; cursor: pointer; color: white;
}
.topup-approve { background: #16a34a !important; color: #fff !important; }
.topup-reject { background: #dc2626 !important; color: #fff !important; }

@media (max-width: 768px) {
    .topup-desktop-table { display: none !important; }
    .topup-mobile-list {
        display: grid !important; grid-template-columns: minmax(0, 1fr);
        gap: 14px; width: 100%; box-sizing: border-box;
    }
    .topup-mobile-card {
        min-width: 0; padding: 15px; box-sizing: border-box;
        border: 1px solid #293449; border-radius: 14px;
        background: #111827; color: #e5e7eb; overflow-wrap: anywhere;
    }
    .topup-mobile-card .topup-card-head {
        display: flex; justify-content: space-between; align-items: center;
        gap: 10px; padding-bottom: 12px; margin-bottom: 10px;
        border-bottom: 1px solid #293449;
    }
    .topup-mobile-card .topup-amount { font-size: 21px; font-weight: 800; margin-top: 4px; }
    .topup-mobile-card .topup-detail {
        display: grid; grid-template-columns: 100px minmax(0, 1fr);
        gap: 8px; padding: 6px 0; font-size: 13px; line-height: 1.5;
    }
    .topup-mobile-card .topup-detail-label { color: #94a3b8; }
    .topup-mobile-card .topup-admin-actions {
        min-width: 0; width: 100%; margin-top: 12px;
        padding-top: 12px; border-top: 1px solid #293449;
    }
    .topup-mobile-card .topup-admin-actions form {
        display: grid; grid-template-columns: minmax(0, 1fr);
        gap: 9px; margin: 10px 0;
    }
    .topup-mobile-card .topup-admin-actions input {
        min-height: 42px; font-size: 14px;
    }
    .topup-mobile-card .topup-admin-actions button {
        width: 100%; min-height: 42px; font-size: 14px;
    }
    .topup-mobile-card .topup-proof-link {
        display: inline-block; padding: 10px 12px; margin: 6px 0;
        border-radius: 8px; background: #1d4ed8; color: #fff;
        text-decoration: none;
    }
}
</style>

<?php $__env->startSection('content'); ?>
<div class="panel" style="margin-bottom:18px;padding:18px">
    <h2 style="margin-top:0">Pengaturan Metode Top Up</h2>
    <p class="muted">Aktifkan atau nonaktifkan setiap metode secara terpisah. Pengaturan berlaku untuk tampilan pengguna dan permintaan baru.</p>

    <form method="POST" action="<?php echo e(route('admin.topups.methods')); ?>">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = [
            'topup_qris_enabled' => ['QRIS Manual', 'Pembayaran QRIS dengan verifikasi bukti oleh admin.'],
            'topup_gopay_enabled' => ['GoPay Otomatis', 'Pembayaran GoPay melalui integrasi PayHook yang sudah ada.'],
            'topup_shopeepay_enabled' => ['ShopeePay Otomatis', 'Pembayaran ShopeePay melalui integrasi PayHook yang sudah ada.'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label style="display:flex;align-items:center;gap:12px;padding:14px;margin:10px 0;border:1px solid var(--border,#293449);border-radius:12px;cursor:pointer">
                <input type="checkbox" name="<?php echo e($key); ?>" value="1"
                    <?php echo e((string) setting($key, '1') === '1' ? 'checked' : ''); ?>

                    style="width:20px;height:20px;flex-shrink:0">
                <span>
                    <strong style="display:block"><?php echo e($details[0]); ?></strong>
                    <small class="muted"><?php echo e($details[1]); ?></small>
                    <small style="display:block;margin-top:5px">
                        Status:
                        <?php if((string) setting($key, '1') === '1'): ?>
                            <strong style="color:#16a34a">Aktif</strong>
                        <?php else: ?>
                            <strong style="color:#dc2626">Nonaktif</strong>
                        <?php endif; ?>
                    </small>
                </span>
            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="btn primary full" type="submit">Simpan Pengaturan Metode</button>
    </form>
</div>

<div class="panel table-wrap">

    
    <table class="topup-desktop-table">
        <thead>
        <tr>
            <th>Pengguna</th>
            <th>ID Pembayaran</th>
            <th>Nominal</th>
            <th>Referensi</th>
            <th>Status</th>
            <th>Bukti & Tindakan</th>
            <th>Waktu</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $topups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($t->user?->email ?? '-'); ?></td>
            <td><?php echo e($t->order_id); ?></td>
            <td><?php echo e(rupiah($t->amount)); ?></td>
            <td><?php echo e($t->payment_reference ?: '-'); ?></td>
            <td><span class="status <?php echo e($t->status); ?>"><?php echo e($t->status); ?></span></td>
            <td class="topup-admin-actions">
                <?php if($t->payment_type === 'manual_qris'): ?>
                    <?php if($t->proof_path): ?>
                        <a class="topup-proof-link" href="<?php echo e(route('admin.topups.proof', $t)); ?>" target="_blank" rel="noopener">Lihat bukti pembayaran</a>
                    <?php else: ?>
                        <small>Belum ada bukti</small>
                    <?php endif; ?>

                    <?php if($t->status === 'pending'): ?>
                        <?php if($t->proof_path): ?>
                            <form method="POST" action="<?php echo e(route('admin.topups.approve', $t)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="topup-approve" type="submit" onclick="return confirm('Pastikan dana cocok dengan mutasi rekening. Setujui top up?')">✓ Setujui</button>
                            </form>
                        <?php else: ?>
                            <small style="display:block;margin-top:8px">Menunggu bukti pembayaran.</small>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('admin.topups.reject', $t)); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="rejection_reason" required maxlength="500" placeholder="Alasan penolakan">
                            <button class="topup-reject" type="submit" onclick="return confirm('Tolak permintaan top up ini?')">✕ Tolak</button>
                        </form>
                    <?php endif; ?>
                    <?php if($t->rejection_reason): ?>
                        <small>Alasan: <?php echo e($t->rejection_reason); ?></small>
                    <?php endif; ?>
                <?php else: ?>
                    <small>Transaksi lama / <?php echo e($t->payment_type ?? 'metode sebelumnya'); ?></small>
                <?php endif; ?>
            </td>
            <td><?php echo e($t->created_at?->format('d/m/Y H:i')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" class="empty">Belum ada transaksi.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>

    
    <div class="topup-mobile-list">
        <?php $__empty_1 = true; $__currentLoopData = $topups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="topup-mobile-card">
            <div class="topup-card-head">
                <div style="min-width:0">
                    <div style="font-size:12px;color:var(--muted,#94a3b8)">NOMINAL TOP UP</div>
                    <div class="topup-amount"><?php echo e(rupiah($t->amount)); ?></div>
                </div>
                <span class="status <?php echo e($t->status); ?>"><?php echo e($t->status); ?></span>
            </div>

            <div class="topup-detail">
                <span class="topup-detail-label">Pengguna</span>
                <span><?php echo e($t->user?->email ?? '-'); ?></span>
            </div>
            <div class="topup-detail">
                <span class="topup-detail-label">ID pembayaran</span>
                <span class="topup-order"><?php echo e($t->order_id); ?></span>
            </div>
            <div class="topup-detail">
                <span class="topup-detail-label">Referensi</span>
                <span><?php echo e($t->payment_reference ?: '-'); ?></span>
            </div>
            <div class="topup-detail">
                <span class="topup-detail-label">Metode</span>
                <span><?php echo e($t->payment_type ?? 'Transaksi lama'); ?></span>
            </div>
            <div class="topup-detail">
                <span class="topup-detail-label">Waktu</span>
                <span><?php echo e($t->created_at?->format('d/m/Y H:i')); ?></span>
            </div>

            <?php if($t->payment_type === 'manual_qris'): ?>
            <div class="topup-admin-actions">
                <?php if($t->proof_path): ?>
                    <a class="topup-proof-link" href="<?php echo e(route('admin.topups.proof', $t)); ?>" target="_blank" rel="noopener">Lihat bukti pembayaran</a>
                <?php else: ?>
                    <small>Belum ada bukti pembayaran.</small>
                <?php endif; ?>

                <?php if($t->status === 'pending'): ?>
                    <?php if($t->proof_path): ?>
                    <form method="POST" action="<?php echo e(route('admin.topups.approve', $t)); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="topup-approve" type="submit" onclick="return confirm('Pastikan dana cocok dengan mutasi rekening. Setujui top up?')">✓ Setujui dan Tambah Saldo</button>
                    </form>
                    <?php else: ?>
                        <small style="display:block;margin-top:8px">Persetujuan tersedia setelah bukti terkirim.</small>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('admin.topups.reject', $t)); ?>">
                        <?php echo csrf_field(); ?>
                        <input name="rejection_reason" required maxlength="500" placeholder="Alasan penolakan">
                        <button class="topup-reject" type="submit" onclick="return confirm('Tolak permintaan top up ini?')">✕ Tolak Permintaan</button>
                    </form>
                <?php endif; ?>

                <?php if($t->rejection_reason): ?>
                    <small>Alasan: <?php echo e($t->rejection_reason); ?></small>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">Belum ada transaksi.</div>
        <?php endif; ?>
    </div>
</div>

<?php echo e($topups->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/admin/topups.blade.php ENDPATH**/ ?>