<?php $__env->startSection('title','Dashboard'); ?><?php $__env->startSection('crumb','OVERVIEW'); ?><?php $__env->startSection('heading','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<style>
/* Saldo dan top up di welcome banner */
.banner-wallet {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    width:100%;
    max-width:340px;
    margin:18px 0 17px;
    padding:0;
    border:0;
    border-radius:0;
    background:transparent;
    backdrop-filter:none;
}
.banner-wallet-info {
    display:flex;
    flex-direction:column;
    align-items:flex-start;
    justify-content:center;
    gap:5px;
    min-width:0;
}
.banner-wallet-label {
    color:#d4ddff;
    font-size:12px;
    line-height:1.3;
}
.banner-wallet-value {
    color:#fff;
    font-size:21px;
    line-height:1.2;
    font-weight:800;
    overflow-wrap:anywhere;
}
.banner-topup-btn {
    flex-shrink:0;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    min-height:42px;
    padding:10px 14px;
    border-radius:11px;
    background:#fff;
    color:#2446bd !important;
    font-size:12px;
    font-weight:800;
    text-decoration:none;
    white-space:nowrap;
    transition:transform .2s,background .2s;
}
.banner-topup-btn:hover {
    transform:translateY(-2px);
    background:#edf2ff;
}
@media(max-width:420px) {

    .banner-wallet-value {
        font-size:17px;
    }
    .banner-topup-btn {
        padding:9px 10px;
        font-size:11px;
    }
}

/* Layout saldo besar dan tombol sejajar */
.banner-wallet {
    width:100%;
    max-width:100%;
    margin:18px 0 15px;
}
.banner-wallet-info {
    display:flex;
    flex-direction:column;
    align-items:flex-start;
    gap:5px;
}
.banner-wallet-label {
    font-size:13px;
}
.banner-wallet-value {
    font-size:29px;
    line-height:1.2;
    font-weight:850;
    letter-spacing:-.5px;
}
.banner-actions {
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
}
.banner-actions .btn.primary {
    margin:0;
}
.banner-actions .banner-topup-btn {
    min-height:42px;
    padding:11px 15px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    background:#fff;
    color:#2446bd !important;
    border-radius:10px;
    font-size:12px;
    font-weight:800;
    text-decoration:none;
    white-space:nowrap;
}
@media(max-width:420px) {
    .banner-wallet-value {
        font-size:27px;
    }
    .banner-actions {
        gap:8px;
    }
    .banner-actions .btn.primary,
    .banner-actions .banner-topup-btn {
        padding:10px 12px;
        font-size:11px;
    }
}



/* DIGISTORE INTERACTIVE PREMIUM BANNER */

.user-interactive-banner {
    position:relative;
    isolation:isolate;
    overflow:hidden;
    background:linear-gradient(
        115deg,
        #172956 0%,
        #25449e 45%,
        #405ff0 100%
    ) !important;
    background-size:200% 200% !important;
    animation:bannerGradientMove 9s ease infinite,
              bannerEntrance .8s cubic-bezier(.2,.8,.2,1) both;
    transition:transform .35s ease,
               box-shadow .35s ease,
               filter .35s ease;
    box-shadow:0 14px 35px rgba(37,75,190,.20);
}

.user-interactive-banner::before {
    content:"";
    position:absolute;
    inset:-40% -70%;
    z-index:0;
    pointer-events:none;
    background:linear-gradient(
        110deg,
        transparent 40%,
        rgba(255,255,255,.10) 49%,
        rgba(255,255,255,.18) 50%,
        rgba(255,255,255,.06) 53%,
        transparent 62%
    );
    transform:translateX(-65%);
    animation:bannerShimmer 7s ease-in-out infinite;
}

.user-interactive-banner::after {
    content:"";
    position:absolute;
    width:230px;
    height:230px;
    right:-115px;
    top:-120px;
    border:1px solid rgba(255,255,255,.13);
    border-radius:50%;
    pointer-events:none;
    animation:bannerRingPulse 5s ease-in-out infinite;
}

.user-interactive-banner .banner-copy {
    position:relative;
    z-index:2;
    animation:bannerContentIn .8s .12s both;
}

.user-interactive-banner .banner-orb {
    z-index:1;
    animation:bannerOrbFloat 5s ease-in-out infinite;
    transition:transform .5s ease;
}

.user-interactive-banner .pill {
    transition:background .3s ease, border-color .3s ease;
}

.user-interactive-banner .pill::first-letter {
    color:#8dffcf;
}

.user-interactive-banner .banner-wallet-value {
    display:inline-block;
    animation:balanceAppear .7s .3s both;
    text-shadow:0 3px 15px rgba(255,255,255,.13);
}

.user-interactive-banner .banner-actions .btn,
.user-interactive-banner .banner-actions .banner-topup-btn {
    position:relative;
    overflow:hidden;
    transition:transform .25s ease,
               box-shadow .25s ease,
               background .25s ease;
}

.user-interactive-banner .banner-actions .btn.primary {
    box-shadow:0 5px 16px rgba(10,25,100,.20);
}

.user-interactive-banner .banner-actions .banner-topup-btn {
    box-shadow:0 5px 16px rgba(10,25,100,.12);
}

.user-interactive-banner .banner-actions .btn:hover,
.user-interactive-banner .banner-actions .banner-topup-btn:hover {
    transform:translateY(-3px);
    box-shadow:0 9px 23px rgba(8,20,80,.25);
}

.user-interactive-banner .banner-actions .btn:active,
.user-interactive-banner .banner-actions .banner-topup-btn:active {
    transform:scale(.96);
}

@keyframes bannerGradientMove {
    0%,100% { background-position:0% 50%; }
    50% { background-position:100% 50%; }
}

@keyframes bannerShimmer {
    0%,20% { transform:translateX(-65%); opacity:0; }
    35% { opacity:1; }
    65% { transform:translateX(65%); opacity:.8; }
    80%,100% { transform:translateX(65%); opacity:0; }
}

@keyframes bannerRingPulse {
    0%,100% { transform:scale(.92); opacity:.45; }
    50% { transform:scale(1.12); opacity:1; }
}

@keyframes bannerOrbFloat {
    0%,100% { transform:translateY(0) rotate(0deg); }
    50% { transform:translateY(-12px) rotate(4deg); }
}

@keyframes bannerEntrance {
    from { opacity:0; transform:translateY(15px); }
    to { opacity:1; transform:translateY(0); }
}

@keyframes bannerContentIn {
    from { opacity:0; transform:translateY(10px); }
    to { opacity:1; transform:translateY(0); }
}

@keyframes balanceAppear {
    from { opacity:0; transform:translateY(8px) scale(.96); }
    to { opacity:1; transform:translateY(0) scale(1); }
}

@media (hover:hover) {
    .user-interactive-banner:hover {
        transform:translateY(-3px);
        box-shadow:0 20px 45px rgba(37,75,190,.30);
    }

    .user-interactive-banner:hover .banner-orb {
        transform:translateY(-7px) scale(1.06);
    }
}

@media (max-width:760px) {
    .user-interactive-banner {
        animation:bannerGradientMove 9s ease infinite,
                  bannerEntrance .7s ease both;
    }
}

@media (prefers-reduced-motion:reduce) {
    .user-interactive-banner,
    .user-interactive-banner *,
    .user-interactive-banner::before,
    .user-interactive-banner::after {
        animation:none !important;
        transition:none !important;
    }
}

</style>

<div class="welcome-banner user-interactive-banner">
    <div class="banner-copy">
        <span class="pill">● SISTEM ONLINE</span>
        <h2>Halo, <?php echo e(auth()->user()->name); ?> 👋</h2>
        <p>Kelola kebutuhan OTP kamu lebih cepat dan mudah.</p>

        <?php if(auth()->user()->role !== 'admin'): ?>
            <div class="banner-wallet">
                <div class="banner-wallet-info">
                    <span class="banner-wallet-label">Saldo kamu</span>
                    <strong class="banner-wallet-value"><?php echo e(rupiah(auth()->user()->balance)); ?></strong>
                </div>
            </div>
        <?php endif; ?>

        <div class="banner-actions">
            <a class="btn primary" href="<?php echo e(route('order')); ?>">Mulai Order <span>→</span></a>
            <?php if(auth()->user()->role !== 'admin'): ?>
                <a class="banner-topup-btn" href="<?php echo e(route('topup')); ?>">＋ Top Up Saldo</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="banner-orb"><div class="orb-ring">✦</div></div>
</div>
<?php if(isset($announcements) && $announcements->isNotEmpty()): ?>
<style>
.dashboard-announcements{display:grid;gap:12px;margin:16px 0 24px}
.dashboard-announcement{padding:15px 17px;border:1px solid var(--line);border-left:4px solid var(--accent,#3b82f6);border-radius:13px;background:var(--panel);overflow-wrap:anywhere}
.dashboard-announcement.info{--accent:#3b82f6}
.dashboard-announcement.success{--accent:#16a34a}
.dashboard-announcement.warning{--accent:#d97706}
.dashboard-announcement.danger{--accent:#dc2626}
.dashboard-announcement-title{font-weight:700;margin-bottom:5px;color:var(--text)}
.dashboard-announcement-message{font-size:14px;line-height:1.6;color:var(--muted);white-space:pre-line}
</style>
<div class="dashboard-announcements">
    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="dashboard-announcement <?php echo e($announcement->type); ?>">
            <div class="dashboard-announcement-title">
                <?php if($announcement->type === 'success'): ?> ✓
                <?php elseif($announcement->type === 'warning'): ?> ⚠
                <?php elseif($announcement->type === 'danger'): ?> !
                <?php else: ?> ℹ
                <?php endif; ?>
                <?php echo e($announcement->title); ?>

            </div>
            <div class="dashboard-announcement-message"><?php echo e($announcement->message); ?></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<div class="stats-grid"><div class="stat-card"><span class="stat-icon blue">↗</span><span class="muted">Saldo tersedia</span><strong><?php echo e(auth()->user()->role === 'admin'
    ? ($simuruBalance['balance_formatted'] ?? ($simuruBalance !== null ? rupiah($simuruBalance['balance'] ?? 0) : ($simuruBalanceError ? 'Tidak tersedia' : '—')))
    : rupiah(auth()->user()->balance)); ?></strong><a href="<?php echo e(route('topup')); ?>">Tambah saldo →</a></div><div class="stat-card"><span class="stat-icon purple">▣</span><span class="muted">Total order</span><strong><?php echo e($stats['orders']); ?></strong><small class="muted">Seluruh transaksi</small></div><div class="stat-card"><span class="stat-icon green">◉</span><span class="muted">OTP aktif</span><strong><?php echo e($stats['active']); ?></strong><a href="<?php echo e(route('otp')); ?>">Lihat OTP →</a></div><div class="stat-card"><span class="stat-icon orange">✓</span><span class="muted">Top up berhasil</span><strong><?php echo e($stats['topups']); ?></strong><small class="muted">Pembayaran terverifikasi</small></div></div>

<?php if(auth()->user()->role !== 'admin'): ?>
<style>
.dashboard-catalog-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:24px}
.dashboard-catalog-item{min-width:0;padding:15px;border:1px solid var(--line);border-radius:15px;background:var(--panel)}
.dashboard-catalog-item img{width:38px;height:38px;object-fit:contain;border-radius:9px;margin-bottom:10px}
.dashboard-catalog-item .catalog-name{font-weight:750;font-size:13px;overflow-wrap:anywhere;min-height:36px}
.dashboard-catalog-item .catalog-price{font-weight:850;font-size:16px;margin:8px 0;color:var(--blue)}
.dashboard-catalog-item small{display:block;color:var(--muted);font-size:11px;margin-bottom:10px}
@media(max-width:800px){.dashboard-catalog-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style>
<div class="section-head">
    <div><h2>Katalog layanan OTP</h2><p class="muted">Harga jual sudah termasuk markup yang ditetapkan admin.</p></div>
    <a class="text-link" href="<?php echo e(route('catalog')); ?>">Lihat semua →</a>
</div>
<?php if($dashboardCatalogError): ?>
    <div class="panel" style="padding:16px;margin-bottom:20px">
        <p class="muted">Katalog sementara tidak tersedia. Silakan buka halaman order untuk mencoba kembali.</p>
        <a class="btn primary" href="<?php echo e(route('order')); ?>">Buka katalog order</a>
    </div>
<?php elseif(count($dashboardCatalog)): ?>
    <div class="dashboard-catalog-grid">
        <?php $__currentLoopData = $dashboardCatalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="dashboard-catalog-item">
                <?php if(is_string($item['image'] ?? null) && filter_var($item['image'], FILTER_VALIDATE_URL)): ?>
                    <img src="<?php echo e($item['image']); ?>" alt="" loading="lazy">
                <?php else: ?>
                    <div style="font-size:25px;margin-bottom:10px">📱</div>
                <?php endif; ?>
                <div class="catalog-name"><?php echo e($item['name']); ?></div>
                <div class="catalog-price"><?php echo e(rupiah($item['selling_price'])); ?></div>
                <small>Harga termurah yang tersedia</small>
                <a class="btn secondary full" href="<?php echo e(route('order')); ?>">Pilih layanan →</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <div class="panel" style="padding:16px;margin-bottom:20px">
        <p class="muted">Belum ada layanan dengan harga tersedia.</p>
        <a class="btn primary" href="<?php echo e(route('order')); ?>">Buka halaman order</a>
    </div>
<?php endif; ?>
<?php endif; ?>

<?php if(auth()->user()->role === 'admin' && $adminStats): ?>
<style>
.admin-ops-grid {
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:14px;
    margin-bottom:24px;
}
.admin-ops-card {
    display:flex;
    flex-direction:column;
    gap:9px;
    min-width:0;
    padding:19px;
    border:1px solid var(--line);
    border-radius:16px;
    background:var(--panel);
    transition:transform .2s ease,border-color .2s ease;
}
.admin-ops-card:hover { transform:translateY(-3px);border-color:var(--blue); }
.admin-ops-icon {
    display:flex;align-items:center;justify-content:center;
    flex:0 0 40px;width:40px;height:40px;border-radius:12px;
    background:rgba(79,109,245,.18);
    color:#7793ff;font-size:21px;line-height:1;
}
.admin-ops-icon i {
    display:inline-block;font-size:21px;line-height:1;
    font-style:normal;visibility:visible;opacity:1;
}
.admin-ops-icon.green { color:#16b889;background:rgba(22,184,137,.13); }
.admin-ops-icon.orange { color:#f59e0b;background:rgba(245,158,11,.13); }
.admin-ops-icon.purple { color:#a78bfa;background:rgba(167,139,250,.14); }
.admin-ops-label { color:var(--muted);font-size:12px; }
.admin-ops-value { font-size:clamp(19px,2vw,25px);font-weight:850;letter-spacing:-.5px;overflow-wrap:anywhere; }
.admin-ops-note { color:var(--muted);font-size:11px;line-height:1.5; }
.admin-ops-links {
    display:grid;grid-template-columns:repeat(3,minmax(0,1fr));
    gap:12px;margin-bottom:25px;
}
.admin-ops-link {
    display:flex;align-items:center;gap:12px;
    padding:15px;border:1px solid var(--line);
    border-radius:14px;background:var(--panel);
    transition:border-color .2s ease,transform .2s ease;
}
.admin-ops-link:hover { border-color:var(--blue);transform:translateY(-2px); }
.admin-ops-link i { color:var(--blue);font-size:20px; }
.admin-ops-link b { display:block;font-size:12px; }
.admin-ops-link small { display:block;margin-top:4px;color:var(--muted);font-size:11px; }
@media(max-width:1000px) {
    .admin-ops-grid { grid-template-columns:repeat(2,minmax(0,1fr)); }
}
@media(max-width:560px) {
    .admin-ops-grid { gap:9px; }
    .admin-ops-card { padding:13px; }
    .admin-ops-value { font-size:19px; }
    .admin-ops-links { grid-template-columns:1fr;gap:9px; }
}
</style>

<div class="section-head">
    <div>
        <h2>Ringkasan Operasional</h2>
        <p class="muted">Statistik sistem dan aktivitas keuangan Depuka OTP</p>
    </div>
</div>

<div class="admin-ops-grid">
    <div class="admin-ops-card">
        <span class="admin-ops-icon"><i class="bi bi-people"></i></span>
        <span class="admin-ops-label">Total pengguna</span>
        <strong class="admin-ops-value"><?php echo e(number_format($adminStats['users'], 0, ',', '.')); ?></strong>
        <span class="admin-ops-note">Seluruh akun terdaftar</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon green"><i class="bi bi-wallet2"></i></span>
        <span class="admin-ops-label">Total saldo pengguna</span>
        <strong class="admin-ops-value"><?php echo e(rupiah($adminStats['balance'])); ?></strong>
        <span class="admin-ops-note">Akumulasi saldo seluruh akun</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon"><i class="bi bi-wallet2"></i></span>
        <span class="admin-ops-label">Saldo SIMURU</span>
        <?php if($simuruBalance !== null): ?>
            <strong class="admin-ops-value"><?php echo e($simuruBalance['balance_formatted'] ?? rupiah($simuruBalance['balance'] ?? 0)); ?></strong>
            <span class="admin-ops-note">Saldo akun provider · diperbarui saat dashboard dimuat</span>
        <?php elseif($simuruBalanceError): ?>
            <strong class="admin-ops-value">Tidak tersedia</strong>
            <span class="admin-ops-note">Gagal mengambil saldo provider. Muat ulang beberapa saat lagi.</span>
        <?php else: ?>
            <strong class="admin-ops-value">—</strong>
            <span class="admin-ops-note">Saldo provider belum dimuat</span>
        <?php endif; ?>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon purple"><i class="bi bi-phone"></i></span>
        <span class="admin-ops-label">Order OTP aktif</span>
        <strong class="admin-ops-value"><?php echo e(number_format($adminStats['activeOrders'], 0, ',', '.')); ?></strong>
        <span class="admin-ops-note">Dari <?php echo e(number_format($adminStats['orders'], 0, ',', '.')); ?> order keseluruhan</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon orange"><i class="bi bi-hourglass-split"></i></span>
        <span class="admin-ops-label">Pengajuan top up</span>
        <strong class="admin-ops-value"><?php echo e(number_format($adminStats['pendingTopups'], 0, ',', '.')); ?></strong>
        <span class="admin-ops-note"><?php echo e(rupiah($adminStats['pendingAmount'])); ?> menunggu pemeriksaan</span>
    </div>

    <div class="admin-ops-card">
        <span class="admin-ops-icon green"><i class="bi bi-check-circle"></i></span>
        <span class="admin-ops-label">Top up berhasil</span>
        <strong class="admin-ops-value"><?php echo e(number_format($adminStats['paidTopups'], 0, ',', '.')); ?></strong>
        <span class="admin-ops-note"><?php echo e(rupiah($adminStats['paidAmount'])); ?> telah disetujui</span>
    </div>
</div>

<div class="section-head">
    <div>
        <h2>Akses administrasi</h2>
        <p class="muted">Pintasan untuk mengelola aktivitas sistem</p>
    </div>
</div>

<div class="admin-ops-links">
    <a class="admin-ops-link" href="<?php echo e(route('admin.users')); ?>">
        <i class="bi bi-people"></i>
        <span><b>Kelola pengguna</b><small>Lihat akun dan saldo pengguna</small></span>
    </a>
    <a class="admin-ops-link" href="<?php echo e(route('admin.topups')); ?>">
        <i class="bi bi-wallet"></i>
        <span><b>Pengajuan top up</b><small>Periksa dan verifikasi pembayaran</small></span>
    </a>
    <a class="admin-ops-link" href="<?php echo e(route('admin.orders')); ?>">
        <i class="bi bi-receipt"></i>
        <span><b>Riwayat order</b><small>Pantau pesanan seluruh pengguna</small></span>
    </a>
</div>
<?php else: ?>
<div class="section-head">
    <div><h2>Akses cepat</h2><p class="muted">Fitur utama Depuka OTP</p></div>
</div>
<div class="quick-grid">
    <a class="quick-card" href="<?php echo e(route('order')); ?>"><span class="quick-icon">＋</span><b>Order nomor</b><small>Pilih layanan dan negara</small><span class="arrow">↗</span></a>
    <a class="quick-card" href="<?php echo e(route('otp')); ?>"><span class="quick-icon violet">▣</span><b>Pesan OTP</b><small>Pantau SMS dan sisa waktu</small><span class="arrow">↗</span></a>
    <a class="quick-card" href="<?php echo e(route('topup')); ?>"><span class="quick-icon mint">◈</span><b>Top up saldo</b><small>Bayar cepat melalui QRIS</small><span class="arrow">↗</span></a>
</div>
<?php endif; ?>
<div class="section-head"><div><h2>Order terbaru</h2><p class="muted">Aktivitas pesanan terakhir</p></div><a class="text-link" href="<?php echo e(route('history')); ?>">Lihat semua →</a></div><div class="panel table-wrap"><table><thead><tr><th>Layanan</th><th>Nomor</th><th>Harga</th><th>Status</th><th></th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><b><?php echo e($o->service_name); ?></b><small><?php echo e($o->country_name); ?></small></td><td><?php echo e($o->phone_number ?? 'Menunggu nomor'); ?></td><td><?php echo e(rupiah($o->selling_price)); ?></td><td><span class="status <?php echo e($o->status); ?>"><?php echo e($o->status); ?></span></td><td><a class="text-link" href="<?php echo e(route('otp')); ?>">Detail</a></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="empty">Belum ada order. Mulai order pertamamu.</td></tr><?php endif; ?></tbody></table></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/dashboard.blade.php ENDPATH**/ ?>