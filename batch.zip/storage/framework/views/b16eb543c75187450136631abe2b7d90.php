<?php $__env->startSection('content'); ?>
<div class="premium-page">
    <div class="premium-heading">
        <div>
            <h1>Aplikasi Premium</h1>
            <p>Pilih aplikasi dan lihat paket yang tersedia.</p>
        </div>
        <a href="<?php echo e(route('premium.history')); ?>">Riwayat Pembelian</a>
    </div>

    <?php if($errors->has('premium')): ?>
        <div class="premium-notice"><?php echo e($errors->first('premium')); ?></div>
    <?php endif; ?>

    <form method="GET" action="<?php echo e(route('premium.index')); ?>" class="premium-search">
        <input type="search" name="q" value="<?php echo e($search); ?>"
               placeholder="Cari aplikasi premium..." aria-label="Cari aplikasi">
        <button type="submit">Cari</button>
    </form>

    <?php if($error): ?>
        <div class="premium-notice"><?php echo e($error); ?></div>
    <?php elseif(empty($categories)): ?>
        <div class="premium-empty">Aplikasi tidak ditemukan.</div>
    <?php else: ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="premium-category">
                <div class="premium-category-title">
                    <?php if(!empty($category['logo'])): ?>
                        <img class="premium-logo"
                             src="<?php echo e($category['logo']); ?>"
                             alt="<?php echo e($category['app'] ?? 'Logo aplikasi'); ?>"
                             loading="eager" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex'">
                    <?php else: ?>
                        <span class="premium-logo-fallback">
                            <?php echo e(mb_strtoupper(mb_substr($category['app'] ?? 'A', 0, 1))); ?>

                        </span>
                    <?php endif; ?>
                    <div>
                        <h2><?php echo e($category['app'] ?? 'Aplikasi'); ?></h2>
                        <p><?php echo e((int) ($category['varian'] ?? count($category['items'] ?? []))); ?> paket tersedia</p>
                    </div>
                </div>

                <div class="premium-grid">
                    <?php $__currentLoopData = ($category['items'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="premium-card">
                            <?php if(!empty($item['logo'])): ?>
                                <img class="premium-card-logo"
                                     src="<?php echo e($item['logo']); ?>"
                                     alt="<?php echo e($item['app'] ?? 'Logo aplikasi'); ?>"
                                     loading="eager" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex'">
                            <?php else: ?>
                                <span class="premium-card-logo premium-logo-fallback">
                                    <?php echo e(mb_strtoupper(mb_substr($item['app'] ?? 'A', 0, 1))); ?>

                                </span>
                            <?php endif; ?>

                            <h3><?php echo e($item['nama'] ?? $item['app'] ?? 'Paket Premium'); ?></h3>
                            <?php if(!empty($item['nama_penuh'])): ?>
                                <p class="premium-description"><?php echo e($item['nama_penuh']); ?></p>
                            <?php endif; ?>
                            <?php if(!empty($item['durasi_hari'])): ?>
                                <p class="premium-meta">Durasi <?php echo e((int) $item['durasi_hari']); ?> hari</p>
                            <?php endif; ?>
                            <div class="premium-price">
                                <?php echo e($item['harga_formatted'] ?? ('Rp ' . number_format((int) ($item['harga'] ?? 0), 0, ',', '.'))); ?>

                            </div>
                            <?php if(isset($item['stok']) && $item['stok'] !== null): ?>
                                <p class="premium-meta">Stok: <?php echo e((int) $item['stok']); ?></p>
                            <?php endif; ?>
                            <p class="premium-meta">
                                <?php echo e(!empty($item['butuh_email']) ? 'Memerlukan email tujuan' : 'Periksa keterangan paket sebelum memesan'); ?>

                            </p>

                            <form method="POST" action="<?php echo e(route('premium.purchase')); ?>" class="premium-buy-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="app_id" value="<?php echo e((int) ($item['id'] ?? 0)); ?>">

                                <?php if(!empty($item['butuh_email'])): ?>
                                    <label class="premium-email-label">
                                        Email tujuan
                                        <input type="email" name="email" required maxlength="255"
                                               autocomplete="email" placeholder="nama@email.com">
                                    </label>
                                <?php endif; ?>

                                <button type="submit" class="premium-buy-button"
                                    <?php if(isset($item['stok']) && (int) $item['stok'] <= 0): ?> disabled <?php endif; ?>>
                                    <?php if(isset($item['stok']) && (int) $item['stok'] <= 0): ?>
                                        Stok Habis
                                    <?php else: ?>
                                        Beli Sekarang
                                    <?php endif; ?>
                                </button>
                            </form>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/premium/index.blade.php ENDPATH**/ ?>