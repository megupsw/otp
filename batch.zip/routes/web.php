<?php

use App\Http\Controllers\CatalogController;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PremiumAppController;
use App\Http\Controllers\TopupController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MidtransWebhookController;
use App\Http\Controllers\PayHookWebhookController;
use App\Http\Controllers\PayHookTopupController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    if (auth()->check()) {
        return redirect()->route('dashboard');
    }

    return view('welcome');
});
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:8,1');
    Route::get('/register', [AuthController::class, 'registerForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:5,1');
});
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::post('/payments/midtrans/notification', [MidtransWebhookController::class, 'handle'])
    ->name('payments.midtrans.notification');

Route::post('/webhooks/payhook/dana', [PayHookWebhookController::class, 'handle'])
    ->name('webhooks.payhook.dana');


Route::middleware(['auth', 'active'])->group(function () {
    Route::get('/chat-komunitas', [\App\Http\Controllers\CommunityChatController::class, 'index'])->name('community-chat');
    Route::get('/chat-komunitas/messages', [\App\Http\Controllers\CommunityChatController::class, 'messages'])->middleware('throttle:60,1')->name('community-chat.messages');
    Route::post('/chat-komunitas/messages', [\App\Http\Controllers\CommunityChatController::class, 'store'])->middleware('throttle:20,1')->name('community-chat.store');
    Route::put('/chat-komunitas/messages/{message}', [\App\Http\Controllers\CommunityChatController::class, 'update'])->middleware('throttle:30,1')->name('community-chat.update');
    Route::delete('/chat-komunitas/messages/{message}', [\App\Http\Controllers\CommunityChatController::class, 'destroy'])->middleware('throttle:30,1')->name('community-chat.destroy');

    Route::get('/dashboard', DashboardController::class)->name('dashboard');
    Route::get('/catalog', [CatalogController::class, 'index'])->name('catalog');
    Route::get('/bantuan', [\App\Http\Controllers\SupportTicketController::class, 'index'])->name('support.index');
    Route::post('/bantuan', [\App\Http\Controllers\SupportTicketController::class, 'store'])->middleware('throttle:5,1')->name('support.store');
    Route::get('/bantuan/{ticket}/lampiran', [\App\Http\Controllers\SupportTicketController::class, 'attachment'])->name('support.attachment');
    Route::get('/order', [OrderController::class, 'index'])->name('order');
    Route::get('/premium-apps', [\App\Http\Controllers\PremiumAppController::class, 'index'])->name('premium.index');
    Route::post('/premium-apps/purchase', [PremiumAppController::class, 'purchase'])
        ->middleware('throttle:5,1')->name('premium.purchase');
    Route::get('/premium-apps/history', [PremiumAppController::class, 'history'])
        ->name('premium.history');
    Route::post('/order', [OrderController::class, 'store'])->middleware('throttle:10,1')->name('order.store');
    Route::get('/otp', [OrderController::class, 'otp'])->name('otp');
Route::get('/inbox', [OrderController::class, 'inbox'])->name('inbox');
    Route::post('/otp/{order}/refresh', [OrderController::class, 'refresh'])->name('otp.refresh');
    Route::post('/otp/{order}/cancel', [OrderController::class, 'cancel'])->name('otp.cancel');
    Route::post('/otp/{order}/finish', [OrderController::class, 'finish'])->name('otp.finish');
    Route::get('/history', [OrderController::class, 'history'])->name('history');
    Route::post('/topup/payhook-gopay', [PayHookTopupController::class, 'create'])->middleware('throttle:5,1')->name('topup.payhook-gopay');
    Route::post('/topup/payhook-shopeepay', [PayHookTopupController::class, 'createShopeePay'])->middleware('throttle:5,1')->name('topup.payhook-shopeepay');
    Route::get('/topup', [TopupController::class, 'index'])->name('topup');
    Route::post('/topup', [TopupController::class, 'store'])->middleware('throttle:5,1')->name('topup.store');
    Route::get('/topup/{topup}/status', [TopupController::class, 'status'])->name('topup.status');
    Route::post('/topup/{topup}/proof', [TopupController::class, 'submitProof'])->middleware('throttle:5,1')->name('topup.proof');
    Route::get('/account', [\App\Http\Controllers\AccountController::class, 'edit'])->name('account.edit');
    Route::put('/account/profile', [\App\Http\Controllers\AccountController::class, 'updateProfile'])->name('account.profile');
    Route::put('/account/password', [\App\Http\Controllers\AccountController::class, 'updatePassword'])->name('account.password');
    Route::post('/theme', [DashboardController::class, 'theme'])->name('theme');
});

Route::prefix('admin')->name('admin.')->middleware(['auth', 'active', 'role:admin'])->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('index');
    Route::get('/support-tickets', [\App\Http\Controllers\AdminSupportTicketController::class, 'index'])->name('support-tickets');
    Route::get('/support-tickets/{ticket}/lampiran', [\App\Http\Controllers\AdminSupportTicketController::class, 'attachment'])->name('support-tickets.attachment');
    Route::put('/support-tickets/{ticket}', [\App\Http\Controllers\AdminSupportTicketController::class, 'update'])->name('support-tickets.update');
    Route::get('/site-settings', [\App\Http\Controllers\AdminSiteSettingsController::class, 'index'])->name('site-settings');
    Route::get('/system-settings', [\App\Http\Controllers\AdminSystemSettingsController::class, 'index'])->name('system-settings');
    Route::post('/site-settings', [\App\Http\Controllers\AdminSiteSettingsController::class, 'save'])->middleware('throttle:10,1')->name('site-settings.save');
    Route::get('/announcements', [\App\Http\Controllers\AdminAnnouncementController::class, 'index'])->name('announcements.index');
    Route::get('/announcements/users', [\App\Http\Controllers\AdminAnnouncementController::class, 'searchUsers'])->middleware('throttle:60,1')->name('announcements.users');
    Route::post('/announcements', [\App\Http\Controllers\AdminAnnouncementController::class, 'store'])->name('announcements.store');
    Route::put('/announcements/{announcement}', [\App\Http\Controllers\AdminAnnouncementController::class, 'update'])->name('announcements.update');
    Route::delete('/announcements/{announcement}', [\App\Http\Controllers\AdminAnnouncementController::class, 'destroy'])->name('announcements.destroy');
    Route::post('/announcements/{announcement}/toggle', [\App\Http\Controllers\AdminAnnouncementController::class, 'toggle'])->name('announcements.toggle');

    Route::get('/users', [AdminController::class, 'users'])->name('users');
    Route::get('/orders', [AdminController::class, 'orders'])->name('orders');
    Route::post('/orders/{order}/cancel', [AdminController::class, 'cancelOrder'])->name('orders.cancel');

    Route::post('/test-otp', [\App\Http\Controllers\OrderController::class, 'testOtp'])->name('test-otp');
    Route::post('/users/{user}/block', [AdminController::class, 'toggleBlock'])->name('users.block');
    Route::post('/users/{user}/reset-password', [AdminController::class, 'resetPassword'])->name('users.reset-password');
    Route::post('/users/{user}/balance', [AdminController::class, 'addBalance'])->name('users.balance');
    Route::post('/users/{user}/deduct-balance', [AdminController::class, 'deductBalance'])->name('users.deduct-balance');
    Route::get('/fonnte', [\App\Http\Controllers\AdminFonnteController::class, 'index'])->name('fonnte');
    Route::post('/fonnte', [\App\Http\Controllers\AdminFonnteController::class, 'save'])->middleware('throttle:10,1')->name('fonnte.save');
    Route::post('/fonnte/test', [\App\Http\Controllers\AdminFonnteController::class, 'test'])->middleware('throttle:3,1')->name('fonnte.test');
    Route::get('/pricing', [AdminController::class, 'pricing'])->name('pricing');
    Route::post('/pricing', [AdminController::class, 'savePricing'])->name('pricing.save');
    Route::post('/topups/automatic', [AdminController::class, 'toggleAutoTopup'])->name('topups.automatic');
    Route::post('/topups/methods', [AdminController::class, 'saveTopupMethods'])->name('topups.methods');
    Route::get('/topups', [AdminController::class, 'topups'])->name('topups');
    Route::get('/topups/{topup}/proof', [AdminController::class, 'topupProof'])->name('topups.proof');
    Route::post('/topups/{topup}/approve', [AdminController::class, 'approveTopup'])->name('topups.approve');
    Route::post('/topups/{topup}/reject', [AdminController::class, 'rejectTopup'])->name('topups.reject');
});
