<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AccountController extends Controller
{
    public function edit(Request $request)
    {
        return view('account.edit', ['user' => $request->user()]);
    }

    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => [
                'required', 'email', 'max:255',
                Rule::unique('users', 'email')->ignore($user->id),
            ],
            'whatsapp_phone' => ['nullable', 'string', 'regex:/^628[0-9]{7,13}$/'],
            'current_password' => ['required', 'current_password'],
        ], [
            'email.unique' => 'Email sudah digunakan akun lain.',
            'whatsapp_phone.regex' => 'Nomor WhatsApp harus memakai format 628xxxxxxxxxx tanpa tanda + atau spasi.',
            'current_password.current_password' => 'Password saat ini salah.',
        ]);

        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->whatsapp_phone = $data['whatsapp_phone'] ?? null;
        $user->save();

        return back()->with('success', 'Profil berhasil diperbarui.');
    }

    public function updatePassword(Request $request)
    {
        $data = $request->validate([
            'current_password' => ['required', 'current_password'],
            'password' => [
                'required', 'confirmed',
                Password::min(8)->letters()->numbers(),
            ],
        ], [
            'current_password.current_password' => 'Password saat ini salah.',
            'password.confirmed' => 'Konfirmasi password baru tidak cocok.',
        ]);

        $user = $request->user();
        $user->password = $data['password'];
        $user->setRememberToken(\Illuminate\Support\Str::random(60));
        $user->save();

        return back()->with('success', 'Password berhasil diubah.');
    }
}
