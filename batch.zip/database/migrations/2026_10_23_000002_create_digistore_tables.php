<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('topups',function(Blueprint $t){ $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('order_id')->unique(); $t->unsignedBigInteger('amount'); $t->string('status')->default('pending')->index(); $t->string('snap_token')->nullable(); $t->text('redirect_url')->nullable(); $t->string('payment_type')->nullable(); $t->timestamp('paid_at')->nullable(); $t->json('payload')->nullable(); $t->timestamps(); });
  Schema::create('otp_orders',function(Blueprint $t){ $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('provider_order_id')->nullable()->index(); $t->string('service_id'); $t->string('service_name'); $t->unsignedInteger('country_id'); $t->string('country_name')->nullable(); $t->string('operator')->nullable(); $t->string('phone_number')->nullable(); $t->unsignedBigInteger('provider_price'); $t->unsignedBigInteger('selling_price'); $t->string('status')->default('active')->index(); $t->string('sms_code')->nullable(); $t->json('sms_data')->nullable(); $t->unsignedInteger('remaining_seconds')->nullable(); $t->json('provider_payload')->nullable(); $t->timestamps(); });
  Schema::create('wallet_transactions',function(Blueprint $t){ $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->foreignId('topup_id')->nullable()->constrained('topups')->nullOnDelete(); $t->string('type'); $t->unsignedBigInteger('amount'); $t->string('description'); $t->timestamps(); });
  Schema::create('settings',function(Blueprint $t){ $t->id(); $t->string('key')->unique(); $t->text('value')->nullable(); });
 }
 public function down(): void { Schema::dropIfExists('settings'); Schema::dropIfExists('wallet_transactions'); Schema::dropIfExists('otp_orders'); Schema::dropIfExists('topups'); }
};
