<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('premium_app_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->unsignedBigInteger('app_id');
            $table->string('app_name');
            $table->string('package_name');
            $table->string('request_id', 64)->unique();
            $table->string('provider_order_id')->nullable()->unique();
            $table->string('email')->nullable();
            $table->unsignedBigInteger('price');
            $table->string('status')->default('initiated')->index();
            $table->json('provider_payload')->nullable();
            $table->text('account_details')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('premium_app_orders');
    }
};
