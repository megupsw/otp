<?php $__env->startSection('title', 'Inbox OTP'); ?>
<?php $__env->startSection('crumb', 'INBOX OTP'); ?>
<?php $__env->startSection('heading', 'Inbox OTP'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-intro">
    <div>
        <h2>Riwayat OTP</h2>
        <p class="muted">OTP yang sudah kedaluwarsa, selesai, atau dibatalkan tersimpan di sini.</p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn secondary" href="<?php echo e(route('otp')); ?>">OTP Aktif</a>
        <a class="btn primary" href="<?php echo e(route('order')); ?>">＋ Order baru</a>
    </div>
</div>

<div class="otp-grid">
<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
        $expiredAt = data_get($o->provider_payload, 'expired_at');
        $timeExpired = false;
        if ($expiredAt) {
            try {
                $timeExpired = \Illuminate\Support\Carbon::parse($expiredAt)->isPast();
            } catch (\Throwable $e) {
                $timeExpired = false;
            }
        }
        $displayStatus = $timeExpired && in_array(strtolower((string)$o->status), ['active','pending'], true)
            ? 'expired'
            : strtolower((string)$o->status);
    ?>

    <div class="panel otp-card">
        <div class="otp-card-top">
            <?php
            $logoUrl = $serviceLogos[$o->service_id] ?? null;
        ?>
        <?php if($logoUrl && filter_var($logoUrl, FILTER_VALIDATE_URL)): ?>
            <img class="service-logo" src="<?php echo e($logoUrl); ?>" alt="<?php echo e($o->service_name); ?>" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex'">
            <span class="service-logo" style="display:none"><?php echo e(strtoupper(substr($o->service_name, 0, 1))); ?></span>
        <?php else: ?>
            <span class="service-logo"><?php echo e(strtoupper(substr($o->service_name, 0, 1))); ?></span>
        <?php endif; ?>
            <span class="status <?php echo e($displayStatus); ?>"><?php echo e($displayStatus); ?></span>
        </div>

        <h3><?php echo e($o->service_name); ?></h3>
        <p class="muted"><?php echo e($o->country_name); ?></p>
        <div class="phone-number"><?php echo e($o->phone_number ?? 'Nomor tidak tersedia'); ?></div>

        <div class="otp-details">
            <div><small>Harga</small><b><?php echo e(rupiah($o->selling_price)); ?></b></div>
            <div><small>ID Order</small><b>#<?php echo e($o->id); ?></b></div>
        </div>

        <div class="code-box">
            <small>KODE OTP</small>
            <strong><?php echo e($o->sms_code ?: 'Tidak ada kode OTP'); ?></strong>
            <?php if($o->sms_code): ?>
                <button class="icon-btn" type="button"
                    onclick="navigator.clipboard.writeText(<?php echo \Illuminate\Support\Js::from($o->sms_code)->toHtml() ?>)"
                    title="Salin kode OTP">⧉</button>
            <?php endif; ?>
        </div>

        <?php if(is_array($o->sms_data) && count($o->sms_data)): ?>
            <div class="sms-data">
                <?php $__currentLoopData = $o->sms_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e(is_array($sms) ? ($sms['text'] ?? json_encode($sms)) : $sms); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p class="muted">Tidak ada isi SMS yang tersimpan.</p>
        <?php endif; ?>

        <p class="muted" style="font-size:12px">
            Dibuat: <?php echo e($o->created_at?->format('d-m-Y H:i') ?? '—'); ?>

        </p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="panel empty-panel">
        <div class="empty-symbol">▤</div>
        <h3>Inbox masih kosong</h3>
        <p class="muted">OTP yang kedaluwarsa atau selesai akan tampil di sini.</p>
        <a class="btn primary" href="<?php echo e(route('otp')); ?>">Lihat OTP aktif</a>
    </div>
<?php endif; ?>
</div>

<?php if($orders->lastPage() > 1): ?>
    <nav class="inbox-pagination" aria-label="Navigasi halaman Inbox OTP">
        <div class="inbox-pagination-info">
            Halaman <strong><?php echo e($orders->currentPage()); ?></strong>
            dari <strong><?php echo e($orders->lastPage()); ?></strong>
            <span>· Maksimal 20 order per halaman</span>
        </div>

        <div class="inbox-pagination-controls">
            <?php if($orders->onFirstPage()): ?>
                <span class="inbox-page-btn is-disabled" aria-disabled="true">‹ Sebelumnya</span>
            <?php else: ?>
                <a class="inbox-page-btn" href="<?php echo e($orders->previousPageUrl()); ?>">‹ Sebelumnya</a>
            <?php endif; ?>

            <?php for($page = 1; $page <= $orders->lastPage(); $page++): ?>
                <?php if($page === $orders->currentPage()): ?>
                    <span class="inbox-page-number is-current" aria-current="page"><?php echo e($page); ?></span>
                <?php else: ?>
                    <a class="inbox-page-number" href="<?php echo e($orders->url($page)); ?>"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if($orders->hasMorePages()): ?>
                <a class="inbox-page-btn" href="<?php echo e($orders->nextPageUrl()); ?>">Berikutnya ›</a>
            <?php else: ?>
                <span class="inbox-page-btn is-disabled" aria-disabled="true">Berikutnya ›</span>
            <?php endif; ?>
        </div>
    </nav>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/otp/inbox.blade.php ENDPATH**/ ?>