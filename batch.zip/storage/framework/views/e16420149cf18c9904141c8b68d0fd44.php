<?php $__env->startSection('title', 'Riwayat Order'); ?>
<?php $__env->startSection('crumb', 'ADMIN / ORDERS'); ?>
<?php $__env->startSection('heading', 'Riwayat Order OTP'); ?>

<?php $__env->startSection('content'); ?>
<style>
.admin-order-tools{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}
.admin-order-tools input,.admin-order-tools select{min-width:0;padding:11px;border:1px solid var(--border,#334155);border-radius:9px;background:var(--panel,#111827);color:inherit}
.admin-order-tools input{flex:1}
.admin-order-tools button,.admin-order-cancel{border:0;border-radius:8px;padding:10px 13px;font-weight:700;cursor:pointer}
.admin-order-tools button{background:#2563eb;color:white}
.admin-order-cancel{background:#dc2626;color:white}
.admin-order-table{width:100%;border-collapse:collapse}
.admin-order-table th,.admin-order-table td{padding:12px 10px;text-align:left;border-bottom:1px solid var(--border,#293449);vertical-align:top;font-size:13px}
.admin-order-table th{color:var(--muted,#94a3b8)}
.admin-order-mobile{display:none}
.admin-order-card{padding:15px;border:1px solid var(--border,#293449);border-radius:12px;margin-bottom:12px;overflow-wrap:anywhere}
.admin-order-card p{margin:7px 0;font-size:13px}
.admin-order-card form{margin-top:12px}
.admin-order-cancel:disabled{opacity:.5;cursor:not-allowed}
.admin-order-pagination{margin-top:18px}
@media(max-width:800px){.admin-order-desktop{display:none}.admin-order-mobile{display:block}.admin-order-tools{display:grid;grid-template-columns:1fr}.admin-order-tools input,.admin-order-tools select,.admin-order-tools button{width:100%;box-sizing:border-box}.admin-order-table td{padding:8px}}
</style>

<div class="panel" style="padding:16px;margin-bottom:16px">
    <form method="GET" action="<?php echo e(route('admin.orders')); ?>" class="admin-order-tools">
        <input type="search" name="q" value="<?php echo e($search); ?>" placeholder="Cari nama/email user, layanan, nomor, ID order">
        <select name="status">
            <option value="">Semua status</option>
            <?php $__currentLoopData = ['active','pending','completed','success','canceled','cancelled','failed','expired']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($st); ?>" <?php if(strtolower($statusFilter) === $st): echo 'selected'; endif; ?>><?php echo e(ucfirst($st)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit">Cari / Filter</button>
        <a href="<?php echo e(route('admin.orders')); ?>" style="align-self:center">Reset</a>
    </form>
    <div class="muted">Menampilkan <?php echo e($orders->firstItem() ?? 0); ?>–<?php echo e($orders->lastItem() ?? 0); ?> dari <?php echo e($orders->total()); ?> order.</div>
</div>

<div class="panel table-wrap admin-order-desktop">
    <table class="admin-order-table">
        <thead><tr><th>User</th><th>Order / Layanan</th><th>Nomor</th><th>Harga</th><th>Status</th><th>Waktu</th><th>Tindakan</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($o->user?->name ?? 'Pengguna dihapus'); ?><br><span class="muted"><?php echo e($o->user?->email ?? '-'); ?></span></td>
                <td>#<?php echo e($o->id); ?><br><?php echo e($o->service_name ?: $o->service_id); ?><br><span class="muted">Provider: <?php echo e($o->provider_order_id ?: '-'); ?></span></td>
                <td><?php echo e($o->phone_number ?: '-'); ?></td>
                <td><?php echo e(rupiah($o->selling_price)); ?></td>
                <td><span class="status <?php echo e(strtolower($o->status)); ?>"><?php echo e($o->status); ?></span></td>
                <td><?php echo e($o->created_at?->format('d/m/Y H:i')); ?></td>
                <td>
                    <?php if(in_array(strtolower((string)$o->status), ['active','pending'], true)): ?>
                        <form method="POST" action="<?php echo e(route('admin.orders.cancel', $o)); ?>" onsubmit="return confirm('Batalkan order #<?php echo e($o->id); ?> untuk <?php echo e($o->user?->email ?? 'pengguna'); ?>? Provider akan diperiksa terlebih dahulu.')">
                            <?php echo csrf_field(); ?>
                            <button class="admin-order-cancel" type="submit">Batalkan</button>
                        </form>
                    <?php else: ?>
                        <span class="muted">Tidak tersedia</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" class="empty">Belum ada order yang cocok.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="admin-order-mobile">
    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="panel admin-order-card">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
                <strong>Order #<?php echo e($o->id); ?></strong>
                <span class="status <?php echo e(strtolower($o->status)); ?>"><?php echo e($o->status); ?></span>
            </div>
            <p><b>User:</b> <?php echo e($o->user?->name ?? 'Pengguna dihapus'); ?> (<?php echo e($o->user?->email ?? '-'); ?>)</p>
            <p><b>Layanan:</b> <?php echo e($o->service_name ?: $o->service_id); ?></p>
            <p><b>Nomor:</b> <?php echo e($o->phone_number ?: '-'); ?></p>
            <p><b>ID provider:</b> <?php echo e($o->provider_order_id ?: '-'); ?></p>
            <p><b>Harga:</b> <?php echo e(rupiah($o->selling_price)); ?></p>
            <p><b>Waktu:</b> <?php echo e($o->created_at?->format('d/m/Y H:i')); ?></p>
            <?php if(in_array(strtolower((string)$o->status), ['active','pending'], true)): ?>
                <form method="POST" action="<?php echo e(route('admin.orders.cancel', $o)); ?>" onsubmit="return confirm('Batalkan order #<?php echo e($o->id); ?>? Provider akan diperiksa terlebih dahulu.')">
                    <?php echo csrf_field(); ?>
                    <button class="admin-order-cancel" type="submit" style="width:100%">Batalkan Order</button>
                </form>
            <?php endif; ?>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="panel" style="padding:16px">Belum ada order yang cocok.</div>
    <?php endif; ?>
</div>

<div class="admin-order-pagination"><?php echo e($orders->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/admin/orders.blade.php ENDPATH**/ ?>