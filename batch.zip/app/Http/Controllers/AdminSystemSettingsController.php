<?php

namespace App\Http\Controllers;

class AdminSystemSettingsController extends Controller
{
    public function index()
    {
        return view('admin.system-settings', [
            'appUrl' => config('app.url'),
            'simuruUrl' => config('services.simuru.base_url'),
            'simuruConfigured' => filled(config('services.simuru.key')),
            'payhookTokenConfigured' => filled(config('services.payhook.token')),
            'payhookSecretConfigured' => filled(config('services.payhook.secret')),
            'midtransUrl' => config('services.midtrans.base_url'),
            'midtransServerKeyConfigured' => filled(config('services.midtrans.server_key')),
            'midtransClientKeyConfigured' => filled(config('services.midtrans.client_key')),
            'midtransProduction' => (bool) config('services.midtrans.is_production'),
            'payhookCallback' => route('webhooks.payhook.dana'),
            'midtransCallback' => route('payments.midtrans.notification'),
        ]);
    }
}
