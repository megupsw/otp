<?php

namespace App\Http\Controllers;

use App\Models\CommunityMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CommunityChatController extends Controller
{
    public function index()
    {
        return view('community-chat.index');
    }

    public function messages(): JsonResponse
    {
        $messages = CommunityMessage::with('user:id,name')
            ->latest('id')
            ->limit(100)
            ->get()
            ->sortBy('id')
            ->values()
            ->map(fn ($message) => [
                'id' => $message->id,
                'user_id' => $message->user_id,
                'name' => $message->user?->name ?? 'Pengguna',
                'message' => $message->message,
                'created_at' => $message->created_at->toIso8601String(),
            ]);

        return response()->json([
            'messages' => $messages,
            'current_user_id' => auth()->id(),
            'is_admin' => auth()->user()->role === 'admin',
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'message' => ['required', 'string', 'max:2000'],
        ]);

        $message = CommunityMessage::create([
            'user_id' => $request->user()->id,
            'message' => trim($data['message']),
        ]);

        return response()->json(['success' => true, 'id' => $message->id], 201);
    }

    public function update(Request $request, CommunityMessage $message): JsonResponse
    {
        if ($message->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Kamu hanya bisa mengedit pesan milikmu.'], 403);
        }

        $data = $request->validate([
            'message' => ['required', 'string', 'max:2000'],
        ]);

        $message->update(['message' => trim($data['message'])]);

        return response()->json(['success' => true]);
    }

    public function destroy(Request $request, CommunityMessage $message): JsonResponse
    {
        $isOwner = $message->user_id === $request->user()->id;
        $isAdmin = $request->user()->role === 'admin';

        if (!$isOwner && !$isAdmin) {
            return response()->json(['message' => 'Kamu tidak berhak menghapus pesan ini.'], 403);
        }

        $message->delete();

        return response()->json(['success' => true]);
    }
}
