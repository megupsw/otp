<?php $__env->startSection('title','Riwayat'); ?><?php $__env->startSection('crumb','ACTIVITY'); ?><?php $__env->startSection('heading','Riwayat Transaksi'); ?>
<?php $__env->startSection('content'); ?>
<div class="section-head"><div><h2>Riwayat order OTP</h2><p class="muted">Daftar transaksi nomor dan layanan.</p></div></div><div class="panel table-wrap"><table><thead><tr><th>Layanan</th><th>Negara</th><th>Nomor</th><th>Harga</th><th>Status</th><th>Tanggal</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($o->service_name); ?></td><td><?php echo e($o->country_name); ?></td><td><?php echo e($o->phone_number ?? '—'); ?></td><td><?php echo e(rupiah($o->selling_price)); ?></td><td><span class="status <?php echo e($o->status); ?>"><?php echo e($o->status); ?></span></td><td><?php echo e($o->created_at->format('d/m/y H:i')); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="empty">Belum ada order.</td></tr><?php endif; ?></tbody></table></div><?php echo e($orders->onEachSide(1)->links()); ?>

<div class="section-head"><div><h2>Riwayat top up</h2><p class="muted">Transaksi saldo masuk</p></div></div><div class="panel table-wrap"><table><thead><tr><th>ID pembayaran</th><th>Nominal</th><th>Status</th><th>Tanggal</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $topups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($t->order_id); ?></td><td><?php echo e(rupiah($t->amount)); ?></td><td><span class="status <?php echo e($t->status); ?>"><?php echo e($t->status); ?></span></td><td><?php echo e($t->created_at->format('d/m/y H:i')); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="empty">Belum ada top up.</td></tr><?php endif; ?></tbody></table></div><?php echo e($topups->onEachSide(1)->links()); ?>


<div class="section-head">
    <div>
        <h2>Riwayat Perubahan Saldo</h2>
        <p class="muted">Top up admin, refund, dan transaksi saldo lainnya.</p>
    </div>
</div>
<div class="panel table-wrap">
    <table>
        <thead>
            <tr>
                <th>Jenis Transaksi</th>
                <th>Nominal</th>
                <th>Keterangan</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $walletTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php switch($transaction->type):
                        case ('admin_credit'): ?>
                            Top Up Admin
                            <?php break; ?>
                        <?php case ('refund'): ?>
                            Refund Saldo
                            <?php break; ?>
                        <?php case ('credit'): ?>
                            Top Up
                            <?php break; ?>
                        <?php case ('admin_debit'): ?>
                            Pengurangan Saldo
                            <?php break; ?>
                        <?php default: ?>
                            <?php echo e(ucwords(str_replace('_', ' ', $transaction->type))); ?>

                    <?php endswitch; ?>
                </td>
                <td>
                    <span style="color:<?php echo e(in_array($transaction->type, ['admin_debit'], true) ? '#f87171' : '#34d399'); ?>;font-weight:700">
                        <?php echo e(in_array($transaction->type, ['admin_debit'], true) ? '−' : '+'); ?><?php echo e(rupiah($transaction->amount)); ?>

                    </span>
                </td>
                <td><?php echo e($transaction->description ?: '—'); ?></td>
                <td><?php echo e($transaction->created_at?->format('d/m/Y H:i') ?? '—'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="empty">Belum ada riwayat perubahan saldo.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div><?php echo e($walletTransactions->onEachSide(1)->links()); ?></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/history.blade.php ENDPATH**/ ?>