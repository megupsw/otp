<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Resend, Postmark, AWS, and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],


    'simuru' => [
        'base_url' => env('SIMURU_BASE_URL', 'https://simuru.com/api'),
        'key' => env('SIMURU_API_KEY'),
        'timeout' => env('SIMURU_TIMEOUT', 12),
    ],

    'payhook' => [
        'token' => env('PAYHOOK_TOKEN'),
        'secret' => env('PAYHOOK_SECRET'),
    ],

    'gopay' => [
        'destination_phone' => env('GOPAY_DESTINATION_PHONE'),
        'account_name' => env('GOPAY_ACCOUNT_NAME'),
    ],

'shopeepay' => [
    'destination_phone' => env('SHOPEEPAY_DESTINATION_PHONE'),
    'account_name' => env('SHOPEEPAY_ACCOUNT_NAME'),
],

    'midtrans' => [
        'base_url' => env('MIDTRANS_BASE_URL', 'https://app.sandbox.midtrans.com'),
        'server_key' => env('MIDTRANS_SERVER_KEY'),
        'client_key' => env('MIDTRANS_CLIENT_KEY'),
        'is_production' => env('MIDTRANS_IS_PRODUCTION', false),
        'snap_path' => env('MIDTRANS_SNAP_PATH', '/snap/v1/transactions'),
    ],

];
