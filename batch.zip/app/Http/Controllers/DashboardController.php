<?php
namespace App\Http\Controllers;
use App\Models\Topup;
use App\Models\Announcement;
use App\Models\User;
use App\Models\OtpOrder;
use App\Services\SimuruClient;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
class DashboardController extends Controller {
    public function __invoke(Request $r, SimuruClient $api){
        $user=$r->user();
        $data = [
            'activeOrders' => $user->orders()->where('status', 'active')->latest()->take(5)->get(),
            'recentOrders' => $user->orders()->latest()->take(6)->get(),
            'recentTopups' => $user->topups()->latest()->take(5)->get(),
            'stats' => [
                'orders' => $user->orders()->count(),
                'active' => $user->orders()->where('status', 'active')->count(),
                'topups' => $user->topups()->where('status', 'paid')->count(),
            ],
            'adminStats' => null,
            'simuruBalance' => null,
            'simuruBalanceError' => false,
        ];

        if ($user->role === 'admin') {
            $adminPending = Topup::where('status', 'pending');

            $data['adminStats'] = [
                'users' => User::count(),
                'balance' => (int) User::sum('balance'),
                'orders' => OtpOrder::count(),
                'activeOrders' => OtpOrder::where('status', 'active')->count(),
                'pendingTopups' => (clone $adminPending)->count(),
                'pendingAmount' => (int) (clone $adminPending)->sum('amount'),
                'paidTopups' => Topup::where('status', 'paid')->count(),
                'paidAmount' => (int) Topup::where('status', 'paid')->sum('amount'),
            ];

            try {
                $providerBalance = $api->balance();
                if (!array_key_exists('balance', $providerBalance)
                    && !array_key_exists('balance_formatted', $providerBalance)) {
                    throw new \RuntimeException('Format saldo SIMURU tidak dikenali.');
                }
                $data['simuruBalance'] = $providerBalance;
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning(
                    'Saldo SIMURU gagal dimuat di dashboard admin.',
                    ['exception' => get_class($e)]
                );
                $data['simuruBalanceError'] = true;
            }
        }

        // Katalog ringkas memakai daftar harga SIMURU yang sama dengan halaman order.
        $data['dashboardCatalog'] = [];
        $data['dashboardCatalogError'] = false;

        if ($user->role !== 'admin') {
            try {
                $markup = (float) setting('markup_percent', env('DEFAULT_MARKUP_PERCENT', 20));
                $services = $api->services();
                $prices = $api->pricelist();

                $serviceNames = [];
                foreach ($services as $service) {
                    $id = (string) ($service['service_id'] ?? $service['slug'] ?? $service['id'] ?? '');
                    $name = $service['name'] ?? $service['service_name'] ?? $service['slug'] ?? 'Layanan OTP';
                    if ($id !== '') {
                        $serviceNames[$id] = [
                            'id' => $id,
                            'name' => $name,
                            'image' => $service['service_image'] ?? $service['image'] ?? null,
                        ];
                    }
                }

                $cheapest = [];

                foreach ($prices as $price) {
                    $id = (string) ($price['service_id'] ?? '');
                    $base = (float) ($price['price'] ?? 0);
                    $countryId = $price['country_id'] ?? null;
                    $countryIso = strtoupper((string) ($price['country_iso'] ?? ''));
                    $countryName = strtolower((string) ($price['country_name'] ?? ''));

                    if (
                        $id === '' ||
                        $base <= 0 ||
                        $countryId === null ||
                        !isset($serviceNames[$id]) ||
                        ($countryIso !== 'ID' && !str_starts_with($countryName, 'indonesia'))
                    ) {
                        continue;
                    }

                    if (!isset($cheapest[$id]) || $base < $cheapest[$id]['base_price']) {
                        $cheapest[$id] = array_merge($serviceNames[$id], [
                            'base_price' => $base,
                            'selling_price' => (int) ceil($base * (1 + $markup / 100)),
                            'country_name' => $price['country_name'] ?? 'Indonesia',
                        ]);
                    }
                }

                $popularIds = [
                    'whatsapp',
                    'googleyoutubegmail',
                    'shopee',
                    'telegram',
                    'tiktok',
                    'instagram',
                    'facebook',
                    'gojek',
                ];

                $catalog = [];

                foreach ($popularIds as $id) {
                    if (isset($cheapest[$id])) {
                        $catalog[] = $cheapest[$id];
                    }
                }

                $data['dashboardCatalog'] = $catalog;
            } catch (\Throwable $e) {
                Log::notice('Katalog dashboard tidak tersedia.', [
                    'exception' => get_class($e),
                ]);
                $data['dashboardCatalogError'] = true;
            }
        }

        $data['announcements'] = Announcement::query()
            ->where('is_active', true)
            ->where(fn ($q) => $q->whereNull('starts_at')->orWhere('starts_at', '<=', now()))
            ->where(fn ($q) => $q->whereNull('ends_at')->orWhere('ends_at', '>=', now()))
            ->where(fn ($q) => $q->where('target_type', 'all')
                ->orWhereHas('users', fn ($users) => $users->where('users.id', $user->id)))
            ->latest()
            ->get();

        return view('dashboard', $data);
    }
    public function theme(Request $r){
        $data=$r->validate(['theme'=>'required|in:dark,light']);
        $r->user()->update($data); return back();
    }
}
