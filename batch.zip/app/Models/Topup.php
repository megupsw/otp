<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Topup extends Model {
    protected $fillable = ['user_id', 'order_id', 'amount', 'status', 'snap_token', 'redirect_url', 'payment_type', 'paid_at', 'payload', 'deposit_id', 'qr_string', 'expired_at', 'payment_reference', 'proof_path', 'reviewed_by', 'reviewed_at', 'rejection_reason', 'payment_amount', 'payhook_event_id'];
    protected function casts(): array { return ['amount'=>'integer','paid_at'=>'datetime','expired_at'=>'datetime','payload'=>'array']; }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
