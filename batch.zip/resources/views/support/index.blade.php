@extends('layouts.app')

@section('title', 'Bantuan CS')
@section('crumb', 'PUSAT BANTUAN')
@section('heading', 'Pusat Bantuan')

@section('content')
<style>
.support-page{max-width:1200px;margin:0 auto;color:var(--text)}
.support-hero{position:relative;overflow:hidden;padding:28px;border-radius:22px;background:linear-gradient(120deg,#243b83,#4059dc 58%,#7049d8);color:white;margin-bottom:24px}
.support-hero:after{content:"";position:absolute;width:240px;height:240px;border:1px solid #ffffff30;border-radius:50%;right:-55px;top:-100px;box-shadow:0 0 0 28px #ffffff09,0 0 0 58px #ffffff06;pointer-events:none}
.support-hero .eyebrow{color:#d7e1ff;font-size:11px;font-weight:800;letter-spacing:2px}
.support-hero h2{font-size:clamp(24px,3vw,34px);margin:12px 0 8px;color:white}
.support-hero p{color:#e0e7ff;max-width:560px;margin:0;line-height:1.7}
.support-grid{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(260px,.7fr);gap:20px;align-items:start}
.support-card{background:var(--panel);border:1px solid var(--line);border-radius:18px;padding:22px;min-width:0;box-shadow:0 8px 28px #00000008}
.support-card h2{font-size:18px;margin:0 0 7px}
.support-muted{color:var(--muted);font-size:13px;line-height:1.65;margin:0 0 20px}
.support-form{display:grid;gap:16px}
.support-form label{display:block;font-size:13px;font-weight:700;margin-bottom:8px}
.support-form input,.support-form select,.support-form textarea{display:block;width:100%;max-width:100%;min-width:0;box-sizing:border-box;border:1px solid var(--line);border-radius:11px;background:var(--bg);color:var(--text);padding:13px 14px;font:inherit;font-size:14px;outline:none}
.support-form input,.support-form select{min-height:46px}
.support-form textarea{min-height:145px;resize:vertical;line-height:1.65}
.support-form input:focus,.support-form select:focus,.support-form textarea:focus{border-color:#5573ff;box-shadow:0 0 0 3px #5573ff20}
.support-submit{width:100%;border:0;border-radius:11px;padding:14px;background:linear-gradient(100deg,#4967f5,#7651e8);color:#fff;font-weight:800;cursor:pointer;box-shadow:0 7px 18px #5267e62b}
.support-submit:hover{filter:brightness(1.08)}
.support-help-link{display:flex;gap:13px;align-items:center;padding:15px;border:1px solid var(--line);border-radius:13px;text-decoration:none;color:var(--text);margin-top:12px;transition:.2s}
.support-help-link:hover{border-color:#5573ff;transform:translateY(-1px)}
.support-icon{width:44px;height:44px;flex:0 0 44px;display:grid;place-items:center;border-radius:13px;background:#5573ff1b;color:#7890ff;font-size:22px}
.support-help-link strong{display:block;font-size:14px;margin-bottom:4px}
.support-help-link small{color:var(--muted);font-size:12px;line-height:1.5}
.support-ticket{border:1px solid var(--line);border-radius:14px;padding:17px;margin-top:13px;min-width:0}
.support-ticket-top{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center}
.support-ticket h3{font-size:15px;margin:0;overflow-wrap:anywhere}
.support-ticket p{line-height:1.7;overflow-wrap:anywhere}
.support-badge{display:inline-block;border-radius:30px;padding:6px 10px;font-size:11px;font-weight:800;background:#5573ff1b;color:#7890ff}
.support-status-selesai{background:#16a34a1b;color:#22c55e}
.support-status-diproses{background:#f59e0b1b;color:#fbbf24}
.support-status-menunggu_pengguna{background:#8b5cf61b;color:#a78bfa}
.support-status-baru{background:#5573ff1b;color:#7890ff}
.support-reply{padding:14px;border-radius:12px;background:var(--bg);border:1px solid var(--line);margin-top:12px}
.support-reply strong{font-size:12px;color:#7c92ff}
.support-empty{text-align:center;padding:28px 16px;color:var(--muted);border:1px dashed var(--line);border-radius:14px;margin-top:12px}
.support-alert{padding:13px 15px;border-radius:12px;margin-bottom:16px;font-size:13px}
.support-alert-success{background:#16a34a18;border:1px solid #16a34a55;color:#22c55e}
.support-alert-error{background:#ef444418;border:1px solid #ef444455;color:#f87171}
.support-section{margin-top:24px}
.support-section-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.support-count{font-size:12px;color:var(--muted)}
@media(max-width:850px){.support-grid{grid-template-columns:1fr}.support-hero{padding:23px}.support-card{padding:18px}}
</style>

<div class="support-page">
    <section class="support-hero">
        <div class="eyebrow">CUSTOMER CARE · {{ setting('brand_name', 'Digistore') }}</div>
        <h2>Ada kendala? Kami siap membantu.</h2>
        <p>Sampaikan masalahmu kepada tim bantuan. Pantau laporan dan baca balasan admin langsung dari halaman ini.</p>
    </section>

    @if(session('success'))
        <div class="support-alert support-alert-success">
            <i class="bi bi-check-circle"></i> {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="support-alert support-alert-error">
            <strong>Periksa kembali data laporan:</strong>
            <ul style="margin:8px 0 0;padding-left:20px">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="support-grid">
        <section class="support-card">
            <h2><i class="bi bi-pencil-square" style="color:#7187ff"></i> Buat laporan baru</h2>
            <p class="support-muted">Isi detail di bawah agar tim CS dapat memahami dan menangani masalahmu.</p>

            <form class="support-form" method="POST" enctype="multipart/form-data" action="{{ route('support.store') }}">
                @csrf
                <div>
                    <label for="subject">Subjek laporan</label>
                    <input id="subject" name="subject" value="{{ old('subject') }}" maxlength="120" required placeholder="Contoh: Top up belum masuk">
                </div>

                <div>
                    <label for="category">Kategori masalah</label>
                    <select id="category" name="category" required>
                        <option value="">Pilih kategori laporan</option>
                        @foreach(['akun'=>'Akun dan login','pembayaran'=>'Pembayaran dan top up','otp'=>'Layanan OTP','teknis'=>'Kendala teknis','lainnya'=>'Lainnya'] as $key => $label)
                            <option value="{{ $key }}" @selected(old('category') === $key)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label for="message">Ceritakan masalahmu</label>
                    <textarea id="message" name="message" rows="6" minlength="10" maxlength="5000" required placeholder="Jelaskan kendala, waktu kejadian, atau nomor transaksi jika ada. Jangan sertakan password atau kode OTP rahasia.">{{ old('message') }}</textarea>
                    <small style="display:block;color:var(--muted);margin-top:7px">Minimal 10 karakter · Maksimal 5.000 karakter</small>
                </div>

                <div>
                <label for="attachment">Lampiran gambar (opsional)</label>
                <input id="attachment" name="attachment" type="file"
                       accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
                <small style="display:block;color:var(--muted);margin-top:7px">
                    JPG, PNG, atau WebP · Maksimal 5 MB
                </small>
                <img id="attachment-preview" alt="Pratinjau gambar"
                     style="display:none;max-width:100%;max-height:240px;margin-top:12px;border-radius:12px">
            </div>

            <button type="submit" class="support-submit"><i class="bi bi-send-fill"></i> Kirim laporan</button>
            </form>
        </section>

        <aside class="support-card">
            <h2><i class="bi bi-headset" style="color:#7187ff"></i> Hubungi CS</h2>
            <p class="support-muted">Pilih cara bantuan yang paling nyaman untukmu.</p>

            <a href="#laporan-saya" class="support-help-link">
                <span class="support-icon"><i class="bi bi-ticket-detailed"></i></span>
                <span><strong>Buat & pantau tiket</strong><small>Laporan tersimpan dan status dapat dipantau di sini.</small></span>
            </a>

            @if($phone)
                <a class="support-help-link" href="https://wa.me/{{ $phone }}?text={{ urlencode('Halo CS ' . setting('brand_name', 'Digistore') . ', saya membutuhkan bantuan.') }}" target="_blank" rel="noopener noreferrer">
                    <span class="support-icon" style="background:#22c55e1b;color:#22c55e"><i class="bi bi-whatsapp"></i></span>
                    <span><strong>Chat WhatsApp</strong><small>Hubungi CS langsung melalui WhatsApp.</small></span>
                </a>
            @else
                <div class="support-help-link">
                    <span class="support-icon"><i class="bi bi-whatsapp"></i></span>
                    <span><strong>WhatsApp belum tersedia</strong><small>Admin belum mengatur nomor CS.</small></span>
                </div>
            @endif

            <div style="margin-top:22px;padding:15px;border-radius:13px;background:var(--bg);border:1px solid var(--line)">
                <div style="font-size:13px;font-weight:800;margin-bottom:6px"><i class="bi bi-shield-check" style="color:#7187ff"></i> Tips keamanan</div>
                <p class="support-muted" style="margin:0">Jangan pernah membagikan password atau kode OTP rahasia kepada siapa pun, termasuk pihak yang mengaku sebagai CS.</p>
            </div>
        </aside>
    </div>

    <section class="support-section" id="laporan-saya">
        <div class="support-section-head">
            <div>
                <h2 style="font-size:20px;margin:0 0 5px"><i class="bi bi-inbox" style="color:#7187ff"></i> Laporan saya</h2>
                <p class="support-muted" style="margin:0">Pantau perkembangan dan balasan tim bantuan.</p>
            </div>
            <span class="support-count">{{ $tickets->total() }} tiket</span>
        </div>

        @forelse($tickets as $ticket)
            <article class="support-ticket">
                <div class="support-ticket-top">
                    <div>
                        <div style="font-size:11px;color:var(--muted);margin-bottom:5px">{{ $ticket->ticket_number }}</div>
                        <h3>{{ $ticket->subject }}</h3>
                    </div>
                    <span class="support-badge support-status-{{ $ticket->status }}">{{ str_replace('_', ' ', ucfirst($ticket->status)) }}</span>
                </div>
                <p class="support-muted" style="margin:9px 0 12px">{{ ucfirst($ticket->category) }} · {{ $ticket->created_at->format('d/m/Y H:i') }}</p>
                <div style="white-space:pre-wrap;font-size:14px;line-height:1.7">{{ $ticket->message }}</div>

                @if($ticket->attachment_path)
                    <p style="margin-top:12px">
                        <a href="{{ route('support.attachment', $ticket) }}" target="_blank" rel="noopener">
                            <i class="bi bi-image"></i> Lihat gambar lampiran
                        </a>
                    </p>
                @endif

                @if($ticket->admin_reply)
                    <div class="support-reply">
                        <strong><i class="bi bi-reply-fill"></i> BALASAN ADMIN</strong>
                        <div style="white-space:pre-wrap;line-height:1.7;margin-top:8px">{{ $ticket->admin_reply }}</div>
                    </div>
                @endif
            </article>
        @empty
            <div class="support-empty">
                <div style="font-size:30px;margin-bottom:10px"><i class="bi bi-chat-square-text"></i></div>
                <strong>Belum ada laporan</strong>
                <p style="font-size:13px;margin:7px 0 0">Jika mengalami kendala, kirim laporan pertamamu melalui formulir di atas.</p>
            </div>
        @endforelse

        <div style="margin-top:16px">{{ $tickets->links() }}</div>
    </section>
</div>
@endsection

<script>
document.addEventListener('DOMContentLoaded', function () {
    const input = document.getElementById('attachment');
    const preview = document.getElementById('attachment-preview');
    if (!input || !preview) return;

    input.addEventListener('change', function () {
        const file = this.files && this.files[0];
        if (!file) {
            preview.removeAttribute('src');
            preview.style.display = 'none';
            return;
        }

        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) ||
            file.size > 5 * 1024 * 1024) {
            alert('Pilih gambar JPG, PNG, atau WebP dengan ukuran maksimal 5 MB.');
            this.value = '';
            preview.removeAttribute('src');
            preview.style.display = 'none';
            return;
        }

        preview.src = URL.createObjectURL(file);
        preview.style.display = 'block';
    });
});
</script>
