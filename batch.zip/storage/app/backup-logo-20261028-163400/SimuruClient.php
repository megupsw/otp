<?php
namespace App\Services;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;
class SimuruClient {
    private function request(string $path, array $params=[]): array {
        $key=config('services.simuru.key');
        if (!$key) throw new RuntimeException('SIMURU_API_KEY belum diatur di .env');
        $response=Http::acceptJson()->timeout((int)config('services.simuru.timeout',12))
            ->get(rtrim(config('services.simuru.base_url'),'/' ).'/'.ltrim($path,'/'), array_merge($params,['apikey'=>$key]));
        if (!$response->successful()) {
            $body = $response->json();
            $detail = '';
            if (is_array($body)) {
                $message = $body['message'] ?? $body['error'] ?? $body['detail'] ?? null;
                if (is_string($message) && $message !== '') {
                    $detail = ': ' . $message;
                } elseif (isset($body['errors'])) {
                    $detail = ': ' . json_encode($body['errors'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                }
            }
            Log::warning('SIMURU request gagal.', [
                'http_status' => $response->status(),
                'provider_detail' => $detail,
            ]);
            throw new RuntimeException('Layanan provider sedang tidak tersedia.');
        }
        $json=$response->json();
        if (!is_array($json) || !($json['success'] ?? false)) throw new RuntimeException($json['message'] ?? 'Respons SIMURU tidak berhasil');
        return $json;
    }
    public function services(): array { return Cache::remember('simuru.services',300,fn()=> $this->request('services')['data'] ?? []); }
    public function countries(): array { return Cache::remember('simuru.countries',900,fn()=> $this->request('countries')['data'] ?? []); }
    public function pricelist(?string $service=null): array {
        $params=$service ? ['service_id'=>$service] : [];
        return Cache::remember('simuru.pricelist.'.($service ?: 'all'),60,fn()=> $this->request('pricelist',$params)['data'] ?? []);
    }
    public function insightsCountries(): array
    {
        return Cache::remember(
            'simuru.insights.countries',
            1800,
            fn () => $this->request('insights/countries')['data'] ?? []
        );
    }

    public function createOrder(string $serviceId, int $countryId, string $operator='random'): array {
        return $this->request('order/create',['service_id'=>$serviceId,'country_id'=>$countryId,'operator'=>$operator]);
    }
    public function activeOrders(): array { return $this->request('orders/active')['data'] ?? []; }
    public function activeDetail(int $id): array { return $this->request('orders/active/detail',['order_id'=>$id])['data'] ?? []; }
    public function cancel(int $id): array { return $this->request('order/cancel',['order_id'=>$id]); }
    public function finish(int $id): array { return $this->request('order/finish',['order_id'=>$id]); }

    public function createDeposit(int $amount, string $method='qris', ?string $note=null): array
    {
        $params = ['amount' => $amount, 'method' => $method];
        if ($note !== null && $note !== '') {
            $params['note'] = mb_substr($note, 0, 255);
        }
        return $this->request('deposit/create', $params);
    }

    public function depositStatus(int $depositId): array
    {
        return $this->request('deposit/status', ['deposit_id' => $depositId])['data'] ?? [];
    }
    public function history(array $params=[]): array { return $this->request('orders-history',$params)['data'] ?? []; }

    public function historyDetail(int $id): array
    {
        return $this->request('orders-history/detail', [
            'order_id' => $id,
            'source' => 'history',
        ])['data'] ?? [];
    }

    public function findHistoryByExternalId(string $externalId): array
    {
        if ($externalId === '') {
            return [];
        }

        for ($page = 1; $page <= 5; $page++) {
            $rows = $this->history([
                'limit' => 100,
                'page' => $page,
            ]);

            if (!is_array($rows) || $rows === []) {
                break;
            }

            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }

                $rowExternalId = (string) ($row['provider_order_id'] ?? '');

                if ($rowExternalId !== $externalId) {
                    continue;
                }

                $historyId = $row['id'] ?? null;

                if ($historyId === null || !is_numeric($historyId)) {
                    continue;
                }

                return $this->historyDetail((int) $historyId);
            }

            if (count($rows) < 100) {
                break;
            }
        }

        return [];
    }
}
