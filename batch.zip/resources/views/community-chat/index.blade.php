@extends('layouts.app')
@section('title', 'Chat Komunitas')
@section('crumb', 'KOMUNITAS')
@section('heading', 'Chat Komunitas')

@section('content')
<style>
.community-chat{display:flex;flex-direction:column;gap:14px}
.chat-intro{padding:17px;border:1px solid var(--line);border-radius:16px;background:var(--panel)}
.chat-intro p{margin:6px 0 0;color:var(--muted);font-size:13px}
.chat-box{height:min(58vh,600px);min-height:320px;overflow:auto;padding:14px;border:1px solid var(--line);border-radius:16px;background:var(--panel);display:flex;flex-direction:column;gap:12px}
.chat-item{max-width:90%;align-self:flex-start;min-width:0}
.chat-item.mine{align-self:flex-end}
.chat-bubble{padding:11px 13px;border:1px solid var(--line);border-radius:14px;background:var(--bg);overflow-wrap:anywhere}
.chat-item.mine .chat-bubble{background:rgba(59,130,246,.12);border-color:rgba(59,130,246,.35)}
.chat-meta{display:flex;justify-content:space-between;gap:12px;color:var(--muted);font-size:11px;margin:0 2px 5px}
.chat-text{white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px}
.chat-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:7px}
.chat-actions button{border:0;background:transparent;color:var(--muted);cursor:pointer;font-size:12px;padding:3px}
.chat-compose{display:flex;gap:9px;align-items:flex-end}
.chat-compose textarea{flex:1;min-width:0;resize:vertical;min-height:48px;max-height:140px}
.chat-status{font-size:12px;color:var(--muted)}
@media(max-width:560px){.chat-box{height:55vh;min-height:280px;padding:10px}.chat-item{max-width:96%}.chat-compose{gap:7px}}
</style>

<div class="community-chat">
    <div class="chat-intro">
        <strong>💬 Ruang Chat Komunitas</strong>
        <p>Semua pengguna dapat berdiskusi di sini. Jaga sopan santun dan jangan membagikan informasi pribadi.</p>
    </div>

    <div id="chat-box" class="chat-box" aria-live="polite">
        <p class="chat-status">Memuat pesan...</p>
    </div>

    <form id="chat-form" class="chat-compose">
        @csrf
        <textarea id="chat-input" maxlength="2000" placeholder="Tulis pesan komunitas..." required></textarea>
        <button id="chat-send" class="btn primary" type="submit">Kirim</button>
    </form>
    <div id="chat-status" class="chat-status">Pesan diperbarui otomatis.</div>
</div>

<script>
(() => {
    const box = document.getElementById('chat-box');
    const form = document.getElementById('chat-form');
    const input = document.getElementById('chat-input');
    const status = document.getElementById('chat-status');
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    const token = csrfMeta ? csrfMeta.content : '';
    if (!csrfMeta) {
        console.error('Chat Komunitas: meta CSRF tidak ditemukan.');
    }
    const messagesUrl = @json(route('community-chat.messages'));
    const storeUrl = @json(route('community-chat.store'));
    const updateBase = @json(url('/chat-komunitas/messages'));
    let currentUserId = null;
    let isAdmin = false;
    let lastSignature = '';
    let busy = false;

    async function request(url, method = 'GET', data = null) {
        const response = await fetch(url, {
            method,
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': token,
                ...(data ? {'Content-Type': 'application/json'} : {})
            },
            ...(data ? {body: JSON.stringify(data)} : {})
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.message || 'Permintaan gagal.');
        return result;
    }

    function render(messages) {
        const signature = JSON.stringify(messages);
        if (signature === lastSignature) return;
        const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 90;
        lastSignature = signature;
        box.replaceChildren();

        if (!messages.length) {
            const empty = document.createElement('p');
            empty.className = 'chat-status';
            empty.textContent = 'Belum ada pesan. Jadilah yang pertama menyapa!';
            box.appendChild(empty);
            return;
        }

        for (const item of messages) {
            const wrapper = document.createElement('div');
            wrapper.className = 'chat-item' + (item.user_id === currentUserId ? ' mine' : '');

            const meta = document.createElement('div');
            meta.className = 'chat-meta';
            const name = document.createElement('strong');
            name.textContent = item.name + (item.user_id === currentUserId ? ' (Kamu)' : '');
            const time = document.createElement('span');
            time.textContent = new Date(item.created_at).toLocaleString('id-ID', {
                day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
            });
            meta.append(name, time);

            const bubble = document.createElement('div');
            bubble.className = 'chat-bubble';
            const text = document.createElement('div');
            text.className = 'chat-text';
            text.textContent = item.message;
            bubble.appendChild(text);
            wrapper.append(meta, bubble);

            if (item.user_id === currentUserId || isAdmin) {
                const actions = document.createElement('div');
                actions.className = 'chat-actions';

                if (item.user_id === currentUserId) {
                    const edit = document.createElement('button');
                    edit.type = 'button';
                    edit.textContent = 'Edit';
                    edit.addEventListener('click', async () => {
                        const revised = prompt('Edit pesan:', item.message);
                        if (revised === null || !revised.trim()) return;
                        try {
                            await request(`${updateBase}/${item.id}`, 'PUT', {message: revised.trim()});
                            lastSignature = '';
                            await load();
                        } catch (error) { status.textContent = error.message; }
                    });
                    actions.appendChild(edit);
                }

                const del = document.createElement('button');
                del.type = 'button';
                del.textContent = 'Hapus';
                del.addEventListener('click', async () => {
                    if (!confirm('Hapus pesan ini?')) return;
                    try {
                        await request(`${updateBase}/${item.id}`, 'DELETE');
                        lastSignature = '';
                        await load();
                    } catch (error) { status.textContent = error.message; }
                });
                actions.appendChild(del);
                wrapper.appendChild(actions);
            }

            box.appendChild(wrapper);
        }
        if (nearBottom) box.scrollTop = box.scrollHeight;
    }

    async function load() {
        if (busy) return;
        busy = true;
        try {
            const result = await request(messagesUrl);
            currentUserId = result.current_user_id;
            isAdmin = result.is_admin;
            render(result.messages);
        } catch (error) {
            status.textContent = error.message;
        } finally {
            busy = false;
        }
    }

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const message = input.value.trim();
        if (!message) return;
        const send = document.getElementById('chat-send');
        send.disabled = true;
        try {
            await request(storeUrl, 'POST', {message});
            input.value = '';
            lastSignature = '';
            await load();
            box.scrollTop = box.scrollHeight;
            status.textContent = 'Pesan terkirim.';
        } catch (error) {
            status.textContent = error.message;
        } finally {
            send.disabled = false;
            input.focus();
        }
    });

    load();
    window.setInterval(load, 5000);
})();
</script>
@endsection
