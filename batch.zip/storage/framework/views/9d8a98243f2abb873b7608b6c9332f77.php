<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
    try {
        document.documentElement.dataset.theme =
            localStorage.getItem('depuka-login-theme') === 'dark' ? 'dark' : 'light';
    } catch(e) {}
    </script>
    <meta name="theme-color" content="#080d19">
    <meta name="description" content="<?php echo e(setting('site_name', 'Digistore OTP')); ?>, layanan nomor virtual dan verifikasi OTP dengan proses praktis melalui satu dashboard.">
    <title><?php echo e(setting('site_name', 'Digistore OTP')); ?> — Verifikasi Jadi Praktis</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            color-scheme: light;
            --bg: #f4f7fc;
            --panel: #ffffff;
            --line: #e2e8f2;
            --muted: #65718a;
            --blue: #4f6df5;
            --cyan: #087eae;
            --white: #172033;
            --surface-shadow: 0 18px 55px rgba(40, 62, 110, .09);
        }
        html[data-theme="dark"] {
            color-scheme: dark;
            --bg: #080d19;
            --panel: #111a2b;
            --line: #243149;
            --muted: #9baaca;
            --blue: #5478ff;
            --cyan: #61d5ff;
            --white: #f7f9ff;
            --surface-shadow: 0 25px 70px rgba(0, 0, 0, .24);
        }
        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
            margin: 0;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, sans-serif;
            color: var(--white);
            background:
                radial-gradient(ellipse at 80% 5%, #173b8250, transparent 34rem),
                radial-gradient(ellipse at 5% 35%, #193b7030, transparent 32rem),
                var(--bg);
        }
        a { color: inherit; text-decoration: none; }
        .container { width: min(1120px, calc(100% - 40px)); margin: auto; }
        .nav {
            height: 78px; display: flex; align-items: center;
            justify-content: space-between; gap: 20px;
            border-bottom: 1px solid var(--line);
        }
        .brand { display: flex; align-items: center; gap: 11px; font-weight: 800; }
        .brand-icon {
            width: 42px; height: 42px; display: grid; place-items: center;
            border-radius: 14px; background: linear-gradient(140deg, #7894ff, #4058e8);
            box-shadow: 0 8px 30px #526eff40; font-size: 22px;
        }
        .brand small { display: block; color: var(--cyan); font-size: 10px; letter-spacing: 2px; }
        .nav-links { display: flex; align-items: center; gap: 27px; color: var(--muted); font-size: 13px; }
        .nav-links a:hover, .footer a:hover { color: var(--blue); }
        .btn {
            display: inline-flex; align-items: center; justify-content: center; gap: 9px;
            min-height: 46px; padding: 0 20px; border-radius: 12px;
            font-size: 13px; font-weight: 750; border: 1px solid var(--line);
            transition: .2s ease;
        }
        .btn:hover { transform: translateY(-2px); }
        .btn-primary { background: linear-gradient(135deg, #6685ff, #4560ed); border-color: transparent; box-shadow: 0 10px 30px #4560ed30; }
        .btn-secondary { background: var(--panel); }
        .hero {
            min-height: 560px; display: grid; grid-template-columns: 1.05fr .95fr;
            align-items: center; gap: 55px; padding-top: 65px; padding-bottom: 75px;
        }
        .eyebrow {
            display: inline-flex; gap: 9px; align-items: center; color: var(--blue);
            border: 1px solid #5778ff45; background: color-mix(in srgb, var(--blue) 8%, var(--panel));
            border-radius: 999px; padding: 9px 13px; font-size: 11px; font-weight: 750;
            letter-spacing: 1px;
        }
        .dot { width: 7px; height: 7px; border-radius: 50%; background: #65e8b1; box-shadow: 0 0 12px #65e8b1; }
        h1 { font-size: clamp(40px, 5.5vw, 66px); line-height: 1.06; letter-spacing: -2.8px; margin: 24px 0 20px; }
        .gradient-text { background: linear-gradient(100deg, #4f61df, #078ebd); color: transparent; background-clip: text; }
        .hero-copy { max-width: 520px; color: var(--muted); font-size: 15px; line-height: 1.9; }
        .hero-actions { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 30px; }
        .trust { display: flex; flex-wrap: wrap; gap: 20px; margin-top: 28px; color: var(--muted); font-size: 11px; }
        .trust span::first-letter { color: #6ce5b5; }
        .visual { position: relative; padding: 15px; }
        .glow { position: absolute; inset: 12% 8%; background: #4167ff38; filter: blur(65px); }
        .mockup {
            position: relative; border: 1px solid #354564; border-radius: 23px;
            background: linear-gradient(150deg, #16233a, #0c1322 78%);
            padding: 23px; box-shadow: 0 30px 90px #0008;
            transform: perspective(1100px) rotateY(-5deg) rotateX(2deg);
        }
        .mock-head { display: flex; justify-content: space-between; align-items: center; padding-bottom: 19px; border-bottom: 1px solid var(--line); }
        .mock-title { font-size: 13px; font-weight: 800; }
        .live { font-size: 10px; color: #70e6b7; background: #1b9b6b1c; border-radius: 20px; padding: 7px 9px; }
        .mock-label { margin: 22px 0 8px; color: var(--muted); font-size: 11px; }
        .service { display: flex; align-items: center; gap: 13px; padding: 15px 0; border-bottom: 1px solid var(--line); }
        .service-icon { width: 42px; height: 42px; display: grid; place-items: center; border-radius: 13px; background: color-mix(in srgb, var(--blue) 12%, var(--panel)); font-weight: 900; }
        .service-name { font-size: 13px; font-weight: 800; }
        .service-sub { margin-top: 5px; color: var(--muted); font-size: 10px; }
        .price { margin-left: auto; text-align: right; font-size: 12px; font-weight: 800; }
        .price small { display: block; margin-bottom: 5px; color: var(--muted); font-size: 9px; font-weight: 400; }
        .otp-box { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 20px; padding: 16px; border: 1px dashed var(--blue); background: color-mix(in srgb, var(--blue) 5%, var(--panel)); border-radius: 13px; }
        .otp-box small { display: block; color: var(--muted); font-size: 9px; margin-bottom: 5px; }
        .otp-number { font-size: 23px; letter-spacing: 5px; font-weight: 850; }
        .demo-note { color: var(--muted); font-size: 10px; line-height: 1.6; margin-top: 12px; }
        .section { padding: 70px 0; }
        .section-head { max-width: 620px; margin: 0 auto 35px; text-align: center; }
        .section-head h2 { font-size: clamp(27px, 3.5vw, 38px); letter-spacing: -1px; margin: 13px 0; }
        .section-head p { color: var(--muted); line-height: 1.8; font-size: 13px; }
        .features { display: grid; grid-template-columns: repeat(3, 1fr); gap: 17px; }
        .feature { border: 1px solid var(--line); background: var(--panel); border-radius: 18px; padding: 25px; }
        .feature-icon { width: 45px; height: 45px; display: grid; place-items: center; border: 1px solid #5a79ff45; background: #4d6dff18; border-radius: 13px; font-size: 21px; }
        .feature h3 { font-size: 15px; margin: 20px 0 10px; }
        .feature p { color: var(--muted); font-size: 12px; line-height: 1.85; margin: 0; }
        .steps { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; counter-reset: step; }
        .step { padding: 20px 5px; }
        .step-num { color: #91a5ff; font-size: 12px; font-weight: 850; letter-spacing: 2px; }
        .step h3 { font-size: 15px; margin: 13px 0 8px; }
        .step p { color: var(--muted); font-size: 12px; line-height: 1.8; }
        .cta {
            text-align: center; padding: 48px 24px; border: 1px solid #4665b9;
            border-radius: 24px; background: radial-gradient(ellipse at top, #3359b83b, #111a2b 70%);
        }
        .cta h2 { font-size: clamp(26px, 4vw, 39px); margin: 0 0 13px; }
        .cta p { color: var(--muted); font-size: 13px; line-height: 1.8; margin-bottom: 25px; }
        .footer { margin-top: 65px; padding: 25px 0; border-top: 1px solid var(--line); display: flex; justify-content: space-between; gap: 20px; color: var(--muted); font-size: 11px; }
        .footer-links { display: flex; gap: 20px; }
        @media (max-width: 800px) {
            .nav { height: 70px; }
            .nav-links { gap: 12px; }
            .nav-links .optional { display: none; }
            .nav-links .btn { min-height: 39px; padding: 0 13px; }
            .hero { grid-template-columns: 1fr; gap: 30px; padding-top: 55px; }
            .hero-copy { font-size: 14px; }
            .visual { max-width: 520px; width: 100%; margin: auto; }
            .mockup { transform: none; }
            .features { grid-template-columns: 1fr; }
            .feature { padding: 22px; }
            .steps { grid-template-columns: 1fr; gap: 5px; }
            .section { padding: 48px 0; }
            .footer { flex-direction: column; }
        }
        @media (max-width: 420px) {
            .container { width: min(100% - 28px, 1120px); }
            h1 { letter-spacing: -1.7px; }
            .brand { font-size: 14px; }
            .brand-icon { width: 37px; height: 37px; }
            .hero-actions .btn { flex: 1; padding: 0 12px; }
            .mockup { padding: 17px; }
            .otp-number { font-size: 19px; letter-spacing: 3px; }
        }

        /* Efek mengetik untuk judul utama */
        .typewriter-text {
            display: inline;
            white-space: normal;
            overflow-wrap: anywhere;
        }
        .typing-cursor {
            display: inline-block;
            width: 3px;
            height: .82em;
            margin-left: 5px;
            vertical-align: -.02em;
            border-radius: 3px;
            background: var(--cyan);
            box-shadow: 0 0 14px #61d5ff90;
            animation: cursorBlink .8s steps(2, start) infinite;
        }
        @keyframes cursorBlink {
            to { opacity: 0; }
        }
        @media (prefers-reduced-motion: reduce) {
            .typing-cursor { animation: none; }
        }

        .theme-toggle {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 9px 12px; border: 1px solid var(--line);
            border-radius: 999px; background: var(--panel);
            color: var(--white); cursor: pointer; font-size: 12px;
            font-weight: 700;
        }
        .theme-toggle:hover { border-color: var(--blue); }
        html[data-theme="light"] .mockup {
            background: linear-gradient(150deg, #ffffff, #f3f6fc 78%);
            border-color: #dbe3f0;
            box-shadow: 0 25px 70px #26385c1a;
        }
        html[data-theme="light"] .feature {
            background: #ffffffd9;
            border-color: var(--line);
            box-shadow: 0 8px 30px #26385c08;
        }
        html[data-theme="light"] .cta {
            background: radial-gradient(ellipse at top, #dfe8ff, #ffffff 72%);
            border-color: #cbd7f4;
        }
        html[data-theme="light"] .nav { border-color: var(--line); }
        html[data-theme="light"] .btn-secondary { background: #ffffff; }
        html[data-theme="light"] .nav-links a:hover,
        html[data-theme="light"] .footer a:hover { color: var(--blue); }
        html[data-theme="light"] .service { border-color: var(--line); }
        html[data-theme="light"] .service-icon { background: #e8edff; color: #344dcc; }
        html[data-theme="light"] .otp-box { background: #f4f6ff; }
        html[data-theme="light"] .demo-note { color: #71809a; }
        html[data-theme="light"] .trust { color: #65718a; }
        html[data-theme="light"] .eyebrow { color: #4058c9; background: #edf1ff; }
        html[data-theme="light"] .gradient-text {
            background-image: linear-gradient(100deg, #4f61df, #078ebd);
        }
        html[data-theme="light"] .section-head .eyebrow { color: #4058c9; }
        html[data-theme="light"] .step-num { color: #4f61df; }
        html[data-theme="light"] .feature-icon { color: #4058c9; }
        @media (prefers-reduced-motion: reduce) {
            .theme-toggle { transition: none; }
        }

        .theme-toggle {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 40px;
            padding: 0 13px;
            border: 1px solid var(--line);
            border-radius: 999px;
            background: var(--panel);
            color: var(--white);
            cursor: pointer;
            white-space: nowrap;
            font-size: 12px;
            font-weight: 700;
            transition: .2s ease;
        }
        .theme-toggle:hover { border-color: var(--blue); }
        .mockup, .feature, .cta { transition: background .25s, border-color .25s, box-shadow .25s; }
        .feature { box-shadow: var(--surface-shadow); }
        .feature-icon { color: var(--blue); }
        .section-head .eyebrow { color: var(--blue); }
        .step-num { color: var(--blue); }
        .service-icon { color: var(--blue); }
        .footer { border-color: var(--line); }

        @media (max-width: 800px) {
            .container { width: min(100% - 32px, 620px); }
            .nav {
                height: auto;
                min-height: 72px;
                padding: 14px 0;
                flex-wrap: wrap;
                gap: 14px;
            }
            .nav-links {
                width: 100%;
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                gap: 9px;
            }
            .nav-links .optional { display: none; }
            .nav-links .btn, .theme-toggle {
                flex: 1 1 auto;
                min-height: 42px;
                padding: 0 12px;
            }
            .hero {
                min-height: auto;
                grid-template-columns: minmax(0, 1fr);
                gap: 30px;
                padding-top: 44px;
                padding-bottom: 35px;
            }
            .hero > div:first-child { min-width: 0; }
            h1 {
                font-size: clamp(38px, 9vw, 58px);
                line-height: 1.1;
                letter-spacing: -1.8px;
                overflow-wrap: break-word;
            }
            .hero-copy { font-size: 14px; }
            .hero-actions { gap: 10px; }
            .hero-actions .btn { flex: 1 1 180px; padding: 0 13px; text-align: center; }
            .trust { gap: 12px; line-height: 1.7; }
            .visual { width: 100%; max-width: 540px; margin: auto; padding: 4px 0; }
            .mockup { transform: none; padding: clamp(16px, 4vw, 23px); }
            .features { grid-template-columns: 1fr; }
            .steps { grid-template-columns: 1fr; gap: 5px; }
            .section { padding: 45px 0; }
            .cta { padding: 35px 18px; }
            .footer { flex-direction: column; margin-top: 35px; }
        }
        @media (max-width: 420px) {
            .container { width: calc(100% - 28px); }
            .brand { font-size: 14px; }
            .brand-icon { width: 37px; height: 37px; }
            .nav-links { gap: 7px; }
            .nav-links .btn, .theme-toggle { font-size: 11px; padding: 0 8px; }
            h1 { font-size: clamp(34px, 10vw, 42px); letter-spacing: -1.5px; }
            .eyebrow { font-size: 9px; padding: 8px 10px; }
            .hero-actions .btn { flex-basis: 100%; }
            .mock-head { gap: 8px; }
            .service { gap: 9px; }
            .service-icon { width: 36px; height: 36px; flex: 0 0 36px; }
            .service-name { font-size: 12px; }
            .service-sub { font-size: 9px; }
            .price { font-size: 11px; }
            .otp-number { font-size: 19px; letter-spacing: 3px; }
            .footer-links { flex-wrap: wrap; }
        }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { scroll-behavior: auto !important; transition: none !important; }
        }
    
        /* Polesan akhir Light/Dark Mode Depuka */
        html[data-theme="light"] {
            --bg: #edf2fa;
            --panel: #ffffff;
            --line: #dce5f2;
            --muted: #64748b;
            --blue: #405ff0;
            --cyan: #078bbd;
            --white: #17243b;
            --surface-shadow: 0 14px 38px rgba(35, 58, 100, .08);
        }

        html[data-theme="light"] body {
            background:
                radial-gradient(ellipse at 82% 8%, rgba(100, 149, 255, .13), transparent 30rem),
                radial-gradient(ellipse at 5% 42%, rgba(110, 160, 230, .10), transparent 27rem),
                linear-gradient(145deg, #f7f9fd 0%, #edf2fa 58%, #f5f8fd 100%);
        }

        html[data-theme="light"] .nav {
            border-bottom-color: #dce5f2;
        }

        html[data-theme="light"] .mockup {
            background: linear-gradient(145deg, #fff 0%, #f9fbff 100%);
            border-color: #dbe5f3;
            box-shadow: 0 24px 65px rgba(54, 83, 140, .13);
        }

        html[data-theme="light"] .feature {
            background: rgba(255,255,255,.88);
            border-color: #e0e7f1;
            box-shadow: 0 10px 28px rgba(40, 60, 100, .055);
        }

        html[data-theme="light"] .cta {
            background: linear-gradient(135deg, #f8faff, #e8efff);
            border-color: #d4def5;
        }

        html[data-theme="light"] .btn-secondary {
            background: #fff;
            border-color: #dce5f2;
            color: #263653;
        }

        html[data-theme="light"] .theme-toggle {
            appearance: none;
            border: 1px solid #dce5f2;
            border-radius: 999px;
            background: #fff;
            color: #263653;
            box-shadow: 0 3px 10px rgba(35,58,100,.04);
            font-family: inherit;
        }

        html[data-theme="light"] .service-icon {
            background: #e9efff;
            color: #405ff0;
        }

        html[data-theme="light"] .otp-box {
            background: #f5f7ff;
            border-color: #b7c7fa;
        }

        html[data-theme="light"] .live {
            color: #087d59;
            background: #dff8ee;
        }

        html[data-theme="light"] .eyebrow {
            color: #4055c4;
            background: #edf1ff;
            border-color: #d4ddff;
        }

        html[data-theme="light"] .gradient-text {
            background-image: linear-gradient(100deg, #465ee8, #078fbe);
        }

        html[data-theme="light"] .trust {
            color: #64748b;
        }

        html[data-theme="light"] .footer {
            border-top-color: #dce5f2;
        }

        html[data-theme="dark"] .theme-toggle {
            appearance: none;
            border: 1px solid var(--line);
            font-family: inherit;
        }

        .theme-toggle {
            min-height: 40px;
            border-radius: 999px;
            padding: 0 15px;
            box-shadow: 0 3px 12px rgba(35,58,100,.05);
        }

        .theme-toggle i {
            font-size: 14px;
            color: var(--blue);
        }

        .section-head h2 {
            text-wrap: balance;
        }

        .section-head p {
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        @media (min-width: 801px) {
            .section-head h2 {
                font-size: clamp(27px, 3vw, 36px);
            }
        }

        @media (max-width: 800px) {
            html[data-theme="light"] body {
                background:
                    radial-gradient(ellipse at 80% 8%, rgba(100,149,255,.10), transparent 24rem),
                    #f2f5fb;
            }

            .hero {
                padding-top: 38px;
            }

            .section-head h2 {
                max-width: 540px;
                margin-left: auto;
                margin-right: auto;
            }
        }

        @media (max-width: 420px) {
            .theme-toggle {
                min-height: 40px;
                padding: 0 9px;
                font-size: 11px;
            }

            .section-head h2 {
                font-size: 27px;
                line-height: 1.2;
                letter-spacing: -.7px;
            }
        }

    
        /* Konsistensi warna kartu pada kedua tema */
        html[data-theme="light"] body {
            background:
                radial-gradient(ellipse at 82% 8%, rgba(105,145,235,.10), transparent 28rem),
                linear-gradient(145deg, #f7f9fd, #edf2fa 65%, #f7f9fd);
        }

        html[data-theme="light"] .mockup {
            background: #ffffff;
            border-color: #dce5f2;
            box-shadow: 0 18px 50px rgba(40,60,100,.10);
            color: #172033;
        }

        html[data-theme="light"] .mockup .muted,
        html[data-theme="light"] .mockup small,
        html[data-theme="light"] .mockup .service-sub,
        html[data-theme="light"] .mockup .demo-note {
            color: #71809a;
        }

        html[data-theme="light"] .mockup .service {
            border-bottom-color: #e5eaf2;
        }

        html[data-theme="light"] .mockup .service-icon {
            background: #eaf0ff;
            color: #405ff0;
        }

        html[data-theme="light"] .mockup .otp-box {
            background: #f5f7ff;
            border-color: #aabcf5;
        }

        html[data-theme="light"] .feature {
            color: #172033;
            background: #fff;
            border-color: #e1e7f0;
        }

        html[data-theme="light"] .cta {
            color: #172033;
            background: linear-gradient(135deg, #f8faff, #eaf0ff);
            border-color: #dce5f2;
        }

        html[data-theme="light"] .nav-links {
            color: #5e6c84;
        }

        html[data-theme="light"] .btn-secondary {
            color: #263653;
            background: #fff;
            border-color: #dce5f2;
        }

        html[data-theme="dark"] .mockup {
            background: linear-gradient(150deg, #16233a, #0c1322 78%);
            border-color: #354564;
            box-shadow: 0 30px 90px #0008;
            color: #f7f9ff;
        }

        .theme-toggle {
            appearance: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 42px;
            padding: 0 15px;
            border: 1px solid var(--line);
            border-radius: 999px;
            background: var(--panel);
            color: var(--white);
            box-shadow: 0 3px 12px rgba(35,58,100,.05);
            font-family: inherit;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
        }

        .theme-toggle i {
            color: var(--blue);
            font-size: 14px;
        }

        @media (max-width: 800px) {
            .hero {
                min-height: auto;
                grid-template-columns: minmax(0, 1fr);
                gap: 25px;
                padding-top: 40px;
                padding-bottom: 40px;
            }
            .visual { width: 100%; max-width: 560px; margin: auto; }
            .mockup { transform: none; }
        }

    
        /* Tombol navbar lebih tegas dan mudah dibaca */
        .nav-links {
            gap: 20px;
        }

        .nav-links > a.btn {
            min-height: 46px;
            padding: 0 23px;
            font-size: 13px;
            font-weight: 800;
            letter-spacing: .1px;
            border-radius: 12px;
            border-width: 1px;
        }

        .btn-primary {
            color: #ffffff !important;
            background: linear-gradient(135deg, #536ff5 0%, #3d58e8 100%);
            border-color: #435de9;
            box-shadow: 0 5px 15px rgba(63, 88, 232, .24);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #405fe9 0%, #3049d4 100%);
            box-shadow: 0 8px 20px rgba(63, 88, 232, .32);
            transform: translateY(-2px);
        }

        .btn-secondary {
            color: #24324c !important;
            background: #ffffff;
            border: 1px solid #cbd6e8;
            box-shadow: 0 3px 10px rgba(35, 58, 100, .06);
        }

        .btn-secondary:hover {
            background: #edf2ff;
            border-color: #8198f7;
            color: #304bd0 !important;
        }

        .theme-toggle {
            min-height: 44px;
            padding: 0 16px;
            border: 1px solid #cbd6e8;
            border-radius: 999px;
            background: #ffffff;
            color: #263653;
            font-size: 12px;
            font-weight: 800;
            box-shadow: 0 3px 12px rgba(35, 58, 100, .07);
        }

        .theme-toggle i {
            color: #405ff0;
            font-size: 15px;
        }

        html[data-theme="dark"] .btn-secondary {
            color: #f3f6ff !important;
            background: #17233a;
            border-color: #3a4b6b;
        }

        html[data-theme="dark"] .btn-secondary:hover {
            background: #223354;
            border-color: #718aff;
            color: #ffffff !important;
        }

        html[data-theme="dark"] .theme-toggle {
            color: #f3f6ff;
            background: #17233a;
            border-color: #3a4b6b;
        }

        html[data-theme="dark"] .theme-toggle i {
            color: #9eb0ff;
        }

        .nav-links a,
        .nav-links button {
            flex-shrink: 0;
        }

        @media (max-width: 800px) {
            .nav-links > a.btn,
            .nav-links .theme-toggle {
                min-height: 43px;
                padding: 0 12px;
                font-weight: 800;
            }
        }

    </style>
</head>
<body>
    <div class="container">
        <nav class="nav">
            <a class="brand" href="<?php echo e(url('/')); ?>">
                <span class="brand-icon">D</span>
                <span><?php echo e(setting('brand_name', 'Digistore')); ?> <small>OTP PLATFORM</small></span>
            </a>
            <div class="nav-links">
                <button class="theme-toggle" id="themeToggle" type="button" aria-label="Ganti tema">
                    <i class="bi bi-moon-stars-fill" id="themeIcon" aria-hidden="true"></i><span id="themeLabel">Mode gelap</span>
                </button>
                <a class="optional" href="#fitur">Fitur</a>
                <a class="optional" href="#cara-kerja">Cara Kerja</a>
                <a class="btn btn-secondary" href="<?php echo e(route('login')); ?>">Masuk</a>
                <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Daftar</a>
            </div>
        </nav>

        <main>
            <section class="hero">
                <div>
                    <div class="eyebrow"><span class="dot"></span> PLATFORM VERIFIKASI OTP</div>
                    <h1>Verifikasi nomor,<br><span class="gradient-text typewriter-text" id="typewriterText">lebih praktis.</span><span class="typing-cursor" aria-hidden="true"></span></h1>
                    <p class="hero-copy">
                        Kelola pesanan nomor virtual dan pantau kode OTP melalui satu dashboard.
                        Proses praktis, tampilan mudah digunakan, dan informasi pesanan dalam satu tempat.
                    </p>
                    <div class="hero-actions">
                        <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Mulai Sekarang <span>→</span></a>
                        <a class="btn btn-secondary" href="<?php echo e(route('login')); ?>">Saya Sudah Punya Akun</a>
                    </div>
                    <div class="trust">
                        <span>✓ Dashboard praktis</span>
                        <span>✓ Pemantauan OTP</span>
                        <span>✓ Riwayat pesanan</span>
                    </div>
                </div>

                <div class="visual" aria-label="Ilustrasi dashboard <?php echo e(setting('site_name', 'Digistore OTP')); ?>">
                    <div class="glow"></div>
                    <div class="mockup">
                        <div class="mock-head">
                            <div class="mock-title">Pratinjau Dashboard</div>
                            <span class="live">● DEMO UI</span>
                        </div>
                        <div class="mock-label">Contoh layanan</div>
                        <div class="service">
                            <div class="service-icon">G</div>
                            <div><div class="service-name">Grab</div><div class="service-sub">Contoh layanan OTP</div></div>
                            <div class="price"><small>Contoh harga</small>Rp 431</div>
                        </div>
                        <div class="service">
                            <div class="service-icon">W</div>
                            <div><div class="service-name">WhatsApp</div><div class="service-sub">Ketersediaan mengikuti provider</div></div>
                            <div class="price"><small>Status</small>Dinamis</div>
                        </div>
                        <div class="otp-box">
                            <div><small>CONTOH KODE OTP</small><div class="otp-number">••••••</div></div>
                            <span class="live">Privat</span>
                        </div>
                        <p class="demo-note">Ilustrasi tampilan saja. Bukan data pesanan atau kode OTP aktual.</p>
                    </div>
                </div>
            </section>

            <section class="section" id="fitur">
                <div class="section-head">
                    <div class="eyebrow">DIBUAT UNTUK KEMUDAHAN</div>
                    <h2>Semua kebutuhan OTP dalam satu tempat</h2>
                    <p>Antarmuka sederhana untuk membantu kamu mengelola pesanan tanpa berpindah-pindah halaman.</p>
                </div>
                <div class="features">
                    <article class="feature">
                        <div class="feature-icon">⚡</div>
                        <h3>Proses praktis</h3>
                        <p>Pilih layanan yang tersedia, buat pesanan, lalu pantau statusnya dari halaman akun.</p>
                    </article>
                    <article class="feature">
                        <div class="feature-icon">⌁</div>
                        <h3>Pantau kode OTP</h3>
                        <p>Lihat kode dan pesan yang diterima pada pesanan yang sedang berjalan, sesuai respons provider.</p>
                    </article>
                    <article class="feature">
                        <div class="feature-icon">◷</div>
                        <h3>Riwayat terorganisir</h3>
                        <p>Periksa pesanan sebelumnya dan pantau status pesanan melalui dashboard <?php echo e(setting('site_name', 'Digistore OTP')); ?>.</p>
                    </article>
                </div>
            </section>

            <section class="section" id="cara-kerja">
                <div class="section-head">
                    <div class="eyebrow">MULAI DALAM 3 LANGKAH</div>
                    <h2>Cara menggunakan <?php echo e(setting('site_name', 'Digistore OTP')); ?></h2>
                    <p>Ikuti alur sederhana berikut untuk mulai menggunakan layanan.</p>
                </div>
                <div class="steps">
                    <article class="step">
                        <div class="step-num">01 / AKUN</div>
                        <h3>Buat akun atau masuk</h3>
                        <p>Daftar terlebih dahulu agar pesanan dan riwayat tersimpan pada akunmu.</p>
                    </article>
                    <article class="step">
                        <div class="step-num">02 / PESANAN</div>
                        <h3>Pilih layanan yang tersedia</h3>
                        <p>Periksa layanan, negara, dan harga yang ditampilkan sebelum membuat pesanan.</p>
                    </article>
                    <article class="step">
                        <div class="step-num">03 / VERIFIKASI</div>
                        <h3>Pantau status dan OTP</h3>
                        <p>Buka halaman Pesan OTP untuk melihat pembaruan pesan dari provider.</p>
                    </article>
                </div>
            </section>

            <section class="section">
                <div class="cta">
                    <h2>Siap mulai menggunakan <?php echo e(setting('brand_name', 'Digistore')); ?>?</h2>
                    <p>Buat akun untuk mengakses dashboard dan layanan OTP yang tersedia.</p>
                    <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Buat Akun Gratis <span>→</span></a>
                </div>
            </section>
        </main>

        <footer class="footer">
            <div>© <?php echo e(date('Y')); ?> <strong><?php echo e(setting('footer_name', 'Digistore OTP')); ?></strong>. Semua hak dilindungi.</div>
            <div class="footer-links">
                <a href="<?php echo e(route('login')); ?>">Masuk</a>
                <a href="<?php echo e(route('register')); ?>">Daftar</a>
            </div>
        </footer>
    </div>

    <script>
    (() => {
        const target = document.getElementById('typewriterText');
        if (!target) return;

        const phrases = [
            'lebih praktis.',
            'lebih mudah.',
            'lebih cepat.',
            'dalam satu tempat.'
        ];

        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            target.textContent = phrases[0];
            return;
        }

        let phraseIndex = 0;
        let charIndex = phrases[0].length;
        let deleting = false;

        function typeEffect() {
            const phrase = phrases[phraseIndex];

            if (deleting) {
                charIndex--;
                target.textContent = phrase.slice(0, charIndex);
            } else {
                charIndex++;
                target.textContent = phrase.slice(0, charIndex);
            }

            let delay = deleting ? 38 : 78;

            if (!deleting && charIndex >= phrase.length) {
                deleting = true;
                delay = 1500;
            } else if (deleting && charIndex <= 0) {
                deleting = false;
                phraseIndex = (phraseIndex + 1) % phrases.length;
                delay = 300;
            }

            window.setTimeout(typeEffect, delay);
        }

        window.setTimeout(typeEffect, 1800);
    })();
    </script>
<script>
    (function () {
        const root = document.documentElement;
        const button = document.getElementById('themeToggle');
        const icon = document.getElementById('themeIcon');
        const label = document.getElementById('themeLabel');
        if (!button) return;

        function update() {
            const dark = root.dataset.theme === 'dark';
            icon.className = dark ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
            label.textContent = dark ? 'Mode terang' : 'Mode gelap';
            button.setAttribute('aria-pressed', String(dark));
        }

        update();
        button.addEventListener('click', function () {
            const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
            root.dataset.theme = next;
            try { localStorage.setItem('depuka-login-theme', next); } catch(e) {}
            update();
        });
    })();
    </script>
    </body>
</html>
<?php /**PATH /root/digistore-project/digistore-otp/resources/views/welcome.blade.php ENDPATH**/ ?>