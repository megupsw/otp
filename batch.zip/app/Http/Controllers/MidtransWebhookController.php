<?php
namespace App\Http\Controllers;
use App\Models\Topup;
use App\Services\MidtransSnap;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class MidtransWebhookController extends Controller {
    public function handle(Request $r, MidtransSnap $snap){
        $payload=$r->all();
        abort_unless($snap->validSignature($payload),403,'Invalid Midtrans signature');
        $topup=Topup::where('order_id',$payload['order_id']??'')->firstOrFail();
        $status=$payload['transaction_status']??'';
        $fraud=$payload['fraud_status']??'accept';
        if ($status==='settlement' || ($status==='capture' && $fraud==='accept')) {
            DB::transaction(function() use($topup,$payload) {
                $locked=Topup::whereKey($topup->id)->lockForUpdate()->firstOrFail();
                if ($locked->status==='paid') return;
                $user=\App\Models\User::whereKey($locked->user_id)->lockForUpdate()->firstOrFail();
                $user->increment('balance',$locked->amount);
                $locked->update(['status'=>'paid','paid_at'=>now(),'payment_type'=>$payload['payment_type']??'qris','payload'=>$payload]);
                \App\Models\WalletTransaction::create(['user_id'=>$user->id,'topup_id'=>$locked->id,'type'=>'credit','amount'=>$locked->amount,'description'=>'Top up QRIS '.$locked->order_id]);
            });
        } elseif (in_array($status,['expire','cancel','deny'],true)) {
            if ($topup->status!=='paid') $topup->update(['status'=>$status==='expire'?'expired':'failed','payload'=>$payload]);
        }
        return response()->json(['ok'=>true]);
    }
}
