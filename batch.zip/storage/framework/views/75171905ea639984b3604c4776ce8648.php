<!doctype html>
<html lang="id" data-theme="<?php echo e(auth()->user()->theme ?? 'dark'); ?>">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"><link rel="icon" href="<?php echo e(setting('favicon_path') ? asset(setting('favicon_path')) . '?v=' . setting('favicon_updated_at', '1') : asset('favicon.ico')); ?>"><title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> · <?php echo e(setting('site_name', 'Digistore OTP')); ?></title><link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=theme-premium-20261108-1">    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="<?php echo e(auth()->check() && auth()->user()->role === 'user' ? 'mobile-user-layout' : ''); ?>">
<?php if(auth()->check() && auth()->user()->role === 'user'): ?>
<style>
@media screen and (max-width: 760px) {
    body.mobile-user-layout header.topbar button.mobile-menu {
        display: none !important;
        visibility: hidden !important;
        pointer-events: none !important;
    }
}
</style>
<?php endif; ?>

<div class="shell">
<aside class="sidebar"><div class="brand-row"><a class="brand" href="<?php echo e(route('dashboard')); ?>"><span class="brand-icon">D</span><span><?php echo e(setting('brand_name', 'Digistore')); ?></span></a></div>
<nav>
<a class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>"><span class="nav-icon">◈</span><span>Dashboard</span></a>
<a class="<?php echo e(request()->routeIs('order*') ? 'active' : ''); ?>" href="<?php echo e(route('order')); ?>"><span class="nav-icon">＋</span><span>Order OTP</span></a>
<a class="<?php echo e(request()->routeIs('otp*') ? 'active' : ''); ?>" href="<?php echo e(route('otp')); ?>"><span class="nav-icon">▣</span><span>Pesan OTP</span></a>
<a class="<?php echo e(request()->routeIs('inbox') ? 'active' : ''); ?>" href="<?php echo e(route('inbox')); ?>"><span class="nav-icon">▤</span><span>Inbox OTP</span></a>
<a class="<?php echo e(request()->routeIs('topup*') || request()->routeIs('admin.topups') ? 'active' : ''); ?>" href="<?php echo e(route('topup')); ?>"><span class="nav-icon">↗</span><span>Top Up</span></a>
<a class="<?php echo e(request()->routeIs('history') ? 'active' : ''); ?>" href="<?php echo e(route('history')); ?>"><span class="nav-icon">◷</span><span>Riwayat</span></a>
<a class="<?php echo e(request()->routeIs('support.*') ? 'active' : ''); ?>" href="<?php echo e(route('support.index')); ?>"><span class="nav-icon">?</span><span>Bantuan CS</span></a>
<a class="<?php echo e(request()->routeIs('account.*') ? 'active' : ''); ?>" href="<?php echo e(route('account.edit')); ?>"><span class="nav-icon">⚙</span><span>Pengaturan Akun</span></a>
<?php if(auth()->user()->role==='admin'): ?><div class="nav-label">ADMIN</div><a class="<?php echo e(request()->routeIs('admin.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.index')); ?>"><span class="nav-icon">⌘</span><span>Overview Admin</span></a><a class="<?php echo e(request()->routeIs('admin.announcements*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.announcements.index')); ?>"><span class="nav-icon">📢</span><span>Pengumuman</span></a><a class="<?php echo e(request()->routeIs('admin.users*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users')); ?>"><span class="nav-icon">♙</span><span>Pengguna</span></a><a class="<?php echo e(request()->routeIs('admin.orders*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.orders')); ?>"><span class="nav-icon">◷</span><span>Riwayat Order</span></a><a class="<?php echo e(request()->routeIs('admin.pricing') ? 'active' : ''); ?>" href="<?php echo e(route('admin.pricing')); ?>"><span class="nav-icon">％</span><span>Markup Harga</span></a><a class="<?php echo e(request()->routeIs('admin.fonnte*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.fonnte')); ?>"><span class="nav-icon">✉</span><span>WhatsApp Fonnte</span></a><a class="<?php echo e(request()->routeIs('admin.site-settings*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.site-settings')); ?>"><span class="nav-icon">⚙</span><span>Identitas Website</span></a><a class="<?php echo e(request()->routeIs('admin.system-settings*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.system-settings')); ?>"><span class="nav-icon">🔧</span><span>Pengaturan Sistem</span></a><a class="<?php echo e(request()->routeIs('admin.support-tickets*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.support-tickets')); ?>"><span class="nav-icon">?</span><span>Tiket Bantuan</span></a><a href="<?php echo e(route('admin.topups')); ?>">▤ <span>Top Up</span></a><?php endif; ?>

<a href="<?php echo e(route('premium.index')); ?>" class="<?php echo e(request()->routeIs('premium.index') ? 'active' : ''); ?>">
    <span>✦</span><span>App Premium</span>
</a>
</nav><div class="side-bottom"><div class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></div><div class="user-label"><b><?php echo e(auth()->user()->name); ?></b><small><?php echo e(auth()->user()->role); ?></small></div><form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="icon-btn" title="Keluar">↪</button></form></div>
</aside>
<main class="main"><header class="topbar"><button class="mobile-menu" onclick="document.body.classList.toggle('nav-open')" aria-label="Buka atau tutup menu" aria-expanded="false">☰</button><div class="topbar-heading"><div class="eyebrow"><?php echo e(setting('site_name', 'Digistore OTP')); ?> / <?php echo $__env->yieldContent('crumb','OVERVIEW'); ?></div><h1><?php echo $__env->yieldContent('heading','Dashboard'); ?></h1></div><div class="balance-pill">Saldo <?php if(auth()->user()->role === 'admin' && isset($simuruBalance) && is_array($simuruBalance)): ?>
<b id="realtime-wallet-balance" data-wallet-source="simuru" data-balance="<?php echo e((int) ($simuruBalance['balance'] ?? auth()->user()->balance)); ?>"><?php echo e($simuruBalance['balance_formatted'] ?? rupiah($simuruBalance['balance'] ?? auth()->user()->balance)); ?></b>
<?php else: ?>
<b id="realtime-wallet-balance" data-balance="<?php echo e((int) auth()->user()->balance); ?>"><?php echo e(rupiah(auth()->user()->balance)); ?></b>
<?php endif; ?></div><div class="top-actions"><button class="icon-btn premium-theme-toggle" onclick="toggleTheme()" title="Ganti tema" aria-label="Ganti tema">
    <span class="theme-icon theme-sun" aria-hidden="true">☀</span>
    <span class="theme-icon theme-moon" aria-hidden="true">☾</span>
    <span class="theme-toggle-glow" aria-hidden="true"></span>
</button></div></header>
<?php if(session('success')): ?><div class="alert success"><?php echo e(session('success')); ?></div><?php endif; ?>
<?php if($errors->any()): ?><div class="alert error"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
<footer>© <?php echo e(date('Y')); ?> <?php echo e(setting('footer_name', 'Digistore OTP')); ?> <span>Secure verification dashboard</span></footer>
</main></div>
<script>
const THEME_URL = <?php echo json_encode(route('theme'), 15, 512) ?>;
const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content;

function applyTheme(theme) {
    const selected = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = selected;
    try { localStorage.setItem('depuka-theme', selected); } catch (_) {}
}

function toggleTheme() {
    const current = document.documentElement.dataset.theme || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';

    // Terapkan langsung agar tombol terasa responsif.
    applyTheme(next);

    // Simpan ke server agar tema juga berlaku pada halaman berikutnya.
    fetch(THEME_URL, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-TOKEN': CSRF_TOKEN
        },
        body: JSON.stringify({theme: next})
    }).then(response => {
        if (!response.ok) throw new Error('Gagal menyimpan tema');
    }).catch(() => {
        // localStorage tetap menyimpan pilihan pada browser ini.
    });
}

// Pulihkan pilihan tema yang tersimpan saat halaman dimuat.
try {
    const savedTheme = localStorage.getItem('depuka-theme');
    if (savedTheme === 'light' || savedTheme === 'dark') {
        applyTheme(savedTheme);
    }
} catch (_) {}
</script>

<?php if(auth()->check() && auth()->user()->role === 'admin'): ?>
<script>
(function () {
    if (window.__digistoreAdminMenuReady) return;
    window.__digistoreAdminMenuReady = true;

    function closeMenu() {
        document.body.classList.remove('nav-open');

        const button = document.querySelector('.mobile-menu');
        if (button) button.setAttribute('aria-expanded', 'false');
    }

    function syncMenuState(button) {
        requestAnimationFrame(function () {
            const currentButton = document.querySelector('.mobile-menu');
            if (currentButton) {
                currentButton.setAttribute(
                    'aria-expanded',
                    document.body.classList.contains('nav-open') ? 'true' : 'false'
                );
            }
        });
    }

    // Event delegation: tetap mengenali tombol setelah konten AJAX diganti.
    document.addEventListener('click', function (event) {
        const button = event.target.closest('.mobile-menu');

        if (button) {
            syncMenuState(button);
            return;
        }

        if (!document.body.classList.contains('nav-open')) return;

        const sidebar = document.querySelector('.sidebar');
        const currentButton = document.querySelector('.mobile-menu');

        if (sidebar && sidebar.contains(event.target)) {
            if (
                event.target.closest('a') &&
                window.matchMedia('(max-width: 760px)').matches
            ) {
                closeMenu();
            }
            return;
        }

        if (currentButton && currentButton.contains(event.target)) return;
        closeMenu();
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeMenu();
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth > 760) closeMenu();
    });
})();
</script>
<?php endif; ?>

<?php if(
    auth()->check()
    && auth()->user()->role === 'user'
    && session('show_login_announcement')
    && setting('login_popup_enabled', '0') === '1'
    && trim((string) setting('login_popup_message', '')) !== ''
): ?>
<div id="loginAnnouncementModal" class="login-announcement-overlay"
     role="presentation">
    <section class="login-announcement-box"
             role="dialog" aria-modal="true"
             aria-labelledby="loginAnnouncementTitle">
        <div class="login-announcement-icon">
            <i class="bi bi-megaphone-fill"></i>
        </div>
        <h2 id="loginAnnouncementTitle">
            <?php echo e(setting('login_popup_title', 'Informasi Terbaru')); ?>

        </h2>
        <div class="login-announcement-message"><?php echo e(setting('login_popup_message', '')); ?></div>
        <button type="button" id="closeLoginAnnouncement"
                class="btn btn-primary login-announcement-button">
            Saya Mengerti
        </button>
    </section>
</div>

<style>
.login-announcement-overlay {
    position: fixed;
    inset: 0;
    z-index: 99999;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 18px;
    background: rgba(5, 10, 25, .76);
    backdrop-filter: blur(5px);
}
.login-announcement-box {
    width: 100%;
    max-width: 460px;
    max-height: 85vh;
    overflow-y: auto;
    padding: 28px;
    border: 1px solid var(--border, #334155);
    border-radius: 20px;
    background: var(--card, #111827);
    color: var(--text, #f8fafc);
    text-align: center;
    box-shadow: 0 24px 80px rgba(0,0,0,.35);
    animation: announcementAppear .22s ease-out;
}
.login-announcement-icon {
    width: 54px;
    height: 54px;
    margin: 0 auto 16px;
    display: grid;
    place-items: center;
    border-radius: 16px;
    background: rgba(59,130,246,.15);
    color: #60a5fa;
    font-size: 25px;
}
.login-announcement-box h2 {
    margin: 0 0 14px;
    font-size: 21px;
    font-weight: 750;
}
.login-announcement-message {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    text-align: left;
    line-height: 1.7;
    color: var(--muted, #cbd5e1);
    font-size: 14px;
}
.login-announcement-button {
    width: 100%;
    margin-top: 24px;
}
@keyframes announcementAppear {
    from { opacity: 0; transform: translateY(12px) scale(.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}
@media (max-width: 480px) {
    .login-announcement-box { padding: 23px 19px; }
}

/* Premium button - Login announcement */
.login-announcement-button,
#closeLoginAnnouncement {
    display: block !important;
    width: 100% !important;
    min-height: 48px !important;
    margin-top: 22px !important;
    padding: 12px 20px !important;
    border: 1px solid rgba(96, 165, 250, .45) !important;
    border-radius: 12px !important;
    background: linear-gradient(135deg, #2563eb 0%, #3b82f6 55%, #60a5fa 100%) !important;
    color: #ffffff !important;
    font-size: 14px !important;
    font-weight: 700 !important;
    letter-spacing: .3px !important;
    box-shadow: 0 6px 20px rgba(37, 99, 235, .35) !important;
    cursor: pointer !important;
    transition: all .2s ease !important;
}

.login-announcement-button:hover,
#closeLoginAnnouncement:hover {
    background: linear-gradient(135deg, #1d4ed8, #2563eb 55%, #3b82f6) !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 9px 25px rgba(37, 99, 235, .48) !important;
}

.login-announcement-button:active,
#closeLoginAnnouncement:active {
    transform: scale(.98) !important;
}

.login-announcement-button:focus-visible,
#closeLoginAnnouncement:focus-visible {
    outline: 3px solid rgba(96, 165, 250, .5) !important;
    outline-offset: 3px !important;
}


/* Popup mengikuti tema DigiStore */

/* LIGHT MODE */
html[data-theme="light"] .login-announcement-overlay {
    background: rgba(15, 23, 42, .48) !important;
}

html[data-theme="light"] .login-announcement-box {
    background: #ffffff !important;
    color: #0f172a !important;
    border: 1px solid #e2e8f0 !important;
    box-shadow: 0 24px 80px rgba(15, 23, 42, .20) !important;
}

html[data-theme="light"] .login-announcement-box h2 {
    color: #0f172a !important;
}

html[data-theme="light"] .login-announcement-message {
    color: #64748b !important;
}

html[data-theme="light"] .login-announcement-icon {
    background: #eff6ff !important;
    color: #2563eb !important;
}

/* DARK MODE */
html[data-theme="dark"] .login-announcement-overlay {
    background: rgba(5, 10, 25, .76) !important;
}

html[data-theme="dark"] .login-announcement-box {
    background: #111827 !important;
    color: #f8fafc !important;
    border: 1px solid #334155 !important;
}

html[data-theme="dark"] .login-announcement-box h2 {
    color: #f8fafc !important;
}

html[data-theme="dark"] .login-announcement-message {
    color: #cbd5e1 !important;
}

html[data-theme="dark"] .login-announcement-icon {
    background: rgba(59,130,246,.15) !important;
    color: #60a5fa !important;
}

</style>

<script>
(function () {
    const modal = document.getElementById('loginAnnouncementModal');
    const closeButton = document.getElementById('closeLoginAnnouncement');
    if (!modal || !closeButton) return;

    function closeAnnouncement() {
        modal.remove();
    }

    closeButton.addEventListener('click', closeAnnouncement);
    modal.addEventListener('click', function (event) {
        if (event.target === modal) closeAnnouncement();
    });
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeAnnouncement();
    });
})();
</script>
<?php endif; ?>


<?php if(auth()->user()->role === 'user'): ?>
<nav class="user-bottom-nav" id="userBottomNav" aria-label="Navigasi utama">

    <a href="<?php echo e(route('dashboard')); ?>"
       class="bottom-nav-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <i class="bi bi-house-door"></i>
        <span>Home</span>
    </a>

    <a href="<?php echo e(route('topup')); ?>"
       class="bottom-nav-item <?php echo e(request()->routeIs('topup*') ? 'active' : ''); ?>">
        <i class="bi bi-wallet2"></i>
        <span>Deposit</span>
    </a>

    <a href="<?php echo e(route('order')); ?>"
       class="bottom-nav-item bottom-nav-order <?php echo e(request()->routeIs('order*') ? 'active' : ''); ?>">
        <span class="bottom-order-icon">
            <i class="bi bi-lightning-charge-fill"></i>
        </span>
        <span>Order OTP</span>
    </a>

    <a href="<?php echo e(route('otp')); ?>"
       class="bottom-nav-item <?php echo e(request()->routeIs('otp*') ? 'active' : ''); ?>">
        <i class="bi bi-chat-square-text"></i>
        <span>Pesan OTP</span>
    </a>

    <button type="button" class="bottom-nav-item bottom-nav-menu"
            onclick="document.body.classList.toggle('nav-open')">
        <i class="bi bi-grid"></i>
        <span>Menu</span>
    </button>

</nav>
<?php endif; ?>


<script src="<?php echo e(asset("js/app.js")); ?>?v=ajax-20261106-4"></script>
</body></html>
<?php /**PATH /root/digistore-project/digistore-otp/resources/views/layouts/app.blade.php ENDPATH**/ ?>