<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::table('users',function(Blueprint $t){ $t->string('role')->default('user')->index(); $t->boolean('is_blocked')->default(false)->index(); $t->unsignedBigInteger('balance')->default(0); $t->string('theme',10)->default('dark'); }); }
 public function down(): void { Schema::table('users',function(Blueprint $t){ $t->dropColumn(['role','is_blocked','balance','theme']); }); }
};
