<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AdminSiteSettingsController extends Controller
{
    private array $fields = [
        'site_name' => 'Nama website',
        'brand_name' => 'Nama brand pendek',
        'login_title' => 'Judul halaman login',
        'footer_name' => 'Nama footer',
        'cs_whatsapp' => 'Nomor WhatsApp CS',
        'login_popup_title' => 'Judul popup informasi setelah login',
        'login_popup_message' => 'Isi popup informasi setelah login',
        'login_popup_enabled' => 'Aktifkan popup informasi setelah login',
        'otp_notice_title' => 'Judul informasi OTP',
        'otp_notice_message' => 'Isi informasi OTP',
        'otp_notice_enabled' => 'Tampilkan informasi OTP',
        'topup_guide_title' => 'Judul panduan Top Up',
        'topup_guide_enabled' => 'Tampilkan panduan Top Up',
        'topup_guide_step1_title' => 'Panduan Top Up langkah 1 - judul',
        'topup_guide_step1_text' => 'Panduan Top Up langkah 1 - isi',
        'topup_guide_step2_title' => 'Panduan Top Up langkah 2 - judul',
        'topup_guide_step2_text' => 'Panduan Top Up langkah 2 - isi',
        'topup_guide_step3_title' => 'Panduan Top Up langkah 3 - judul',
        'topup_guide_step3_text' => 'Panduan Top Up langkah 3 - isi',
        'topup_guide_step4_title' => 'Panduan Top Up langkah 4 - judul',
        'topup_guide_step4_text' => 'Panduan Top Up langkah 4 - isi',
        'topup_guide_step5_title' => 'Panduan Top Up langkah 5 - judul',
        'topup_guide_step5_text' => 'Panduan Top Up langkah 5 - isi',
    ];

    public function index()
    {
        $settings = [];


        foreach ($this->fields as $key => $label) {
            $settings[$key] = setting($key, match ($key) {
                'site_name' => 'Digistore OTP',
                'brand_name' => 'Digistore',
                'login_title' => 'Selamat datang',
                'footer_name' => 'Digistore OTP',
                'cs_whatsapp' => '',
                'login_popup_title' => 'Informasi Terbaru',
                'login_popup_message' => 'Selamat datang di DigiStore OTP. Silakan baca informasi terbaru sebelum menggunakan layanan.',
                'login_popup_enabled' => '0',
                'otp_notice_title' => 'Informasi Penting',
                'otp_notice_message' => 'Pastikan layanan dan negara sudah sesuai sebelum memesan. Harga serta ketersediaan nomor dapat berubah mengikuti penyedia layanan. Penerimaan SMS tidak selalu dijamin.',
                'otp_notice_enabled' => '1',
                'topup_guide_title' => 'Bagaimana cara top up?',
                'topup_guide_enabled' => '1',
                'topup_guide_step1_title' => 'Pilih metode dan nominal',
                'topup_guide_step1_text' => 'Tentukan metode pembayaran dan nominal saldo yang ingin ditambahkan. Periksa kembali nominal sebelum melanjutkan.',
                'topup_guide_step2_title' => 'Lakukan pembayaran',
                'topup_guide_step2_text' => 'QRIS manual: tampilkan QRIS resmi lalu bayar sesuai nominal. GoPay atau ShopeePay otomatis: ikuti instruksi dan nominal unik yang ditampilkan sistem.',
                'topup_guide_step3_title' => 'Kirim bukti jika diminta',
                'topup_guide_step3_text' => 'Untuk QRIS manual, unggah bukti pembayaran dan isi referensi jika tersedia. Pembayaran otomatis diproses melalui notifikasi pembayaran.',
                'topup_guide_step4_title' => 'Tunggu saldo diproses',
                'topup_guide_step4_text' => 'QRIS manual menunggu pemeriksaan admin. Pembayaran otomatis menunggu konfirmasi sistem. Periksa saldo dan riwayat Top Up.',
                'topup_guide_step5_title' => 'Perhatikan keamanan',
                'topup_guide_step5_text' => 'Gunakan tujuan pembayaran resmi dan nominal yang tepat. Jangan membagikan PIN, kode OTP, atau kata sandi kepada siapa pun.',
                default => '',
            });
        }

        $settings['favicon_path'] = setting('favicon_path', '');

        return view('admin.site-settings', [
            'settings' => $settings,
        ]);
    }

    public function save(Request $request)
    {
        $data = $request->validate([
            'site_name' => ['required', 'string', 'max:100'],
            'brand_name' => ['required', 'string', 'max:60'],
            'login_title' => ['required', 'string', 'max:100'],
            'footer_name' => ['required', 'string', 'max:120'],
            'cs_whatsapp' => ['nullable', 'string', 'regex:/^628[0-9]{7,13}$/'],
            'login_popup_title' => ['nullable', 'string', 'max:120'],
            'login_popup_message' => ['nullable', 'string', 'max:3000'],
            'login_popup_enabled' => ['nullable', 'in:1'],
            'otp_notice_title' => ['nullable', 'string', 'max:120'],
            'otp_notice_message' => ['nullable', 'string', 'max:2000'],
            'otp_notice_enabled' => ['nullable', 'in:1'],
            'topup_guide_title' => ['nullable', 'string', 'max:120'],
            'topup_guide_enabled' => ['nullable', 'in:1'],
            'topup_guide_step1_title' => ['nullable', 'string', 'max:120'],
            'topup_guide_step1_text' => ['nullable', 'string', 'max:1000'],
            'topup_guide_step2_title' => ['nullable', 'string', 'max:120'],
            'topup_guide_step2_text' => ['nullable', 'string', 'max:1000'],
            'topup_guide_step3_title' => ['nullable', 'string', 'max:120'],
            'topup_guide_step3_text' => ['nullable', 'string', 'max:1000'],
            'topup_guide_step4_title' => ['nullable', 'string', 'max:120'],
            'topup_guide_step4_text' => ['nullable', 'string', 'max:1000'],
            'topup_guide_step5_title' => ['nullable', 'string', 'max:120'],
            'topup_guide_step5_text' => ['nullable', 'string', 'max:1000'],
            'favicon' => [
                'nullable',
                'file',
                'max:2048',
                function ($attribute, $file, $fail) {
                    if (!$file) {
                        return;
                    }

                    $ext = strtolower($file->getClientOriginalExtension());
                    $mime = $file->getMimeType();

                    $allowed = [
                        'png' => ['image/png'],
                        'jpg' => ['image/jpeg'],
                        'jpeg' => ['image/jpeg'],
                        'ico' => [
                            'image/x-icon',
                            'image/vnd.microsoft.icon',
                            'application/octet-stream',
                        ],
                    ];

                    if (
                        !isset($allowed[$ext]) ||
                        !in_array($mime, $allowed[$ext], true)
                    ) {
                        $fail('Favicon harus berupa file PNG, JPG, JPEG, atau ICO yang valid.');
                    }
                },
            ],
        ], [
            'favicon.max' => 'Ukuran favicon maksimal 2 MB.',
        ]);

        $data['login_popup_enabled'] = $request->boolean('login_popup_enabled') ? '1' : '0';
        $data['otp_notice_enabled'] = $request->boolean('otp_notice_enabled') ? '1' : '0';
        $data['topup_guide_enabled'] = $request->boolean('topup_guide_enabled') ? '1' : '0';

        foreach ($this->fields as $key => $label) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => trim($data[$key] ?? '')]
            );
        }

        if ($request->hasFile('favicon')) {
            $file = $request->file('favicon');
            $directory = public_path('uploads');

            if (!is_dir($directory)) {
                mkdir($directory, 0755, true);
            }

            $extension = strtolower($file->getClientOriginalExtension());
            $filename = 'favicon-' . Str::uuid() . '.' . $extension;
            $file->move($directory, $filename);

            $newPath = 'uploads/' . $filename;
            $oldPath = setting('favicon_path', '');

            Setting::updateOrCreate(
                ['key' => 'favicon_path'],
                ['value' => $newPath]
            );

            Setting::updateOrCreate(
                ['key' => 'favicon_updated_at'],
                ['value' => (string) time()]
            );

            if (
                $oldPath &&
                str_starts_with($oldPath, 'uploads/favicon-') &&
                basename($oldPath) === $oldPath &&
                is_file(public_path($oldPath))
            ) {
                @unlink(public_path($oldPath));
            }
        }

        return redirect()
            ->route('admin.site-settings')
            ->with('success', 'Identitas website berhasil disimpan.');
    }
}
