<!doctype html>
<html lang="id" data-theme="{{ auth()->user()->theme ?? 'dark' }}">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="{{ csrf_token() }}"><title>@yield('title', 'Dashboard') · {{ setting('site_name', 'Digistore OTP') }}</title><link rel="stylesheet" href="{{ asset('css/app.css') }}?v=inbox-pagination-v2">    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
<div class="shell">
<aside class="sidebar"><div class="brand-row"><a class="brand" href="{{ route('dashboard') }}"><span class="brand-icon">D</span><span>{{ setting('brand_name', 'Digistore') }}</span></a></div>
<nav>
<a class="{{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}"><span class="nav-icon">◈</span><span>Dashboard</span></a>
<a class="{{ request()->routeIs('order*') ? 'active' : '' }}" href="{{ route('order') }}"><span class="nav-icon">＋</span><span>Order OTP</span></a>
<a class="{{ request()->routeIs('otp*') ? 'active' : '' }}" href="{{ route('otp') }}"><span class="nav-icon">▣</span><span>Pesan OTP</span></a>
<a class="{{ request()->routeIs('inbox') ? 'active' : '' }}" href="{{ route('inbox') }}"><span class="nav-icon">▤</span><span>Inbox OTP</span></a>
<a class="{{ request()->routeIs('topup*') || request()->routeIs('admin.topups') ? 'active' : '' }}" href="{{ route('topup') }}"><span class="nav-icon">↗</span><span>Top Up</span></a>
<a class="{{ request()->routeIs('history') ? 'active' : '' }}" href="{{ route('history') }}"><span class="nav-icon">◷</span><span>Riwayat</span></a>
<a class="{{ request()->routeIs('support.*') ? 'active' : '' }}" href="{{ route('support.index') }}"><span class="nav-icon">?</span><span>Bantuan CS</span></a>
<a class="{{ request()->routeIs('account.*') ? 'active' : '' }}" href="{{ route('account.edit') }}"><span class="nav-icon">⚙</span><span>Pengaturan Akun</span></a>
@if(auth()->user()->role==='admin')<div class="nav-label">ADMIN</div><a class="{{ request()->routeIs('admin.index') ? 'active' : '' }}" href="{{ route('admin.index') }}"><span class="nav-icon">⌘</span><span>Overview Admin</span></a><a class="{{ request()->routeIs('admin.users*') ? 'active' : '' }}" href="{{ route('admin.users') }}"><span class="nav-icon">♙</span><span>Pengguna</span></a><a class="{{ request()->routeIs('admin.orders*') ? 'active' : '' }}" href="{{ route('admin.orders') }}"><span class="nav-icon">◷</span><span>Riwayat Order</span></a><a class="{{ request()->routeIs('admin.pricing') ? 'active' : '' }}" href="{{ route('admin.pricing') }}"><span class="nav-icon">％</span><span>Markup Harga</span></a><a class="{{ request()->routeIs('admin.fonnte*') ? 'active' : '' }}" href="{{ route('admin.fonnte') }}"><span class="nav-icon">✉</span><span>WhatsApp Fonnte</span></a><a class="{{ request()->routeIs('admin.site-settings*') ? 'active' : '' }}" href="{{ route('admin.site-settings') }}"><span class="nav-icon">⚙</span><span>Identitas Website</span></a><a class="{{ request()->routeIs('admin.support-tickets*') ? 'active' : '' }}" href="{{ route('admin.support-tickets') }}"><span class="nav-icon">?</span><span>Tiket Bantuan</span></a><a href="{{ route('admin.topups') }}">▤ <span>Top Up</span></a>@endif
</nav><div class="side-bottom"><div class="avatar">{{ strtoupper(substr(auth()->user()->name,0,1)) }}</div><div class="user-label"><b>{{ auth()->user()->name }}</b><small>{{ auth()->user()->role }}</small></div><form method="POST" action="{{ route('logout') }}">@csrf<button class="icon-btn" title="Keluar">↪</button></form></div>
</aside>
<main class="main"><header class="topbar"><button class="mobile-menu" onclick="document.body.classList.toggle('nav-open')" aria-label="Buka atau tutup menu" aria-expanded="false">☰</button><div class="topbar-heading"><div class="eyebrow">{{ setting('site_name', 'Digistore OTP') }} / @yield('crumb','OVERVIEW')</div><h1>@yield('heading','Dashboard')</h1></div><div class="balance-pill">Saldo <b>{{ rupiah(auth()->user()->balance) }}</b></div><div class="top-actions"><button class="icon-btn" onclick="toggleTheme()" title="Ganti tema" aria-label="Ganti tema">☼</button></div></header>
@if(session('success'))<div class="alert success">{{ session('success') }}</div>@endif
@if($errors->any())<div class="alert error">@foreach($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>@endif
@yield('content')
<footer>© {{ date('Y') }} {{ setting('footer_name', 'Digistore OTP') }} <span>Secure verification dashboard</span></footer>
</main></div>
<script>
const THEME_URL = @json(route('theme'));
const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content;

function applyTheme(theme) {
    const selected = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = selected;
    try { localStorage.setItem('depuka-theme', selected); } catch (_) {}
}

function toggleTheme() {
    const current = document.documentElement.dataset.theme || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';

    // Terapkan langsung agar tombol terasa responsif.
    applyTheme(next);

    // Simpan ke server agar tema juga berlaku pada halaman berikutnya.
    fetch(THEME_URL, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-TOKEN': CSRF_TOKEN
        },
        body: JSON.stringify({theme: next})
    }).then(response => {
        if (!response.ok) throw new Error('Gagal menyimpan tema');
    }).catch(() => {
        // localStorage tetap menyimpan pilihan pada browser ini.
    });
}

// Pulihkan pilihan tema yang tersimpan saat halaman dimuat.
try {
    const savedTheme = localStorage.getItem('depuka-theme');
    if (savedTheme === 'light' || savedTheme === 'dark') {
        applyTheme(savedTheme);
    }
} catch (_) {}
</script>

<script>
(function () {
    const menuButton = document.querySelector('.mobile-menu');
    const sidebar = document.querySelector('.sidebar');

    if (!menuButton || !sidebar) return;

    function closeMenu() {
        document.body.classList.remove('nav-open');
        menuButton.setAttribute('aria-expanded', 'false');
    }

    function syncMenuState() {
        menuButton.setAttribute(
            'aria-expanded',
            document.body.classList.contains('nav-open') ? 'true' : 'false'
        );
    }

    menuButton.addEventListener('click', function () {
        requestAnimationFrame(syncMenuState);
    });

    document.addEventListener('click', function (event) {
        if (!document.body.classList.contains('nav-open')) return;
        if (sidebar.contains(event.target) || menuButton.contains(event.target)) return;
        closeMenu();
    });

    sidebar.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.matchMedia('(max-width: 760px)').matches) closeMenu();
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeMenu();
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth > 760) closeMenu();
    });
})();
</script>
</body></html>
