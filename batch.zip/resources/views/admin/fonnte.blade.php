@extends('layouts.app')
@section('title', 'Pengaturan WhatsApp')
@section('crumb', 'ADMIN / WHATSAPP')
@section('heading', 'Pengaturan WhatsApp')

@section('content')
<div class="panel" style="max-width:760px;padding:24px">
    @if(session('success'))
        <div class="alert alert-success" role="status">{{ session('success') }}</div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger" role="alert">
            @foreach($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <h2>Gateway WhatsApp</h2>
    <p class="muted">Pilih gateway yang digunakan untuk mengirim notifikasi. Token Fonnte lama tetap disimpan.</p>

    <form method="POST" action="{{ route('admin.fonnte.save') }}" style="display:grid;gap:12px">
        @csrf

        <label for="gateway">Gateway aktif</label>
        <select id="gateway" name="gateway" style="width:100%;padding:10px">
            <option value="fonnte" @selected(old('gateway', $gateway) === 'fonnte')>Fonnte</option>
            <option value="openwa" @selected(old('gateway', $gateway) === 'openwa')>OpenWA</option>
        </select>

        <hr style="margin:12px 0;opacity:.2">
        <h3>Fonnte</h3>
        <p class="muted">Kosongkan token jika ingin mempertahankan token yang tersimpan.</p>

        <label for="token">Token API Fonnte</label>
        <input id="token" type="password" name="token" autocomplete="new-password"
               maxlength="500" placeholder="{{ $configured ? 'Token tersimpan — isi hanya jika ingin mengganti' : 'Masukkan token Fonnte' }}">

        <label for="phone">Nomor WhatsApp admin untuk pesan tes</label>
        <input id="phone" type="tel" name="phone" inputmode="numeric"
               pattern="628[0-9]{7,13}" maxlength="16" placeholder="6281234567890"
               value="{{ old('phone', $phone) }}" required>
        <small class="muted">Format 628..., tanpa tanda + atau spasi.</small>

        <hr style="margin:12px 0;opacity:.2">
        <h3>OpenWA</h3>
        <p class="muted">Pastikan sesi OpenWA sudah aktif/ready. Base URL biasanya diakhiri /api, sesuai alamat API pada server kamu.</p>

        <label for="openwa_base_url">Base URL OpenWA</label>
        <input id="openwa_base_url" type="url" name="openwa_base_url"
               maxlength="500" placeholder="http://127.0.0.1:3000/api"
               value="{{ old('openwa_base_url', $openwaUrl) }}">

        <label for="openwa_api_key">API Key OpenWA</label>
        <input id="openwa_api_key" type="password" name="openwa_api_key"
               autocomplete="new-password" maxlength="1000"
               placeholder="{{ $openwaConfigured ? 'API Key tersimpan — isi hanya jika ingin mengganti' : 'Masukkan API Key OpenWA' }}">
        <small class="muted">API Key dienkripsi sebelum disimpan dan tidak ditampilkan kembali.</small>

        <label for="openwa_session_id">Session ID</label>
        <input id="openwa_session_id" type="text" name="openwa_session_id"
               maxlength="150" placeholder="default"
               value="{{ old('openwa_session_id', $openwaSession) }}">

        <button class="btn primary full" type="submit">Simpan Pengaturan</button>
    </form>

    <hr style="margin:24px 0;opacity:.2">
    <h3>Tes koneksi WhatsApp</h3>
    <p class="muted">Mengirim satu pesan tes ke nomor admin dengan gateway yang sedang aktif.</p>
    <form method="POST" action="{{ route('admin.fonnte.test') }}">
        @csrf
        <button class="btn full" type="submit">Kirim Pesan Tes</button>
    </form>
</div>
@endsection
