<?php $__env->startSection('title', 'Pengumuman'); ?>
<?php $__env->startSection('crumb', 'ADMIN'); ?>
<?php $__env->startSection('heading', 'Pengumuman'); ?>

<?php $__env->startSection('content'); ?>
<style>
/* ===== ANNOUNCEMENT ADMIN ===== */
.ann-wrap{
    display:grid;
    gap:20px;
    min-width:0;
    width:100%;
}
.ann-panel{
    min-width:0;
    padding:22px;
    border:1px solid var(--line);
    border-radius:18px;
    background:var(--panel);
}
.ann-heading{
    display:flex;
    align-items:flex-start;
    gap:12px;
    margin-bottom:20px;
}
.ann-heading-icon{
    width:42px;
    height:42px;
    flex:0 0 42px;
    display:grid;
    place-items:center;
    border-radius:13px;
    background:rgba(59,130,246,.13);
    color:#60a5fa;
    font-size:20px;
}
.ann-heading h2{
    font-size:17px;
    font-weight:800;
    margin:0 0 5px;
}
.ann-muted{
    color:var(--muted);
    font-size:12px;
    line-height:1.6;
}
.ann-form-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:17px;
}
.ann-field{
    display:grid;
    align-content:start;
    gap:8px;
    min-width:0;
}
.ann-field.full{
    grid-column:1/-1;
}
.ann-field label,
.ann-label{
    font-size:12px;
    font-weight:700;
    color:var(--text);
}
.ann-field input:not([type=checkbox]),
.ann-field select,
.ann-field textarea,
.ann-search{
    display:block;
    width:100%;
    min-width:0;
    min-height:44px;
    padding:11px 13px;
    border:1px solid var(--line);
    border-radius:11px;
    outline:none;
    background:var(--bg);
    color:var(--text);
    font:inherit;
    font-size:13px;
    box-sizing:border-box;
    transition:border-color .2s,box-shadow .2s;
}
.ann-field textarea{
    min-height:120px;
    resize:vertical;
    line-height:1.6;
}
.ann-field input:focus,
.ann-field select:focus,
.ann-field textarea:focus,
.ann-search:focus{
    border-color:#5685ff;
    box-shadow:0 0 0 3px rgba(59,130,246,.12);
}
.ann-field input[type=checkbox],
.ann-user input[type=checkbox]{
    width:17px;
    height:17px;
    flex:0 0 17px;
    accent-color:#4778f5;
    cursor:pointer;
}
.ann-section-label{
    display:flex;
    align-items:center;
    justify-content:space-between;
    flex-wrap:wrap;
    gap:8px;
}
.ann-user-picker[hidden]{
    display:none!important;
}
.ann-user-tools{
    display:flex;
    align-items:center;
    justify-content:space-between;
    flex-wrap:wrap;
    gap:10px;
}
.ann-user-tools .ann-search{
    flex:1;
    min-width:180px;
}
.ann-user-count{
    color:var(--muted);
    font-size:11px;
    white-space:nowrap;
}
.ann-users{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:9px;
    max-height:280px;
    overflow-y:auto;
    overflow-x:hidden;
    padding:10px;
    border:1px solid var(--line);
    border-radius:13px;
    background:var(--bg);
    scrollbar-width:thin;
}
.ann-user{
    display:flex;
    align-items:flex-start;
    gap:10px;
    min-width:0;
    padding:11px;
    border:1px solid var(--line);
    border-radius:10px;
    background:var(--panel);
    cursor:pointer;
    transition:border-color .15s,background .15s;
}
.ann-user:has(input:checked){
    border-color:#5685ff;
    background:rgba(59,130,246,.08);
}
.ann-user input{
    margin:2px 0 0;
}
.ann-user-info{
    display:block;
    min-width:0;
    overflow-wrap:anywhere;
}
.ann-user-name{
    display:block;
    font-size:12px;
    font-weight:700;
    color:var(--text);
}
.ann-user-email{
    display:block;
    margin-top:3px;
    font-size:11px;
    color:var(--muted);
}
.ann-user-empty{
    grid-column:1/-1;
    padding:20px;
    text-align:center;
    color:var(--muted);
    font-size:12px;
}
.ann-check-row{
    display:flex;
    align-items:center;
    gap:10px;
    padding:13px 14px;
    border:1px solid var(--line);
    border-radius:11px;
    background:var(--bg);
    cursor:pointer;
    font-size:12px;
    font-weight:600;
}
.ann-submit{
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:10px;
    padding-top:4px;
}
.ann-submit .btn{
    min-height:44px;
    padding:11px 20px;
    border-radius:11px;
    font-weight:700;
}
.ann-alert{
    padding:13px 15px;
    border:1px solid var(--line);
    border-radius:12px;
    font-size:13px;
}
.ann-alert.success{
    border-color:rgba(22,163,74,.4);
    color:#22c55e;
    background:rgba(22,163,74,.07);
}
.ann-alert.error{
    border-color:rgba(239,68,68,.4);
    color:#ef4444;
    background:rgba(239,68,68,.06);
}
.ann-error-list{
    margin:7px 0 0;
    padding-left:18px;
    font-size:12px;
    line-height:1.7;
}
.ann-list{
    display:grid;
    gap:12px;
    margin-top:18px;
}
.ann-item{
    min-width:0;
    padding:17px;
    border:1px solid var(--line);
    border-radius:14px;
    background:var(--bg);
}
.ann-item-head{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:14px;
}
.ann-item-content{
    min-width:0;
    flex:1;
}
.ann-item-title{
    font-size:14px;
    font-weight:800;
    overflow-wrap:anywhere;
}
.ann-item-message{
    margin:7px 0 12px;
    color:var(--muted);
    font-size:12px;
    line-height:1.7;
    white-space:pre-line;
    overflow-wrap:anywhere;
}
.ann-date{
    color:var(--muted);
    font-size:11px;
    white-space:nowrap;
}
.ann-tags{
    display:flex;
    flex-wrap:wrap;
    gap:7px;
}
.ann-tag{
    display:inline-flex;
    align-items:center;
    padding:5px 9px;
    border:1px solid var(--line);
    border-radius:20px;
    background:var(--panel);
    color:var(--muted);
    font-size:10px;
    font-weight:700;
}
.ann-tag.active{
    color:#22c55e;
    border-color:rgba(34,197,94,.3);
    background:rgba(34,197,94,.07);
}
.ann-tag.inactive{
    color:#ef4444;
    border-color:rgba(239,68,68,.3);
    background:rgba(239,68,68,.07);
}
.ann-actions{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:8px;
    margin-top:14px;
}
.ann-actions form{
    margin:0;
}
.ann-actions .btn{
    min-height:37px;
    padding:8px 12px;
    border-radius:9px;
    font-size:11px;
}
.ann-edit{
    margin-top:16px;
    padding-top:17px;
    border-top:1px solid var(--line);
}
.ann-edit[hidden]{
    display:none!important;
}
.ann-edit-title{
    margin:0 0 15px;
    font-size:14px;
    font-weight:800;
}
.ann-empty{
    padding:30px 15px;
    text-align:center;
    border:1px dashed var(--line);
    border-radius:13px;
    color:var(--muted);
    font-size:13px;
}
.ann-empty-icon{
    display:block;
    margin-bottom:9px;
    font-size:28px;
}
.ann-pagination{
    margin-top:18px;
    overflow-x:auto;
}


/* ===== AJAX USER PICKER ===== */
.ann-selected-users{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:8px;
    margin:12px 0;
}
.ann-selected-users:empty{display:none}
.ann-selected-users .ann-user{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:8px;
    min-width:0;
    padding:10px;
    border-color:#5685ff;
    background:rgba(59,130,246,.08);
}
.ann-selected-users .ann-user-info{flex:1}
.ann-remove-user{
    flex:0 0 auto;
    border:0;
    border-radius:7px;
    padding:7px 9px;
    background:rgba(239,68,68,.12);
    color:#ef4444;
    font-size:11px;
    font-weight:700;
    cursor:pointer;
}
.ann-users .ann-user-empty{
    grid-column:1/-1;
    padding:16px;
    text-align:center;
    color:var(--muted);
    font-size:12px;
}
.ann-users .ann-user[hidden]{display:none!important}
@media(max-width:600px){
    .ann-selected-users{grid-template-columns:minmax(0,1fr)}
}

/* ===== TABLET ===== */
@media(max-width:900px){
    .ann-panel{padding:18px}
}

/* ===== MOBILE ===== */
@media(max-width:600px){
    .ann-wrap{gap:14px}
    .ann-panel{
        padding:15px;
        border-radius:14px;
    }
    .ann-heading{margin-bottom:17px}
    .ann-heading-icon{
        width:38px;
        height:38px;
        flex-basis:38px;
    }
    .ann-form-grid{
        grid-template-columns:minmax(0,1fr);
        gap:14px;
    }
    .ann-field.full{grid-column:auto}
    .ann-field input:not([type=checkbox]),
    .ann-field select,
    .ann-field textarea{
        font-size:16px;
    }
    .ann-field textarea{min-height:110px}
    .ann-users{
        grid-template-columns:minmax(0,1fr);
        max-height:260px;
        padding:8px;
    }
    .ann-user{padding:11px}
    .ann-user-tools{
        align-items:stretch;
        flex-direction:column;
    }
    .ann-user-tools .ann-search{width:100%}
    .ann-user-count{white-space:normal}
    .ann-submit{display:block}
    .ann-submit .btn{
        width:100%;
        justify-content:center;
    }
    .ann-item{padding:14px}
    .ann-item-head{display:block}
    .ann-date{
        display:block;
        margin-top:9px;
    }
    .ann-actions{
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
    }
    .ann-actions form,
    .ann-actions button{
        width:100%;
    }
    .ann-actions .btn{
        width:100%;
        min-height:40px;
    }
}
</style>

<div class="ann-wrap">

    <?php if(session('success')): ?>
        <div class="ann-alert success">✓ <?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="ann-alert error">
            <strong>Periksa kembali isian:</strong>
            <ul class="ann-error-list">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <section class="ann-panel">
        <div class="ann-heading">
            <div class="ann-heading-icon">＋</div>
            <div>
                <h2>Buat pengumuman baru</h2>
                <div class="ann-muted">Sampaikan informasi kepada pengguna Digistore OTP.</div>
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('admin.announcements.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="ann-form-grid">
                <div class="ann-field full">
                    <label for="ann-title">Judul pengumuman</label>
                    <input id="ann-title" name="title" maxlength="150"
                           value="<?php echo e(old('title')); ?>" required
                           placeholder="Contoh: Informasi pemeliharaan sistem">
                </div>

                <div class="ann-field full">
                    <label for="ann-message">Isi pengumuman</label>
                    <textarea id="ann-message" name="message" required
                              placeholder="Tulis informasi untuk pengguna..."><?php echo e(old('message')); ?></textarea>
                </div>

                <div class="ann-field">
                    <label for="ann-type">Jenis pengumuman</label>
                    <select id="ann-type" name="type">
                        <option value="info" <?php if(old('type', 'info') === 'info'): echo 'selected'; endif; ?>>Informasi</option>
                        <option value="success" <?php if(old('type') === 'success'): echo 'selected'; endif; ?>>Sukses</option>
                        <option value="warning" <?php if(old('type') === 'warning'): echo 'selected'; endif; ?>>Peringatan</option>
                        <option value="danger" <?php if(old('type') === 'danger'): echo 'selected'; endif; ?>>Penting</option>
                    </select>
                </div>

                <div class="ann-field">
                    <label for="ann-target">Target penerima</label>
                    <select id="ann-target" name="target_type" class="ann-target" required>
                        <option value="all" <?php if(old('target_type', 'all') === 'all'): echo 'selected'; endif; ?>>Semua pengguna</option>
                        <option value="selected" <?php if(old('target_type') === 'selected'): echo 'selected'; endif; ?>>Pengguna tertentu</option>
                    </select>
                </div>

                <div class="ann-field full ann-user-picker"
                     data-url="<?php echo e(route('admin.announcements.users')); ?>"
                     data-selected-users="[]"
                     <?php if(old('target_type', 'all') !== 'selected'): ?> hidden <?php endif; ?>>
                    <div class="ann-section-label">
                        <label>Pilih pengguna penerima</label>
                        <span class="ann-muted">Centang satu atau beberapa pengguna.</span>
                    </div>
                    <div class="ann-user-tools">
                        <input type="search" class="ann-search" placeholder="Cari nama atau email pengguna..." autocomplete="off">
                        <span class="ann-user-count">0 pengguna dipilih</span>
                    </div>
                    <div class="ann-selected-users"></div>
                    <div class="ann-users">
                        <div class="ann-user-empty">Ketik minimal 2 karakter untuk mencari pengguna.</div>
                    </div>
                    <div class="ann-hidden-inputs"></div>
                </div><div class="ann-field">
                    <label for="ann-start">Mulai ditampilkan (opsional)</label>
                    <input id="ann-start" type="datetime-local" name="starts_at" value="<?php echo e(old('starts_at')); ?>">
                    <span class="ann-muted">Kosongkan agar langsung mengikuti status aktif.</span>
                </div>

                <div class="ann-field">
                    <label for="ann-end">Berakhir (opsional)</label>
                    <input id="ann-end" type="datetime-local" name="ends_at" value="<?php echo e(old('ends_at')); ?>">
                    <span class="ann-muted">Kosongkan jika tidak ada batas waktu.</span>
                </div>

                <div class="ann-field full">
                    <label class="ann-check-row">
                        <input type="checkbox" name="is_active" value="1"
                               <?php if(old('is_active', '1')): echo 'checked'; endif; ?>>
                        <span>Aktifkan pengumuman langsung</span>
                    </label>
                </div>

                <div class="ann-field full">
                    <div class="ann-submit">
                        <button class="btn primary" type="submit">Simpan Pengumuman →</button>
                    </div>
                </div>
            </div>
        </form>
    </section>

    
    <section class="ann-panel">
        <div class="ann-heading">
            <div class="ann-heading-icon">▤</div>
            <div>
                <h2>Daftar pengumuman</h2>
                <div class="ann-muted">Kelola, ubah, dan pantau pengumuman yang sudah dibuat.</div>
            </div>
        </div>

        <div class="ann-list">
            <?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="ann-item">
                    <div class="ann-item-head">
                        <div class="ann-item-content">
                            <div class="ann-item-title"><?php echo e($announcement->title); ?></div>
                            <div class="ann-item-message"><?php echo e($announcement->message); ?></div>

                            <div class="ann-tags">
                                <span class="ann-tag"><?php echo e(strtoupper($announcement->type)); ?></span>
                                <span class="ann-tag">
                                    <?php echo e($announcement->target_type === 'all' ? 'Semua pengguna' : $announcement->users->count().' pengguna dipilih'); ?>

                                </span>
                                <span class="ann-tag <?php echo e($announcement->is_active ? 'active' : 'inactive'); ?>">
                                    <?php echo e($announcement->is_active ? '● Aktif' : '● Nonaktif'); ?>

                                </span>
                            </div>
                        </div>

                        <time class="ann-date"><?php echo e($announcement->created_at->format('d/m/Y H:i')); ?></time>
                    </div>

                    <div class="ann-actions">
                        <form method="POST" action="<?php echo e(route('admin.announcements.toggle', $announcement)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn secondary" type="submit">
                                <?php echo e($announcement->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                            </button>
                        </form>

                        <button class="btn secondary" type="button"
                                onclick="annToggleEdit(<?php echo e($announcement->id); ?>)">
                            ✎ Edit
                        </button>

                        <form method="POST"
                              action="<?php echo e(route('admin.announcements.destroy', $announcement)); ?>"
                              onsubmit="return confirm('Yakin ingin menghapus pengumuman ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn secondary" type="submit">Hapus</button>
                        </form>
                    </div>

                    
                    <div class="ann-edit" id="edit-ann-<?php echo e($announcement->id); ?>" hidden>
                        <h3 class="ann-edit-title">Edit pengumuman</h3>

                        <form method="POST" action="<?php echo e(route('admin.announcements.update', $announcement)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="ann-form-grid">
                                <div class="ann-field full">
                                    <label>Judul</label>
                                    <input name="title" value="<?php echo e($announcement->title); ?>"
                                           required maxlength="150">
                                </div>

                                <div class="ann-field full">
                                    <label>Isi pengumuman</label>
                                    <textarea name="message" required><?php echo e($announcement->message); ?></textarea>
                                </div>

                                <div class="ann-field">
                                    <label>Jenis pengumuman</label>
                                    <select name="type">
                                        <?php $__currentLoopData = ['info'=>'Informasi','success'=>'Sukses','warning'=>'Peringatan','danger'=>'Penting']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($announcement->type === $key): echo 'selected'; endif; ?>>
                                                <?php echo e($label); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="ann-field">
                                    <label>Target penerima</label>
                                    <select name="target_type" class="ann-target" required>
                                        <option value="all" <?php if($announcement->target_type === 'all'): echo 'selected'; endif; ?>>Semua pengguna</option>
                                        <option value="selected" <?php if($announcement->target_type === 'selected'): echo 'selected'; endif; ?>>Pengguna tertentu</option>
                                    </select>
                                </div>

                                <div class="ann-field full ann-user-picker"
                                     data-url="<?php echo e(route('admin.announcements.users')); ?>"
                                     data-selected-users="<?php echo e(json_encode($announcement->users->map(fn($user) => ['id' => $user->id, 'name' => $user->name, 'email' => $user->email])->values(), JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP)); ?>"
                                     <?php if($announcement->target_type !== 'selected'): ?> hidden <?php endif; ?>>
                                    <div class="ann-section-label">
                                        <label>Pilih pengguna</label>
                                        <span class="ann-muted">Pengguna yang dicentang akan menerima pengumuman.</span>
                                    </div>
                                    <div class="ann-user-tools">
                                        <input type="search" class="ann-search" placeholder="Cari nama atau email pengguna..." autocomplete="off">
                                        <span class="ann-user-count">0 pengguna dipilih</span>
                                    </div>
                                    <div class="ann-selected-users"></div>
                                    <div class="ann-users">
                                        <div class="ann-user-empty">Ketik minimal 2 karakter untuk mencari pengguna.</div>
                                    </div>
                                    <div class="ann-hidden-inputs"></div>
                                </div><div class="ann-field">
                                    <label>Mulai ditampilkan (opsional)</label>
                                    <input type="datetime-local" name="starts_at"
                                           value="<?php echo e($announcement->starts_at?->format('Y-m-d\TH:i')); ?>">
                                </div>

                                <div class="ann-field">
                                    <label>Berakhir (opsional)</label>
                                    <input type="datetime-local" name="ends_at"
                                           value="<?php echo e($announcement->ends_at?->format('Y-m-d\TH:i')); ?>">
                                </div>

                                <div class="ann-field full">
                                    <label class="ann-check-row">
                                        <input type="checkbox" name="is_active" value="1"
                                               <?php if($announcement->is_active): echo 'checked'; endif; ?>>
                                        <span>Aktifkan pengumuman</span>
                                    </label>
                                </div>

                                <div class="ann-field full">
                                    <div class="ann-submit">
                                        <button class="btn primary" type="submit">Simpan Perubahan →</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="ann-empty">
                    <span class="ann-empty-icon">📢</span>
                    <strong>Belum ada pengumuman</strong>
                    <p class="ann-muted">Pengumuman yang kamu buat akan muncul di bagian ini.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="ann-pagination"><?php echo e($announcements->links()); ?></div>
    </section>
</div>

<script>
(function () {
    // Buka/tutup form edit
    window.annToggleEdit = function (id) {
        const panel = document.getElementById('edit-ann-' + id);
        if (!panel) return;
        panel.hidden = !panel.hidden;
        if (!panel.hidden) {
            panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    };

    // Tampilkan daftar pengguna hanya jika target tertentu dipilih
    document.querySelectorAll('.ann-target').forEach(function (select) {
        function updatePicker() {
            const form = select.closest('form');
            const picker = form ? form.querySelector('.ann-user-picker') : null;
            if (picker) picker.hidden = select.value !== 'selected';
        }
        select.addEventListener('change', updatePicker);
        updatePicker();
    });

    // Pencarian pengguna dengan AJAX
    document.querySelectorAll('.ann-user-picker').forEach(function (picker) {
        const search = picker.querySelector('.ann-search');
        const results = picker.querySelector('.ann-users');
        const selectedBox = picker.querySelector('.ann-selected-users');
        const hiddenInputs = picker.querySelector('.ann-hidden-inputs');
        const count = picker.querySelector('.ann-user-count');
        const url = picker.dataset.url;

        const selected = new Map();
        let currentUsers = [];
        let timer = null;
        let controller = null;
        let requestNumber = 0;

        // Pulihkan penerima yang sudah tersimpan pada form edit
        try {
            const initial = JSON.parse(picker.dataset.selectedUsers || '[]');
            initial.forEach(function (user) {
                selected.set(String(user.id), user);
            });
        } catch (error) {
            console.error('Gagal membaca penerima:', error);
        }

        function renderSelected() {
            selectedBox.innerHTML = '';
            hiddenInputs.innerHTML = '';

            selected.forEach(function (user, id) {
                const item = document.createElement('div');
                item.className = 'ann-user';

                const info = document.createElement('span');
                info.className = 'ann-user-info';

                const name = document.createElement('span');
                name.className = 'ann-user-name';
                name.textContent = user.name;

                const email = document.createElement('span');
                email.className = 'ann-user-email';
                email.textContent = user.email;

                info.append(name, email);

                const remove = document.createElement('button');
                remove.type = 'button';
                remove.className = 'ann-remove-user';
                remove.textContent = 'Hapus';
                remove.addEventListener('click', function () {
                    selected.delete(id);
                    renderSelected();
                    renderResults();
                });

                item.append(info, remove);
                selectedBox.appendChild(item);

                const hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'user_ids[]';
                hidden.value = id;
                hiddenInputs.appendChild(hidden);
            });

            count.textContent = selected.size + ' pengguna dipilih';
        }

        function renderResults() {
            results.innerHTML = '';

            if (!currentUsers.length) {
                const empty = document.createElement('div');
                empty.className = 'ann-user-empty';
                empty.textContent = 'Tidak ada pengguna yang ditemukan.';
                results.appendChild(empty);
                return;
            }

            currentUsers.forEach(function (user) {
                const id = String(user.id);
                const label = document.createElement('label');
                label.className = 'ann-user';

                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.checked = selected.has(id);

                const info = document.createElement('span');
                info.className = 'ann-user-info';

                const name = document.createElement('span');
                name.className = 'ann-user-name';
                name.textContent = user.name;

                const email = document.createElement('span');
                email.className = 'ann-user-email';
                email.textContent = user.email;

                info.append(name, email);
                label.append(checkbox, info);

                checkbox.addEventListener('change', function () {
                    if (checkbox.checked) {
                        selected.set(id, user);
                    } else {
                        selected.delete(id);
                    }
                    renderSelected();
                });

                results.appendChild(label);
            });
        }

        async function searchUsers(keyword) {
            if (controller) controller.abort();
            controller = new AbortController();

            const thisRequest = ++requestNumber;
            results.textContent = 'Mencari pengguna...';

            try {
                const response = await fetch(
                    url + '?q=' + encodeURIComponent(keyword),
                    {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        signal: controller.signal
                    }
                );

                if (!response.ok) {
                    throw new Error('HTTP ' + response.status);
                }

                const data = await response.json();

                if (thisRequest !== requestNumber) return;

                currentUsers = data.users || [];
                renderResults();

            } catch (error) {
                if (error.name === 'AbortError') return;
                results.textContent = 'Gagal mencari pengguna. Silakan coba lagi.';
                console.error('AJAX pencarian pengguna:', error);
            }
        }

        search.addEventListener('input', function () {
            clearTimeout(timer);

            const keyword = search.value.trim();

            if (keyword.length < 2) {
                if (controller) controller.abort();
                requestNumber++;
                currentUsers = [];
                results.textContent = 'Ketik minimal 2 karakter untuk mencari pengguna.';
                renderSelected();
                return;
            }

            timer = setTimeout(function () {
                searchUsers(keyword);
            }, 300);
        });

        renderSelected();
    });

})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/admin/announcements/index.blade.php ENDPATH**/ ?>