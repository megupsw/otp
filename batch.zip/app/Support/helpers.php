<?php
use App\Models\Setting;
if (!function_exists('setting')) {
    function setting(string $key, mixed $default=null): mixed {
        try { return Setting::where('key',$key)->value('value') ?? $default; }
        catch (\Throwable $e) { return $default; }
    }
}
if (!function_exists('rupiah')) {
    function rupiah(int|float|null $value): string { return 'Rp '.number_format((float)$value,0,',','.'); }
}
