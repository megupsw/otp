<?php
namespace Database\Seeders;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
class AdminSeeder extends Seeder {
 public function run(): void {
  $email=env('ADMIN_EMAIL'); $password=env('ADMIN_PASSWORD');
  if (!$email || !$password || str_contains($password,'CHANGE_THIS')) { $this->command?->warn('Set ADMIN_EMAIL and a strong ADMIN_PASSWORD in .env before seeding.'); return; }
  User::updateOrCreate(['email'=>$email],['name'=>env('ADMIN_NAME','Digistore Admin'),'password'=>Hash::make($password),'role'=>'admin','is_blocked'=>false]);
 }
}
