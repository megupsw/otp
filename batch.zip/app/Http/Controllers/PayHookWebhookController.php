<?php

namespace App\Http\Controllers;

use App\Models\Topup;
use App\Models\User;
use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PayHookWebhookController extends Controller
{
    public function handle(Request $request)
    {
        $token = (string) config('services.payhook.token');
        $secret = (string) config('services.payhook.secret');

        if ($token === '' || $secret === '') {
            Log::error('PayHook belum dikonfigurasi.');
            return response()->json(['error' => 'Webhook not configured'], 503);
        }

        if (! hash_equals($token, (string) $request->bearerToken())) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $raw = $request->getContent();
        $timestamp = (string) $request->header('X-Payhook-Timestamp', '');
        $signature = (string) $request->header('X-Payhook-Signature', '');

        if (! ctype_digit($timestamp) || abs(time() - (int) $timestamp) > 300) {
            return response()->json(['error' => 'Expired timestamp'], 401);
        }

        $expected = 'sha256=' . hash_hmac('sha256', $timestamp . '.' . $raw, $secret);
        if (! hash_equals($expected, $signature)) {
            return response()->json(['error' => 'Invalid signature'], 401);
        }

        $data = json_decode($raw, true);
        if (! is_array($data)) {
            return response()->json(['error' => 'Invalid JSON'], 400);
        }

        $eventId = $data['event_id'] ?? null;
        if (! is_string($eventId) || $eventId === '' || strlen($eventId) > 255) {
            return response()->json(['error' => 'Missing event_id'], 422);
        }

        // Catat metadata minimum untuk diagnosis GoPay.
        Log::info('PayHook payment metadata', [
            'event_type' => $data['event_type'] ?? null,
            'package_name' => $data['package_name'] ?? null,
            'sent_by' => $data['sent_by'] ?? null,
            'has_amount' => isset($data['amount']),
        ]);

        $packageName = (string) ($data['package_name'] ?? '');
        $shopeePackages = ['com.shopee.id', 'com.shopeepay.id'];
        $gopayPackages = ['com.gojek.gopay', 'com.gojek.app'];

        if (($data['event_type'] ?? '') !== 'payment.incoming'
            || (! in_array($packageName, $gopayPackages, true)
                && ! in_array($packageName, $shopeePackages, true))
            || ! isset($data['amount'])
            || ! is_numeric($data['amount'])
            || (int) $data['amount'] <= 0
            || (float) $data['amount'] !== (float) (int) $data['amount']) {
            Log::notice('PayHook event dilewati karena metode atau nominal tidak valid.', [
                'event_id' => $eventId,
                'package_name' => $packageName,
            ]);
            return response()->json(['ok' => true, 'ignored' => true]);
        }

        $isShopeePay = in_array($packageName, $shopeePackages, true);
        $paymentType = $isShopeePay ? 'payhook_shopeepay' : 'payhook_gopay';
        $paymentLabel = $isShopeePay ? 'ShopeePay' : 'GoPay';

        // Retry event yang sama tidak boleh mengisi saldo dua kali.
        if (Topup::where('payhook_event_id', $eventId)->exists()) {
            return response()->json(['ok' => true, 'duplicate' => true]);
        }

        $paidAmount = (int) $data['amount'];

        try {
            $result = DB::transaction(function () use ($eventId, $paidAmount, $data, $paymentType, $paymentLabel) {
                $topup = Topup::where('payment_type', $paymentType)
                    ->where('status', 'pending')
                    ->where('payment_amount', $paidAmount)
                    ->where('expired_at', '>', now())
                    ->lockForUpdate()
                    ->first();

                if (! $topup) {
                    Log::warning('PayHook: pembayaran tidak cocok dengan top up pending.', [
                        'event_id' => $eventId,
                        'amount' => $paidAmount,
                    ]);
                    return 'unmatched';
                }

                // Perbarui secara bersyarat agar event bersamaan tidak mengkredit ulang.
                $changed = Topup::whereKey($topup->id)
                    ->where('status', 'pending')
                    ->whereNull('payhook_event_id')
                    ->update([
                        'status' => 'paid',
                        'paid_at' => now(),
                        'payhook_event_id' => $eventId,
                        'payment_reference' => isset($data['reference'])
                            ? substr((string) $data['reference'], 0, 150)
                            : null,
                        'payload' => $data,
                        'updated_at' => now(),
                    ]);

                if ($changed !== 1) {
                    return 'duplicate';
                }

                $user = User::whereKey($topup->user_id)->lockForUpdate()->firstOrFail();
                $credit = (int) $topup->amount;
                $user->increment('balance', $credit);

                WalletTransaction::create([
                    'user_id' => $user->id,
                    'topup_id' => $topup->id,
                    'type' => 'credit',
                    'amount' => $credit,
                    'description' => 'Top up ' . $paymentLabel . ' PayHook ' . $topup->order_id,
                ]);

                return 'paid';
            });
        } catch (\Illuminate\Database\QueryException $e) {
            // Unique index event_id juga melindungi dari retry bersamaan.
            if (Topup::where('payhook_event_id', $eventId)->exists()) {
                return response()->json(['ok' => true, 'duplicate' => true]);
            }
            throw $e;
        }

        return response()->json([
            'ok' => true,
            'result' => $result,
        ]);
    }
}
