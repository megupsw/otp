<?php

namespace App\Http\Controllers;

use App\Models\Topup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PayHookTopupController extends Controller
{
    public function create(Request $request)
    {
        abort_unless(
            (string) setting('topup_gopay_enabled', '1') === '1',
            403,
            'Pembayaran GoPay sedang dinonaktifkan.'
        );
        $data = $request->validate([
            'amount' => ['required', 'integer', 'min:2000', 'max:2000000'],
        ]);

        $amount = (int) $data['amount'];

        $topup = DB::transaction(function () use ($request, $amount) {
            // Nominal pembayaran unik untuk mengidentifikasi transfer masuk.
            for ($i = 0; $i < 100; $i++) {
                $paymentAmount = $amount + random_int(1, 100);

                $taken = Topup::where('payment_type', 'payhook_gopay')
                    ->where('status', 'pending')
                    ->where('payment_amount', $paymentAmount)
                    ->where('expired_at', '>', now())
                    ->exists();

                if (! $taken) {
                    return Topup::create([
                        'user_id' => $request->user()->id,
                        'order_id' => 'DSOTP-' . strtoupper(Str::random(16)),
                        'amount' => $amount,
                        'payment_amount' => $paymentAmount,
                        'status' => 'pending',
                        'payment_type' => 'payhook_gopay',
                        'expired_at' => now()->addMinutes(30),
                        'payload' => [
                            'gateway' => 'payhook',
                            'source' => 'GoPay',
                        ],
                    ]);
                }
            }

            abort(503, 'Belum dapat membuat nominal pembayaran unik. Silakan coba lagi.');
        });

        return redirect()->route('topup', ['order' => $topup->order_id])
            ->with('success', 'Pesanan top up GoPay berhasil dibuat.');
    }

    public function createShopeePay(Request $request)
    {
        abort_unless(
            (string) setting('topup_shopeepay_enabled', '1') === '1',
            403,
            'Pembayaran ShopeePay sedang dinonaktifkan.'
        );
        $data = $request->validate([
            'amount' => ['required', 'integer', 'min:2000', 'max:2000000'],
        ]);

        $amount = (int) $data['amount'];

        $topup = DB::transaction(function () use ($request, $amount) {
            for ($i = 0; $i < 100; $i++) {
                $paymentAmount = $amount + random_int(1, 100);

                $taken = Topup::where('payment_type', 'payhook_shopeepay')
                    ->where('status', 'pending')
                    ->where('payment_amount', $paymentAmount)
                    ->where('expired_at', '>', now())
                    ->exists();

                if (! $taken) {
                    return Topup::create([
                        'user_id' => $request->user()->id,
                        'order_id' => 'DSOTP-' . strtoupper(Str::random(16)),
                        'amount' => $amount,
                        'payment_amount' => $paymentAmount,
                        'status' => 'pending',
                        'payment_type' => 'payhook_shopeepay',
                        'expired_at' => now()->addMinutes(30),
                        'payload' => [
                            'gateway' => 'payhook',
                            'source' => 'ShopeePay',
                        ],
                    ]);
                }
            }

            abort(503, 'Belum dapat membuat nominal pembayaran unik. Silakan coba lagi.');
        });

        return redirect()->route('topup', ['order' => $topup->order_id])
            ->with('success', 'Pesanan top up ShopeePay berhasil dibuat.');
    }

}
