<?php
namespace App\Http\Controllers;
use App\Models\OtpOrder;
use App\Services\SimuruClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;
class OrderController extends Controller {
    public function index(SimuruClient $api){
        try { $services=$api->services(); $countries=$api->countries(); $prices=$api->pricelist(); $error=null; }
        catch (\Throwable $e) { $services=[]; $countries=[]; $prices=[]; $error='Layanan sedang mengalami gangguan. Silakan coba kembali beberapa saat lagi.'; }
        $markup=(float) (setting('markup_percent',env('DEFAULT_MARKUP_PERCENT',20)));
        $prices=array_map(function($p) use($markup){ $p['selling_price']=(int)ceil(((float)($p['price']??0))*(1+$markup/100)); return $p; },$prices);

        $insights = [];
        try {
            $insights = $api->insightsCountries();
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::notice('Statistik SIMURU tidak tersedia.', [
                'exception' => get_class($e),
            ]);
        }

        $serviceLogos = [];
        foreach ($services as $service) {
            $id = (string) ($service['service_id'] ?? $service['id'] ?? $service['slug'] ?? '');
            $logo = $service['service_image'] ?? $service['image'] ?? null;
            if ($id !== '' && is_string($logo) && filter_var($logo, FILTER_VALIDATE_URL)) {
                $serviceLogos[$id] = $logo;
            }
        }
        return view('order.index', compact('services','countries','prices','error','markup','insights','serviceLogos'));
    }
    public function store(Request $r, SimuruClient $api){
        $data=$r->validate(['service_id'=>'required|string|max:80','country_id'=>'required|integer|min:1','operator'=>'nullable|string|max:80']);
        $markup=(float)setting('markup_percent',env('DEFAULT_MARKUP_PERCENT',20));
        $priceRow=collect($api->pricelist($data['service_id']))->first(fn($p)=>(string)($p['country_id']??'')===(string)$data['country_id']);
        if (!$priceRow) return back()->withErrors(['service_id'=>'Harga layanan tidak tersedia, silakan muat ulang.']);
        $providerPrice=(int)$priceRow['price']; $selling=(int)ceil($providerPrice*(1+$markup/100));
        $user=$r->user();
        try {
            $order=DB::transaction(function() use($user,$providerPrice,$selling,$data,$api,$priceRow) {
                $locked=\App\Models\User::whereKey($user->id)->lockForUpdate()->firstOrFail();
                // Admin boleh memesan OTP tanpa memotong saldo lokal.
                // Pengguna biasa tetap wajib memiliki saldo yang cukup.
                $isAdmin = $locked->role === 'admin';

                if (!$isAdmin && $locked->balance < $selling) {
                    throw new RuntimeException('Saldo tidak cukup. Silakan top up dahulu.');
                }

                // Hanya saldo pengguna biasa yang dipotong.
                if (!$isAdmin) {
                    $locked->decrement('balance', $selling);
                }
                $res=$api->createOrder($data['service_id'],(int)$data['country_id'],$data['operator']??'random');
                $d=$res['data']??[];
                return OtpOrder::create([
                    'user_id'=>$locked->id,'provider_order_id'=>$d['id']??$d['order_id']??null,'external_provider_order_id'=>$d['provider_order_id']??null,
                    'service_id'=>$data['service_id'],'service_name'=>$priceRow['service_name']??$data['service_id'],
                    'country_id'=>(int)$data['country_id'],'country_name'=>$priceRow['country_name']??'',
                    'operator'=>$data['operator']??'random','phone_number'=>$d['phone_number']??null,
                    'provider_price'=>$providerPrice,'selling_price'=>$selling,'status'=>$d['status']??'active',
                    'sms_code'=>$d['sms_code']??null,'sms_data'=>$d['sms_data']??[],
                    'remaining_seconds'=>$d['remaining_seconds']??null,'provider_payload'=>$d
                ]);
            });
            return redirect()->route('otp')->with('success','Order berhasil dibuat.');
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Order OTP gagal diproses.', [
                'user_id' => $r->user()->id,
                'exception' => get_class($e),
                'message' => $e->getMessage(),
            ]);
            $message = $e->getMessage() === 'Saldo tidak cukup. Silakan top up dahulu.'
                ? 'Saldo akun kamu belum mencukupi. Silakan top up terlebih dahulu.'
                : 'Pesanan belum dapat diproses saat ini. Silakan coba kembali beberapa saat lagi.';
            return back()->withErrors(['order' => $message]);
        }
    }
    public function testOtp(Request $r)
    {
        abort_unless($r->user()->role === 'admin', 403);

        $order = OtpOrder::create([
            'user_id' => $r->user()->id,
            'provider_order_id' => 'TEST-' . \Illuminate\Support\Str::random(12),
            'service_id' => 'test',
            'service_name' => 'TEST OTP (SIMULASI)',
            'country_id' => 0,
            'country_name' => 'Lokal',
            'operator' => 'test',
            'phone_number' => '08XXXXXXXXXX',
            'provider_price' => 0,
            'selling_price' => 0,
            'status' => 'active',
            'sms_code' => '123456',
            'sms_data' => [
                ['text' => '[SIMULASI] Kode OTP pengujian: 123456. Ini bukan SMS sungguhan.']
            ],
            'remaining_seconds' => 600,
            'provider_payload' => ['simulation' => true],
        ]);

        return redirect()->route('otp')
            ->with('success', 'OTP simulasi dibuat. Tidak ada nomor SIMURU yang dibeli.');
    }

    private function serviceLogoMap(SimuruClient $api): array
    {
        try {
            $services = $api->services();
        } catch (\Throwable $e) {
            return [];
        }

        $logos = [];
        foreach ($services as $service) {
            if (!empty($service['service_id']) && !empty($service['service_image'])) {
                $logos[(string) $service['service_id']] = (string) $service['service_image'];
            }
        }

        return $logos;
    }

    private function orderExpiredByTime($order): bool
    {
        $expiredAt = data_get($order->provider_payload, 'expired_at');

        if (!$expiredAt) {
            return false;
        }

        try {
            return \Illuminate\Support\Carbon::parse($expiredAt)->isPast();
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function orderPaginator($orders, Request $r, int $perPage = 15)
    {
        $page = max(1, \Illuminate\Pagination\LengthAwarePaginator::resolveCurrentPage());
        $total = $orders->count();
        $items = $orders->slice(($page - 1) * $perPage, $perPage)->values();

        return new \Illuminate\Pagination\LengthAwarePaginator(
            $items,
            $total,
            $perPage,
            $page,
            ['path' => $r->url(), 'query' => $r->query()]
        );
    }

    public function otp(Request $r, SimuruClient $api)
    {
        $all = $r->user()->orders()->latest()->get();

        $orders = $all->filter(function ($order) {
            return in_array(strtolower((string) $order->status), ['active', 'pending'], true)
                && !$this->orderExpiredByTime($order);
        })->values();

        return view('otp.index', [
            'orders' => $this->orderPaginator($orders, $r),
            'serviceLogos' => $this->serviceLogoMap($api),
        ]);
    }

    public function inbox(Request $r, SimuruClient $api)
    {
        $all = $r->user()->orders()->latest()->get();

        $orders = $all->filter(function ($order) {
            $status = strtolower((string) $order->status);
            $expiredAt = data_get($order->provider_payload, 'expired_at');

            // Order yang sudah mencapai status akhir tetap masuk Inbox.
            if (!in_array($status, ['active', 'pending'], true)) {
                return true;
            }

            // Order aktif/pending masuk Inbox jika waktu kedaluwarsanya lewat.
            if ($expiredAt) {
                try {
                    return \Illuminate\Support\Carbon::parse($expiredAt)->isPast();
                } catch (\Throwable $e) {
                    // Format tanggal tidak valid: jangan anggap kedaluwarsa.
                    return false;
                }
            }

            return false;
        })->values();

        return view('otp.inbox', [
            'orders' => $this->orderPaginator($orders, $r, 20),
            'serviceLogos' => $this->serviceLogoMap($api),
        ]);
    }

    public function refresh(Request $r, OtpOrder $order, SimuruClient $api)
    {
        if (str_starts_with((string) $order->provider_order_id, 'TEST-')) {
            return back()->with('success', 'Order simulasi berhasil dibatalkan.');
        }

        abort_unless($order->user_id === $r->user()->id, 404);

        try {
            try {
                $d = $api->activeDetail((int) $order->provider_order_id);
            } catch (\Throwable $activeError) {
                $externalId = (string) $order->external_provider_order_id;

                if ($externalId === '') {
                    throw $activeError;
                }

                $history = $api->findHistoryByExternalId($externalId);
                $payload = (array) ($order->provider_payload ?? []);
                $historyStatus = strtolower(trim((string) ($history['status'] ?? '')));

                $matchesOrder =
                    !empty($history)
                    && (string) ($history['provider_order_id'] ?? '') === $externalId
                    && (string) ($history['phone_number'] ?? '') === (string) $order->phone_number
                    && (string) ($history['service_id'] ?? '') === (string) ($payload['service_id'] ?? '')
                    && (string) ($history['country_id'] ?? '') === (string) ($payload['country_id'] ?? '');

                $terminalStatuses = [
                    'completed', 'complete', 'success',
                    'canceled', 'cancelled', 'expired', 'failed',
                ];

                if (!$matchesOrder || !in_array($historyStatus, $terminalStatuses, true)) {
                    throw $activeError;
                }

                $normalizedStatus = $historyStatus === 'cancelled'
                    ? 'canceled'
                    : (in_array($historyStatus, ['complete', 'success'], true)
                        ? 'completed'
                        : $historyStatus);

                $payload['status'] = $historyStatus;
                $payload['history_sync_status'] = $historyStatus;

                $order->update([
                    'status' => $normalizedStatus,
                    'sms_code' => $history['sms_code'] ?? $order->sms_code,
                    'sms_data' => $history['sms_data'] ?? $order->sms_data ?? [],
                    'remaining_seconds' => $history['remaining_seconds'] ?? $order->remaining_seconds,
                    'provider_payload' => $payload,
                ]);

                if ($r->expectsJson()) {
                    return response()->json([
                        'ok' => true,
                        'phone_number' => $order->phone_number,
                        'status' => $order->status,
                        'sms_code' => $order->sms_code,
                        'sms_data' => $order->sms_data ?? [],
                        'remaining_seconds' => $order->remaining_seconds,
                        'expired_at' => $history['expired_at'] ?? data_get($payload, 'expired_at'),
                        'source' => 'history',
                    ]);
                }

                return back()->with('success', 'Status OTP diperbarui dari riwayat provider.');
            }

            $smsData = $d['sms_data'] ?? $order->sms_data ?? [];
            $smsCode = $d['sms_code'] ?? $order->sms_code;

            // Jika ada pesan SMS baru, ambil kode dari pesan terakhir.
            // Beberapa provider mempertahankan sms_code lama walaupun sms_data bertambah.
            if (is_array($smsData) && count($smsData) > 0) {
                $latestSms = end($smsData);
                $latestText = is_array($latestSms)
                    ? (string) ($latestSms['text'] ?? '')
                    : (is_string($latestSms) ? $latestSms : '');

                if ($latestText !== '' &&
                    preg_match('/\b(\d{4,8})\b/', $latestText, $matches)) {
                    $smsCode = $matches[1];
                }
            }

            $order->update([
                'phone_number' => $d['phone_number'] ?? $order->phone_number,
                'status' => $d['status'] ?? $order->status,
                'sms_code' => $smsCode,
                'sms_data' => $smsData,
                'remaining_seconds' => $d['remaining_seconds'] ?? $order->remaining_seconds,
                'provider_payload' => $d,
            ]);

            // Kirim notifikasi hanya jika ada kode dan kode itu belum ditandai terkirim.
            // Penanda disimpan hanya setelah gateway menerima pesan.
            $freshCode = trim((string) $order->sms_code);
            if ($freshCode !== ''
                && $freshCode !== (string) $order->whatsapp_notified_code
                && preg_match('/^\d{4,8}$/', $freshCode)) {
                $user = $order->user;
                $whatsappPhone = $user?->whatsapp_phone;

                if ($whatsappPhone) {
                    $message = "DEPUKA OTP - SMS baru diterima\n"
                        . "Layanan: " . $order->service_name . "\n"
                        . "Nomor virtual: " . ($order->phone_number ?: '-') . "\n"
                        . "Kode OTP: " . $freshCode . "\n"
                        . "Jangan bagikan kode ini kepada siapa pun.";

                    try {
                        $gatewayClass = \App\Services\WhatsAppGateway::class;

                        if (class_exists($gatewayClass)) {
                            $sent = app($gatewayClass)->send($whatsappPhone, $message);

                            if ($sent) {
                                $order->whatsapp_notified_code = $freshCode;
                                $order->save();
                            }
                        }
                    } catch (\Throwable $whatsappError) {
                        \Illuminate\Support\Facades\Log::warning(
                            'Notifikasi WhatsApp gagal; refresh OTP tetap dilanjutkan.',
                            ['error' => $whatsappError->getMessage()]
                        );
                    }
                }
            }

            if ($r->expectsJson()) {
                return response()->json([
                    'ok' => true,
                    'phone_number' => $order->phone_number,
                    'status' => $order->status,
                    'sms_code' => $order->sms_code,
                    'sms_data' => $order->sms_data ?? [],
                    'remaining_seconds' => $order->remaining_seconds,
                    'expired_at' => $d['expired_at'] ?? null,
                ]);
            }

            return back()->with('success', 'Status OTP diperbarui.');
        } catch (\Throwable $e) {
            if ($r->expectsJson()) {
                return response()->json(['ok' => false, 'message' => $e->getMessage()], 502);
            }
            return back()->withErrors(['otp' => $e->getMessage()]);
        }
    }

    public function cancel(Request $r, OtpOrder $order, SimuruClient $api)
    {
        if (str_starts_with((string) $order->provider_order_id, 'TEST-')) {
            return back()->with('success', 'Order simulasi tidak memanggil SIMURU.');
        }

        abort_unless($order->user_id === $r->user()->id, 404);

        if (!in_array($order->status, ['active', 'pending'], true)) {
            return back()->withErrors(['otp' => 'Order ini sudah tidak aktif.']);
        }

        try {
            $d = $api->activeDetail((int) $order->provider_order_id);

            $smsCode = $d['sms_code'] ?? $order->sms_code;
            $smsData = $d['sms_data'] ?? $order->sms_data;
            $providerStatus = strtolower((string) ($d['status'] ?? $order->status));

            $order->update([
                'phone_number' => $d['phone_number'] ?? $order->phone_number,
                'sms_code' => $smsCode,
                'sms_data' => $smsData,
                'status' => $d['status'] ?? $order->status,
                'remaining_seconds' => $d['remaining_seconds'] ?? $order->remaining_seconds,
                'provider_payload' => $d,
            ]);

            if (!empty($smsCode) || !empty($smsData)) {
                return back()->withErrors([
                    'otp' => 'SMS sudah masuk. Order tidak dibatalkan otomatis.'
                ]);
            }

            if (!in_array($providerStatus, ['active', 'pending'], true)) {
                return back()->withErrors([
                    'otp' => 'Status nomor dari provider sudah berubah. Silakan refresh status order sebelum mencoba lagi.'
                ]);
            }

            $api->cancel((int) $order->provider_order_id);

            $refunded = \Illuminate\Support\Facades\DB::transaction(function () use ($order) {
                $locked = OtpOrder::whereKey($order->id)->lockForUpdate()->firstOrFail();

                if (!in_array($locked->status, ['active', 'pending'], true)) {
                    return false;
                }

                $locked->update(['status' => 'canceled']);

                $user = \App\Models\User::whereKey($locked->user_id)
                    ->lockForUpdate()->firstOrFail();

                // Admin tidak dipotong saldo saat membuat order.
                if ($user->role !== 'admin') {
                    $user->increment('balance', (int) $locked->selling_price);

                    \App\Models\WalletTransaction::create([
                        'user_id' => $user->id,
                        'topup_id' => null,
                        'type' => 'refund',
                        'amount' => (int) $locked->selling_price,
                        'description' => 'Refund pembatalan OTP order #' . $locked->id,
                    ]);
                }

                return true;
            });

            if (!$refunded) {
                return back()->withErrors([
                    'otp' => 'Status order lokal sudah berubah. Saldo tidak dikembalikan dua kali.'
                ]);
            }

            return back()->with('success', 'Order berhasil dibatalkan dan proses refund selesai.');

        } catch (\Throwable $e) {
            $message = $e->getMessage();

            if (
                str_contains($message, 'HTTP 422') &&
                str_contains(strtolower($message), 'batas waktu minimum')
            ) {
                return back()->withErrors([
                    'otp' => 'Provider belum mengizinkan pembatalan nomor ini. Tunggu beberapa saat, lalu coba batalkan kembali. Status order dan saldo tetap dipertahankan sampai provider mengonfirmasi pembatalan.'
                ]);
            }

            return back()->withErrors([
                'otp' => 'Pembatalan belum berhasil dikonfirmasi. Silakan coba lagi dalam 3–5 menit.'
            ]);
        }
    }

    public function finish(Request $r, OtpOrder $order, SimuruClient $api)
    {
        if (str_starts_with((string) $order->provider_order_id, 'TEST-')) {
            return back()->with('success', 'Order simulasi tidak memanggil SIMURU.');
        }

        abort_unless($order->user_id === $r->user()->id, 404);

        try {
            $d = $api->activeDetail((int) $order->provider_order_id);
            $code = $d['sms_code'] ?? $order->sms_code;

            $order->update([
                'phone_number' => $d['phone_number'] ?? $order->phone_number,
                'sms_code' => $code,
                'sms_data' => $d['sms_data'] ?? $order->sms_data,
                'status' => $d['status'] ?? $order->status,
                'remaining_seconds' => $d['remaining_seconds'] ?? $order->remaining_seconds,
                'provider_payload' => $d,
            ]);

            if (empty($code)) {
                return back()->withErrors(['otp' => 'Kode OTP belum diterima. Tombol selesai belum dapat digunakan.']);
            }

            $api->finish((int) $order->provider_order_id);
            $order->update(['status' => 'completed']);

            return back()->with('success', 'Order berhasil diselesaikan.');
        } catch (\Throwable $e) {
            return back()->withErrors(['otp' => 'Order belum berhasil diselesaikan: ' . $e->getMessage()]);
        }
    }
    public function history(Request $r)
    {
        $user = $r->user();

        $orders = $user->orders()
            ->latest()
            ->paginate(10, ['*'], 'order_page')
            ->appends($r->except('order_page'));

        $topups = $user->topups()
            ->latest()
            ->paginate(10, ['*'], 'topup_page')
            ->appends($r->except('topup_page'));

        $walletTransactions = \App\Models\WalletTransaction::where('user_id', $user->id)
            ->latest()
            ->paginate(15, ['*'], 'wallet_page')
            ->appends($r->except('wallet_page'));

        return view('history', compact('orders', 'topups', 'walletTransactions'));
    }
}
