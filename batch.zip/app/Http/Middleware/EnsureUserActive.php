<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class EnsureUserActive {
    public function handle(Request $request, Closure $next): Response {
        if ($request->user()?->is_blocked) {
            auth()->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return redirect()->route('login')->withErrors(['email' => 'Akun diblokir. Hubungi administrator.']);
        }
        return $next($request);
    }
}
