<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\SupportTicket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SupportTicketController extends Controller
{
    public function index()
    {
        $tickets = auth()->user()
            ->supportTickets()
            ->latest()
            ->paginate(10);

        $phone = preg_replace(
            '/\D+/',
            '',
            (string) Setting::where('key', 'cs_whatsapp')->value('value')
        );

        return view('support.index', compact('tickets', 'phone'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'subject' => ['required', 'string', 'max:120'],
            'category' => ['required', 'in:akun,pembayaran,otp,teknis,lainnya'],
            'message' => ['required', 'string', 'min:10', 'max:5000'],
            'attachment' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:5120',
            ],
        ]);

        do {
            $number = 'TKT-' . now()->format('ymd') . '-' . strtoupper(Str::random(6));
        } while (SupportTicket::where('ticket_number', $number)->exists());

        $attachmentPath = null;

        if ($request->hasFile('attachment')) {
            $attachmentPath = Storage::disk('local')->putFile(
                'support-attachments',
                $request->file('attachment')
            );
        }

        try {
            auth()->user()->supportTickets()->create([
                'ticket_number' => $number,
                'subject' => $data['subject'],
                'category' => $data['category'],
                'message' => $data['message'],
                'attachment_path' => $attachmentPath,
                'status' => 'baru',
            ]);
        } catch (\Throwable $e) {
            if ($attachmentPath) {
                Storage::disk('local')->delete($attachmentPath);
            }

            throw $e;
        }

        return redirect()
            ->route('support.index')
            ->with('success', "Laporan berhasil dibuat. Nomor tiket: {$number}");
    }

    public function attachment(SupportTicket $ticket)
    {
        abort_unless((int) $ticket->user_id === (int) auth()->id(), 404);
        abort_unless($ticket->attachment_path, 404);

        $disk = Storage::disk('local');

        abort_unless($disk->exists($ticket->attachment_path), 404);

        return $disk->response($ticket->attachment_path);
    }
}
