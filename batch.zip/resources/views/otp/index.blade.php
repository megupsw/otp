
<style>
.phone-number-row {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin:12px 0;
}
.phone-number-row .phone-number {
    min-width:0;
    overflow-wrap:anywhere;
}
.copy-number-btn {
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    flex-shrink:0;
    padding:8px 11px;
    border:1px solid var(--line);
    border-radius:10px;
    background:var(--panel);
    color:var(--white);
    font:inherit;
    font-size:12px;
    cursor:pointer;
    transition:background .2s,border-color .2s,transform .2s;
}
.copy-number-btn:hover {
    border-color:var(--blue);
    background:color-mix(in srgb,var(--blue) 12%,var(--panel));
}
.copy-number-btn:active { transform:scale(.96); }
.copy-number-btn i { color:var(--blue); font-size:14px; }
.copy-number-btn.copied { border-color:#10b981; color:#10b981; }
@media(max-width:480px) {
    .copy-number-btn { padding:8px; }
    .copy-number-btn span { display:none; }
}
</style>
<script>
async function copyOtpNumber(button, number) {
    try {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(String(number));
        } else {
            const input = document.createElement('textarea');
            input.value = String(number);
            input.style.position = 'fixed';
            input.style.opacity = '0';
            document.body.appendChild(input);
            input.select();
            const copied = document.execCommand('copy');
            input.remove();
            if (!copied) throw new Error('Gagal menyalin nomor');
        }

        const original = button.innerHTML;
        button.innerHTML = '<i class="bi bi-check2"></i><span>Tersalin</span>';
        button.classList.add('copied');
        setTimeout(() => {
            button.innerHTML = original;
            button.classList.remove('copied');
        }, 1500);
    } catch (error) {
        alert('Nomor gagal disalin. Silakan salin secara manual.');
    }
}
</script>
<style>
.whatsapp-login-guide {
    margin-top:14px;
    padding:16px;
    border:1px solid var(--line);
    border-radius:14px;
    background:var(--panel);
    color:var(--white);
    font-size:12px;
    line-height:1.75;
}
.whatsapp-guide-heading {
    display:flex;
    align-items:flex-start;
    gap:9px;
    margin-bottom:10px;
    font-size:13px;
}
.whatsapp-guide-heading i {
    color:#25d366;
    font-size:19px;
    flex:0 0 auto;
}
.whatsapp-login-guide ol {
    margin:0;
    padding-left:22px;
}
.whatsapp-login-guide li {
    padding:3px 0 5px 3px;
}
.whatsapp-login-guide p {
    margin:10px 0 0;
    padding-top:10px;
    border-top:1px solid var(--line);
    font-weight:700;
}
</style>

@extends('layouts.app')
@section('title','Pesan OTP')@section('crumb','INBOX')@section('heading','Pesan OTP')
@section('content')
<div class="page-intro">
    <div><h2>Inbox nomor aktif</h2><p class="muted">Pantau nomor, status, kode OTP, dan waktu tersisa.</p></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        @if(auth()->user()->role === 'admin')
        <form method="POST" action="{{ route('admin.test-otp') }}">
            @csrf
            <button class="btn secondary" type="submit">Tes OTP (Simulasi)</button>
        </form>
        @endif
        <a class="btn primary" href="{{ route('order') }}">＋ Order baru</a>
    </div>
</div>
<div class="otp-grid">@forelse($orders as $o)<div class="panel otp-card"><div class="otp-card-top">@if(!empty($serviceLogos[$o->service_id] ?? null))
<img class="service-logo" src="{{ $serviceLogos[$o->service_id] }}" alt="{{ $o->service_name }}" loading="lazy" referrerpolicy="no-referrer">
@else
<span class="service-logo">{{ strtoupper(substr($o->service_name,0,1)) }}</span>
@endif<span class="status {{ $o->status }}">{{ $o->status }}</span></div><h3>{{ $o->service_name }}</h3><div class="otp-network-details">
    <span><i class="bi bi-globe2"></i> {{ $o->country_name ?: 'Negara tidak tersedia' }}</span>
    <span><i class="bi bi-sim"></i> Operator: {{ ucfirst(str_replace('_', ' ', $o->operator ?: 'random')) }}</span>
</div>
<div class="phone-number-row">
    <div class="phone-number">{{ $o->phone_number ?? 'Menunggu nomor...' }}</div>
    @if($o->phone_number)
        <button type="button" class="copy-number-btn"
            onclick="copyOtpNumber(this, @js($o->phone_number))"
            title="Salin nomor" aria-label="Salin nomor telepon">
            <i class="bi bi-copy"></i>
            <span>Salin</span>
        </button>
    @endif
</div><div class="otp-details"><div><small>Harga</small><b>{{ rupiah($o->selling_price) }}</b></div><div><small>Sisa waktu</small><b class="otp-countdown" data-expired-at="{{ $o->provider_payload['expired_at'] ?? '' }}" data-remaining="{{ $o->remaining_seconds ?? 0 }}">{{ $o->remaining_seconds !== null ? gmdate('i:s', max(0, $o->remaining_seconds)) : '—' }}</b></div></div><div class="code-box"><small>KODE OTP</small><strong>{{ $o->sms_code ?? 'Menunggu SMS' }}</strong>@if($o->sms_code)<button class="icon-btn" onclick="navigator.clipboard.writeText('{{ $o->sms_code }}')">⧉</button>@endif</div>@if($o->sms_data)<div class="sms-data">@foreach($o->sms_data as $sms)<p>{{ $sms['text'] ?? json_encode($sms) }}</p>@endforeach</div>@endif
@if(str_contains(strtolower((string)($o->service_name ?? '')), 'whatsapp'))
<div class="whatsapp-login-guide">
    <div class="whatsapp-guide-heading">
        <i class="bi bi-whatsapp"></i>
        <strong>WhatsApp muncul "Login tidak tersedia saat ini"?</strong>
    </div>
    <ol>
        <li>Matikan WiFi, pakai jaringan seluler (kuota) — login lewat WiFi sering ditolak WhatsApp.</li>
        <li>Hapus aplikasi WhatsApp, lalu unduh dan pasang ulang.</li>
        <li>Setelah memakai jaringan seluler, nyalakan mode pesawat 30 detik lalu matikan lagi — IP berganti supaya tidak terdeteksi WhatsApp.</li>
        <li>Buka WhatsApp lagi, lalu minta kode sekali lagi.</li>
    </ol>
    <p>Pastikan pakai cara ini secara berurutan — ini yang membuat login berhasil.</p>
</div>
@endif

<div class="card-actions"><form method="POST" action="{{ route('otp.refresh',$o) }}">@csrf<button class="btn secondary">↻ Perbarui</button></form><form method="POST" action="{{ route('otp.finish',$o) }}"
    class="finish-form" @if(empty($o->sms_code)) hidden @endif
    onsubmit="return confirm('Selesaikan pesanan OTP ini?')">
    @csrf
    <button class="btn primary finish-button" type="submit">
        <i class="bi bi-check-circle"></i> Selesai
    </button>
</form><form method="POST" action="{{ route('otp.cancel',$o) }}" class="cancel-form">
    @csrf
    <button class="btn danger cancel-trigger" type="button">
        <i class="bi bi-x-circle"></i> Batalkan
    </button>
</form></div></div>@empty<div class="panel empty-panel"><div class="empty-symbol">▣</div><h3>Belum ada OTP aktif</h3><p class="muted">Pesan nomor untuk layanan yang kamu butuhkan.</p><a class="btn primary" href="{{ route('order') }}">Mulai order</a></div>@endforelse</div>{{ $orders->links() }}

<script>
document.querySelectorAll('.otp-card').forEach(card => {
    const timeEl = card.querySelector('.otp-countdown');
    let seconds = Number(timeEl?.dataset.remaining || 0);
    let expiresAt = timeEl?.dataset.expiredAt
        ? Date.parse(timeEl.dataset.expiredAt)
        : NaN;
    let estimatedExpiry = Number.isFinite(expiresAt)
        ? expiresAt
        : Date.now() + seconds * 1000;

    function renderCountdown() {
        if (!timeEl) return;
        seconds = Math.max(0, Math.ceil((estimatedExpiry - Date.now()) / 1000));
        timeEl.textContent = String(Math.floor(seconds / 60)).padStart(2, '0')
            + ':' + String(seconds % 60).padStart(2, '0');
    }

    renderCountdown();
    setInterval(renderCountdown, 1000);

    const refreshForm = card.querySelector('form[action*="/refresh"]');
    if (!refreshForm) return;

    const refreshUrl = refreshForm.action;
    const csrf = refreshForm.querySelector('input[name="_token"]')?.value;
    let refreshing = false;

    async function refreshOtp() {
        if (refreshing || document.hidden) return;
        refreshing = true;

        try {
            const response = await fetch(refreshUrl, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': csrf
                }
            });

            const data = await response.json().catch(() => ({}));
            if (!response.ok || !data.ok) {
                console.error('[OTP Polling] HTTP ' + response.status, data.message || data);
                return;
            }

            const phone = card.querySelector('.phone-number');
            if (phone && data.phone_number) phone.textContent = data.phone_number;

            const codeBox = card.querySelector('.code-box');
            const code = codeBox?.querySelector('strong');
            if (code && typeof data.sms_code === 'string' && data.sms_code.trim() !== '') {
                code.textContent = data.sms_code.trim();
            }

            // Perbarui pesan SMS tanpa reload halaman.
            let smsBox = card.querySelector('.sms-data');
            const messages = Array.isArray(data.sms_data) ? data.sms_data : [];

            if (messages.length > 0) {
                if (!smsBox) {
                    smsBox = document.createElement('div');
                    smsBox.className = 'sms-data';
                    codeBox?.insertAdjacentElement('afterend', smsBox);
                }

                if (smsBox) {
                    const signature = JSON.stringify(messages);
                    if (smsBox.dataset.signature !== signature) {
                        smsBox.replaceChildren();
                        messages.forEach(sms => {
                            const p = document.createElement('p');
                            p.textContent = typeof sms === 'object' && sms !== null
                                ? (sms.text ?? JSON.stringify(sms))
                                : String(sms);
                            smsBox.appendChild(p);
                        });
                        smsBox.dataset.signature = signature;
                    }
                }
            }

            if (typeof data.remaining_seconds === 'number' && timeEl) {
                // Sinkronkan perkiraan waktu kedaluwarsa dari server.
                // Jangan mengatur ulang timer setiap detik; polling hanya mengoreksi drift.
                if (data.expired_at) {
                    const providerExpiry = Date.parse(data.expired_at);
                    if (Number.isFinite(providerExpiry)) estimatedExpiry = providerExpiry;
                } else {
                    const serverEstimate = Date.now() + Math.max(0, data.remaining_seconds) * 1000;
                    if (Math.abs(serverEstimate - estimatedExpiry) > 3000) {
                        estimatedExpiry = serverEstimate;
                    }
                }
                renderCountdown();
            }

            // Perbarui status langsung di kartu.
            const statusEl = card.querySelector('.status');
            if (statusEl && data.status) {
                statusEl.className = 'status ' + data.status;
                statusEl.textContent = data.status;
            }

            // Tombol Selesai hanya tampil jika kode OTP benar-benar diterima.
            const actions = card.querySelector('.card-actions');
            if (actions) {
                const finishForm = actions.querySelector('.finish-form');
                const cancelForm = actions.querySelector('form[action*="/cancel"]');
                const codeBox = card.querySelector('.code-box');
                const displayedCode = codeBox?.querySelector('strong')?.textContent?.trim() || '';
                const currentCode = String(data.sms_code || displayedCode).trim();
                const hasCode = /^\d{4,8}$/.test(currentCode);
                const currentStatus = String(data.status || '').toLowerCase();
                const finished = ['completed', 'canceled', 'expired'].includes(currentStatus);

                if (finishForm) finishForm.hidden = !hasCode || finished;
                if (cancelForm) cancelForm.hidden = finished;
            }
        } catch (error) {
            console.error('[OTP Polling] Gagal memperbarui OTP:', error);
        } finally {
            refreshing = false;
        }
    }

    // Refresh pertama setelah halaman dibuka, lalu setiap 7 detik.
    refreshOtp();
    setInterval(refreshOtp, 3000);
});
</script>
<style>
.otp-network-details {
    display:flex;
    flex-wrap:wrap;
    gap:8px;
    margin:8px 0 12px;
}
.otp-network-details span {
    display:inline-flex;
    align-items:center;
    gap:6px;
    padding:6px 10px;
    border:1px solid var(--line);
    border-radius:9px;
    background:var(--panel);
    color:var(--muted);
    font-size:12px;
}
.otp-network-details i { color:var(--blue); }
.finish-button {
    background:linear-gradient(135deg,#16a875,#07845a);
    border-color:#07845a;
    color:#fff;
}
.finish-button:hover { filter:brightness(1.06); }
.finish-form[hidden] { display:none !important; }
@media(max-width:480px) {
    .otp-network-details { gap:6px; }
    .otp-network-details span { font-size:11px; padding:6px 8px; }
    .card-actions { flex-wrap:wrap; }
}
</style>



<!-- Modal konfirmasi pembatalan Depuka OTP -->
<div class="depuka-modal" id="cancelModal" aria-hidden="true">
    <div class="depuka-modal-backdrop" data-modal-close></div>
    <section class="depuka-modal-dialog" role="dialog"
        aria-modal="true" aria-labelledby="cancelModalTitle"
        aria-describedby="cancelModalDescription">
        <div class="depuka-modal-icon">
            <svg viewBox="0 0 24 24" width="30" height="30"
     fill="none" stroke="currentColor" stroke-width="2"
     stroke-linecap="round" stroke-linejoin="round"
     aria-hidden="true">
    <path d="M10.3 3.9 2.6 17.2A2 2 0 0 0 4.3 20h15.4a2 2 0 0 0 1.7-2.8L13.7 3.9a2 2 0 0 0-3.4 0Z"/>
    <path d="M12 9v4"/>
    <path d="M12 17h.01"/>
</svg>
        </div>
        <h2 id="cancelModalTitle">Batalkan pesanan?</h2>
        <p id="cancelModalDescription">
            Apakah kamu yakin ingin membatalkan nomor OTP ini?
        </p>
        <div class="depuka-modal-note">
            <i class="bi bi-info-circle"></i>
            <span>Pembatalan akan diproses sesuai status nomor. Jika SMS sudah masuk, pesanan mungkin tidak dapat dibatalkan.</span>
        </div>
        <div class="depuka-modal-actions">
            <button type="button" class="depuka-modal-button modal-keep" data-modal-close>
                Kembali
            </button>
            <button type="button" class="depuka-modal-button modal-confirm" id="confirmCancel">
                <i class="bi bi-x-circle"></i> Ya, batalkan
            </button>
        </div>
    </section>
</div>

<style>
.depuka-modal[aria-hidden="true"] { display:none !important; }
.depuka-modal {
    position:fixed; inset:0; z-index:99999;
    display:grid; place-items:center; padding:20px;
}
.depuka-modal-backdrop {
    position:absolute; inset:0;
    background:rgba(9,16,32,.72);
    backdrop-filter:blur(5px);
}
.depuka-modal-dialog {
    position:relative;
    width:min(100%,430px);
    padding:30px;
    border:1px solid #e0e7f2;
    border-radius:22px;
    background:#ffffff !important;
    color:#17243b !important;
    box-shadow:0 28px 90px rgba(0,0,0,.32);
    animation:depukaPop .2s ease-out;
}
.depuka-modal-dialog h2 {
    margin:0 0 10px;
    color:#17243b !important;
    font-size:23px; line-height:1.3;
    letter-spacing:-.5px;
}
.depuka-modal-dialog p {
    margin:0;
    color:#58677f !important;
    font-size:14px; line-height:1.7;
}
.depuka-modal-icon {
    width:58px;height:58px;
    display:grid;place-items:center;
    margin-bottom:20px;
    border-radius:17px;
    background:#fff1cc !important;
    color:#a65a00 !important;
    font-size:25px;
}
.depuka-modal-icon i { color:#a65a00 !important; }
.depuka-modal-note {
    display:flex;gap:10px;align-items:flex-start;
    margin-top:19px;padding:14px;
    border:1px solid #e0e7f2;
    border-radius:12px;
    background:#f4f7fc !important;
    color:#52627a !important;
    font-size:12px;line-height:1.65;
}
.depuka-modal-note i {
    color:#4563e9 !important;
    font-size:16px;flex-shrink:0;
}
.depuka-modal-actions {
    display:flex;justify-content:flex-end;
    gap:10px;margin-top:24px;
}
.depuka-modal-button {
    min-height:45px;padding:0 17px;
    border-radius:11px;
    font-family:inherit;font-size:13px;font-weight:750;
    cursor:pointer;transition:filter .15s,transform .15s;
}
.depuka-modal-button:hover { filter:brightness(.96);transform:translateY(-1px); }
.modal-keep {
    color:#263653 !important;
    background:#ffffff !important;
    border:1px solid #cbd5e4 !important;
}
.modal-confirm {
    display:inline-flex;align-items:center;justify-content:center;gap:8px;
    color:#ffffff !important;
    background:#d92d43 !important;
    border:1px solid #d92d43 !important;
    box-shadow:0 5px 14px rgba(217,45,67,.2);
}
.modal-confirm:disabled { opacity:.7;cursor:wait; }

html[data-theme="dark"] .depuka-modal-dialog {
    background:#111a2b !important;
    border-color:#30405b;
    color:#f4f7ff !important;
}
html[data-theme="dark"] .depuka-modal-dialog h2 {
    color:#f4f7ff !important;
}
html[data-theme="dark"] .depuka-modal-dialog p {
    color:#b2bfd5 !important;
}
html[data-theme="dark"] .depuka-modal-note {
    background:#19253b !important;
    border-color:#30405b;
    color:#c0cbe0 !important;
}
html[data-theme="dark"] .modal-keep {
    color:#f4f7ff !important;
    background:#1b2941 !important;
    border-color:#435575 !important;
}
@keyframes depukaPop {
    from { opacity:0;transform:translateY(9px) scale(.98); }
    to { opacity:1;transform:translateY(0) scale(1); }
}
@media(max-width:420px) {
    .depuka-modal { padding:15px; }
    .depuka-modal-dialog { padding:23px;border-radius:18px; }
    .depuka-modal-dialog h2 { font-size:21px; }
    .depuka-modal-actions { flex-direction:column-reverse; }
    .depuka-modal-button { width:100%;min-height:47px; }
}
@media(prefers-reduced-motion:reduce) {
    .depuka-modal-dialog { animation:none; }
}
</style>

<script>
(() => {
    const modal = document.getElementById('cancelModal');
    const confirmButton = document.getElementById('confirmCancel');
    if (!modal || !confirmButton) return;

    let pendingForm = null;
    let previousFocus = null;

    function closeModal() {
        modal.setAttribute('aria-hidden', 'true');
        pendingForm = null;
        if (previousFocus) previousFocus.focus();
    }

    document.querySelectorAll('.cancel-trigger').forEach(button => {
        button.addEventListener('click', () => {
            pendingForm = button.closest('.cancel-form');
            previousFocus = button;
            modal.setAttribute('aria-hidden', 'false');
            confirmButton.focus();
        });
    });

    modal.querySelectorAll('[data-modal-close]').forEach(button => {
        button.addEventListener('click', closeModal);
    });

    confirmButton.addEventListener('click', () => {
        if (!pendingForm) return;
        confirmButton.disabled = true;
        confirmButton.innerHTML = '<i class="bi bi-hourglass-split"></i> Memproses...';
        pendingForm.submit();
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
            closeModal();
        }
    });
})();
</script>

@endsection


<style id="otp-waiting-animation">
.otp-waiting-animated {
    display: inline-flex !important;
    align-items: center;
    gap: 9px;
    color: #315be7;
    font-weight: 800;
    letter-spacing: 2px;
    animation: otpTextPulse 1.8s ease-in-out infinite;
}
.otp-waiting-animated::before {
    content: "";
    display: inline-block;
    width: 9px;
    height: 9px;
    flex: 0 0 9px;
    border-radius: 50%;
    background: #5685ff;
    box-shadow: 0 0 0 0 rgba(86,133,255,.5);
    animation: otpSignal 1.6s ease-out infinite;
}
.otp-waiting-dots {
    display: inline-flex;
    gap: 4px;
    align-items: center;
    letter-spacing: 0;
}
.otp-waiting-dots i {
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: currentColor;
    animation: otpDotBounce 1.1s ease-in-out infinite;
}
.otp-waiting-dots i:nth-child(2) { animation-delay: .15s; }
.otp-waiting-dots i:nth-child(3) { animation-delay: .3s; }

@keyframes otpDotBounce {
    0%, 60%, 100% { transform: translateY(0); opacity: .35; }
    30% { transform: translateY(-5px); opacity: 1; }
}
@keyframes otpSignal {
    0% { box-shadow: 0 0 0 0 rgba(86,133,255,.45); }
    75%, 100% { box-shadow: 0 0 0 9px rgba(86,133,255,0); }
}
@keyframes otpTextPulse {
    0%, 100% { opacity: 1; }
    50% { opacity: .65; }
}
@media (prefers-reduced-motion: reduce) {
    .otp-waiting-animated,
    .otp-waiting-animated::before,
    .otp-waiting-dots i {
        animation: none !important;
    }
}
</style>
<script>
(function () {
    function decorateWaitingText() {
        const walker = document.createTreeWalker(
            document.body,
            NodeFilter.SHOW_TEXT
        );
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);

        nodes.forEach(function (node) {
            if (!/Menunggu SMS/i.test(node.nodeValue || '')) return;

            const el = node.parentElement;
            if (!el || el.closest('script,style')) return;

            // Hindari mengubah elemen besar yang berisi seluruh kartu OTP.
            if (el.children.length > 2) return;

            if (!el.classList.contains('otp-waiting-animated')) {
                el.classList.add('otp-waiting-animated');
            }

            if (!el.querySelector('.otp-waiting-dots')) {
                const dots = document.createElement('span');
                dots.className = 'otp-waiting-dots';
                dots.setAttribute('aria-hidden', 'true');
                dots.innerHTML = '<i></i><i></i><i></i>';
                el.appendChild(dots);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', decorateWaitingText);
    } else {
        decorateWaitingText();
    }

    // Pantau perubahan status setelah body tersedia.
    function observeOtpChanges() {
        const target = document.body;
        if (!target) return;

        let scheduled = false;
        new MutationObserver(function () {
            if (scheduled) return;
            scheduled = true;
            requestAnimationFrame(function () {
                scheduled = false;
                decorateWaitingText();
            });
        }).observe(target, {
            childList: true,
            characterData: true,
            subtree: true
        });
    }

    if (document.body) {
        observeOtpChanges();
    } else {
        document.addEventListener('DOMContentLoaded', observeOtpChanges, { once: true });
    }
})();
</script>

