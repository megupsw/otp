<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('topups', function (Blueprint $table) {
            $table->unsignedBigInteger('payment_amount')->nullable();
            $table->string('payhook_event_id')->nullable()->unique();
        });
    }

    public function down(): void
    {
        Schema::table('topups', function (Blueprint $table) {
            $table->dropUnique(['payhook_event_id']);
            $table->dropColumn(['payment_amount', 'payhook_event_id']);
        });
    }
};
