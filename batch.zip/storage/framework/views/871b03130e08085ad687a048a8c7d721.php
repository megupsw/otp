<!doctype html>
<html lang="id" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <title><?php echo e(setting('login_title', 'Selamat datang')); ?> · <?php echo e(setting('site_name', 'Digistore OTP')); ?></title>

    <script>
        try {
            const savedTheme = localStorage.getItem('depuka-login-theme');
            document.documentElement.dataset.theme =
                savedTheme === 'dark' ? 'dark' : 'light';
        } catch (e) {}
    </script>

    <style>
        :root {
            color-scheme: light;
            --bg: #f4f7fc;
            --surface: rgba(255,255,255,.92);
            --text: #172033;
            --muted: #788397;
            --border: #e5eaf2;
            --input: #f8faff;
            --accent: #4f6df5;
            --accent2: #7658ee;
            --soft: #edf1ff;
            --shadow: 0 24px 80px rgba(37,55,100,.12);
        }

        html[data-theme="dark"] {
            color-scheme: dark;
            --bg: #0b1020;
            --surface: rgba(19,27,47,.94);
            --text: #f0f4ff;
            --muted: #9aa8c2;
            --border: #2a3550;
            --input: #111a2e;
            --accent: #8294ff;
            --accent2: #a28bff;
            --soft: #202b4b;
            --shadow: 0 24px 80px rgba(0,0,0,.28);
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            padding: 30px 18px;
            display: grid;
            place-items: center;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system,
                         BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: var(--text);
            background:
                radial-gradient(ellipse at 12% 12%, rgba(87,112,255,.13), transparent 38%),
                radial-gradient(ellipse at 90% 88%, rgba(135,94,255,.12), transparent 34%),
                var(--bg);
            transition: background .25s, color .25s;
        }

        button, input { font: inherit; }

        .auth-shell {
            width: min(100%, 1000px);
            display: grid;
            grid-template-columns: 1fr 1fr;
            overflow: hidden;
            border: 1px solid var(--border);
            border-radius: 28px;
            background: var(--surface);
            box-shadow: var(--shadow);
            backdrop-filter: blur(18px);
        }

        .welcome-panel {
            position: relative;
            isolation: isolate;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 590px;
            padding: 42px;
            color: #fff;
            background: linear-gradient(145deg, #304ee1 0%, #6555e9 52%, #8b5cf6 100%);
        }

        .welcome-panel::before,
        .welcome-panel::after {
            position: absolute;
            z-index: -1;
            content: "";
            border: 1px solid rgba(255,255,255,.19);
            border-radius: 50%;
        }

        .welcome-panel::before {
            width: 360px;
            height: 360px;
            right: -145px;
            top: 110px;
            box-shadow: 0 0 0 35px rgba(255,255,255,.035),
                        0 0 0 75px rgba(255,255,255,.025);
        }

        .welcome-panel::after {
            width: 180px;
            height: 180px;
            right: 45px;
            top: 195px;
            background: rgba(255,255,255,.055);
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            color: inherit;
            text-decoration: none;
            font-size: 19px;
            font-weight: 800;
            letter-spacing: -.5px;
        }

        .brand-mark {
            display: grid;
            place-items: center;
            width: 43px;
            height: 43px;
            border: 1px solid rgba(255,255,255,.3);
            border-radius: 14px;
            background: rgba(255,255,255,.16);
            font-size: 22px;
            font-weight: 900;
        }

        .brand small {
            display: block;
            margin-top: 2px;
            font-size: 10px;
            font-weight: 600;
            letter-spacing: 3px;
            opacity: .75;
        }

        .welcome-copy { margin: 55px 0; }

        .welcome-label {
            display: inline-block;
            padding: 8px 12px;
            border: 1px solid rgba(255,255,255,.25);
            border-radius: 999px;
            background: rgba(255,255,255,.1);
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 2px;
        }

        .welcome-copy h2 {
            max-width: 390px;
            margin: 22px 0 14px;
            font-size: clamp(30px, 4vw, 43px);
            line-height: 1.13;
            letter-spacing: -1.8px;
        }

        .welcome-copy p {
            max-width: 330px;
            margin: 0;
            color: rgba(255,255,255,.8);
            font-size: 14px;
            line-height: 1.9;
        }

        .welcome-foot {
            color: rgba(255,255,255,.7);
            font-size: 11px;
        }

        .form-panel {
            padding: 35px clamp(25px, 4vw, 52px);
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-width: 0;
        }

        .form-top {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 38px;
        }

        .theme-toggle {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 9px 12px;
            border: 1px solid var(--border);
            border-radius: 999px;
            color: var(--text);
            background: var(--surface);
            cursor: pointer;
            font-size: 12px;
            font-weight: 650;
            transition: .2s;
        }

        .theme-toggle:hover { border-color: var(--accent); }

        .form-heading .eyebrow {
            margin: 0 0 10px;
            color: var(--accent);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 2px;
        }

        .form-heading h1 {
            margin: 0;
            font-size: 31px;
            letter-spacing: -1.2px;
        }

        .form-heading p {
            margin: 10px 0 29px;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.7;
        }

        .field { margin-bottom: 19px; }

        .field label {
            display: block;
            margin-bottom: 9px;
            font-size: 12px;
            font-weight: 750;
        }

        .input-wrap { position: relative; }

        .input-wrap input {
            width: 100%;
            height: 49px;
            padding: 0 45px 0 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            outline: none;
            color: var(--text);
            background: var(--input);
            font-size: 13px;
            transition: border-color .2s, box-shadow .2s;
        }

        .input-wrap input::placeholder { color: var(--muted); opacity: .8; }

        .input-wrap input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(92,111,245,.13);
        }

        .field-icon {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted);
            font-size: 16px;
            pointer-events: none;
        }

        .password-toggle {
            position: absolute;
            right: 9px;
            top: 50%;
            transform: translateY(-50%);
            border: 0;
            padding: 7px;
            color: var(--muted);
            background: transparent;
            cursor: pointer;
            font-size: 11px;
            font-weight: 700;
        }

        .remember-row {
            display: flex;
            align-items: center;
            margin: 3px 0 22px;
        }

        .remember-row label {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            color: var(--muted);
            cursor: pointer;
            font-size: 12px;
        }

        .remember-row input {
            width: 15px;
            height: 15px;
            accent-color: var(--accent);
        }

        .login-button {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: 100%;
            min-height: 49px;
            border: 0;
            border-radius: 12px;
            color: #fff;
            background: linear-gradient(100deg, #4e68ee, #7959ed);
            box-shadow: 0 9px 22px rgba(83,94,226,.22);
            cursor: pointer;
            font-size: 13px;
            font-weight: 800;
            transition: transform .2s, box-shadow .2s;
        }

        .login-button:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 26px rgba(83,94,226,.3);
        }

        .login-button span { font-size: 18px; }

        .error-message {
            margin: 0 0 17px;
            padding: 12px 14px;
            border: 1px solid #f4b8bd;
            border-radius: 10px;
            color: #c92f40;
            background: #fff0f1;
            font-size: 12px;
            line-height: 1.6;
        }

        html[data-theme="dark"] .error-message {
            border-color: #733b4a;
            color: #ff9ba7;
            background: #321d2b;
        }

        .auth-foot {
            margin: 25px 0 0;
            text-align: center;
            color: var(--muted);
            font-size: 12px;
        }

        .auth-foot a {
            color: var(--accent);
            font-weight: 800;
            text-decoration: none;
        }

        .auth-foot a:hover { text-decoration: underline; }

        @media(max-width: 760px) {
            body { padding: 18px 12px; }

            .auth-shell {
                width: min(100%, 460px);
                grid-template-columns: 1fr;
                border-radius: 23px;
            }

            .welcome-panel {
                min-height: auto;
                padding: 25px 26px 28px;
            }

            .welcome-copy { margin: 32px 0 24px; }

            .welcome-copy h2 {
                max-width: 320px;
                margin-top: 15px;
                font-size: 30px;
            }

            .welcome-copy p { font-size: 12px; }
            .welcome-foot { display: none; }

            .form-panel { padding: 25px 26px 30px; }
            .form-top { margin-bottom: 24px; }
            .form-heading h1 { font-size: 27px; }
            .form-heading p { margin-bottom: 24px; }
        }

        @media(prefers-reduced-motion: reduce) {
            *, *::before, *::after {
            }
        }
    </style>
</head>
<body>
    <main class="auth-shell">
        <section class="welcome-panel">
            <a class="brand" href="<?php echo e(url('/')); ?>">
                <span class="brand-mark">D</span>
                <span><?php echo e(setting('brand_name', 'Digistore')); ?><small>OTP PLATFORM</small></span>
            </a>

            <div class="welcome-copy">
                <span class="welcome-label">WELCOME BACK</span>
                <h2>Semua kebutuhan OTP, dalam satu tempat.</h2>
                <p>Masuk ke akunmu untuk melanjutkan pengelolaan layanan dengan lebih praktis, cepat, dan nyaman.</p>
            </div>

            <div class="welcome-foot">© <?php echo e(date('Y')); ?> <?php echo e(setting('footer_name', 'Digistore OTP')); ?> · Secure account access</div>
        </section>

        <section class="form-panel">
            <div class="form-top">
                <button class="theme-toggle" type="button" id="themeToggle"
                        aria-label="Ganti tema tampilan" aria-pressed="false">
                    <span id="themeIcon">☾</span>
                    <span id="themeLabel">Mode gelap</span>
                </button>
            </div>

            <div class="form-heading">
                <p class="eyebrow">AKUN KAMU</p>
                <h1>Selamat datang</h1>
                <p>Masukkan detail akun untuk melanjutkan ke dashboard.</p>
            </div>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="field">
                    <label for="email">Alamat email</label>
                    <div class="input-wrap">
                        <input id="email" type="email" name="email"
                               value="<?php echo e(old('email')); ?>"
                               placeholder="nama@email.com"
                               autocomplete="username"
                               required autofocus>
                        <span class="field-icon" aria-hidden="true">✉</span>
                    </div>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="input-wrap">
                        <input id="password" type="password" name="password"
                               placeholder="Masukkan password"
                               autocomplete="current-password" required>
                        <button type="button" class="password-toggle"
                                id="passwordToggle" aria-label="Tampilkan password"
                                aria-pressed="false">Lihat</button>
                    </div>
                </div>

                <div class="remember-row">
                    <label>
                        <input type="checkbox" name="remember" value="1">
                        Ingat saya
                    </label>
                </div>

                <?php if($errors->any()): ?>
                    <div class="error-message" role="alert">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                <button type="submit" class="login-button">
                    Masuk ke akun <span aria-hidden="true">→</span>
                </button>
            </form>

            <p class="auth-foot">
                Belum punya akun?
                <a href="<?php echo e(route('register')); ?>">Daftar sekarang</a>
            </p>
        </section>
    </main>

    <script>
        (function () {
            const root = document.documentElement;
            const themeButton = document.getElementById('themeToggle');
            const themeIcon = document.getElementById('themeIcon');
            const themeLabel = document.getElementById('themeLabel');
            const password = document.getElementById('password');
            const passwordButton = document.getElementById('passwordToggle');

            function updateThemeButton() {
                const dark = root.dataset.theme === 'dark';
                themeIcon.textContent = dark ? '☀' : '☾';
                themeLabel.textContent = dark ? 'Mode terang' : 'Mode gelap';
                themeButton.setAttribute('aria-pressed', String(dark));
            }

            updateThemeButton();

            themeButton.addEventListener('click', function () {
                const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
                root.dataset.theme = next;
                try {
                    localStorage.setItem('depuka-login-theme', next);
                } catch (e) {}
                updateThemeButton();
            });

            passwordButton.addEventListener('click', function () {
                const show = password.type === 'password';
                password.type = show ? 'text' : 'password';
                passwordButton.textContent = show ? 'Sembunyi' : 'Lihat';
                passwordButton.setAttribute('aria-pressed', String(show));
                passwordButton.setAttribute(
                    'aria-label', show ? 'Sembunyikan password' : 'Tampilkan password'
                );
            });
        })();
    </script>
</body>
</html>
<?php /**PATH /root/digistore-project/digistore-otp/resources/views/auth/login.blade.php ENDPATH**/ ?>