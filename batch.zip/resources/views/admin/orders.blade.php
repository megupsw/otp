@extends('layouts.app')
@section('title', 'Riwayat Order')
@section('crumb', 'ADMIN / ORDERS')
@section('heading', 'Riwayat Order OTP')

@section('content')
<style>
.admin-order-tools{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}
.admin-order-tools input,.admin-order-tools select{min-width:0;padding:11px;border:1px solid var(--border,#334155);border-radius:9px;background:var(--panel,#111827);color:inherit}
.admin-order-tools input{flex:1}
.admin-order-tools button,.admin-order-cancel{border:0;border-radius:8px;padding:10px 13px;font-weight:700;cursor:pointer}
.admin-order-tools button{background:#2563eb;color:white}
.admin-order-cancel{background:#dc2626;color:white}
.admin-order-table{width:100%;border-collapse:collapse}
.admin-order-table th,.admin-order-table td{padding:12px 10px;text-align:left;border-bottom:1px solid var(--border,#293449);vertical-align:top;font-size:13px}
.admin-order-table th{color:var(--muted,#94a3b8)}
.admin-order-mobile{display:none}
.admin-order-card{padding:15px;border:1px solid var(--border,#293449);border-radius:12px;margin-bottom:12px;overflow-wrap:anywhere}
.admin-order-card p{margin:7px 0;font-size:13px}
.admin-order-card form{margin-top:12px}
.admin-order-cancel:disabled{opacity:.5;cursor:not-allowed}
.admin-order-pagination{margin-top:18px}
@media(max-width:800px){.admin-order-desktop{display:none}.admin-order-mobile{display:block}.admin-order-tools{display:grid;grid-template-columns:1fr}.admin-order-tools input,.admin-order-tools select,.admin-order-tools button{width:100%;box-sizing:border-box}.admin-order-table td{padding:8px}}
</style>

<div class="panel" style="padding:16px;margin-bottom:16px">
    <form method="GET" action="{{ route('admin.orders') }}" class="admin-order-tools">
        <input type="search" name="q" value="{{ $search }}" placeholder="Cari nama/email user, layanan, nomor, ID order">
        <select name="status">
            <option value="">Semua status</option>
            @foreach(['active','pending','completed','success','canceled','cancelled','failed','expired'] as $st)
                <option value="{{ $st }}" @selected(strtolower($statusFilter) === $st)>{{ ucfirst($st) }}</option>
            @endforeach
        </select>
        <button type="submit">Cari / Filter</button>
        <a href="{{ route('admin.orders') }}" style="align-self:center">Reset</a>
    </form>
    <div class="muted">Menampilkan {{ $orders->firstItem() ?? 0 }}–{{ $orders->lastItem() ?? 0 }} dari {{ $orders->total() }} order.</div>
</div>

<div class="panel table-wrap admin-order-desktop">
    <table class="admin-order-table">
        <thead><tr><th>User</th><th>Order / Layanan</th><th>Nomor</th><th>Harga</th><th>Status</th><th>Waktu</th><th>Tindakan</th></tr></thead>
        <tbody>
        @forelse($orders as $o)
            <tr>
                <td>{{ $o->user?->name ?? 'Pengguna dihapus' }}<br><span class="muted">{{ $o->user?->email ?? '-' }}</span></td>
                <td>#{{ $o->id }}<br>{{ $o->service_name ?: $o->service_id }}<br><span class="muted">Provider: {{ $o->provider_order_id ?: '-' }}</span></td>
                <td>{{ $o->phone_number ?: '-' }}</td>
                <td>{{ rupiah($o->selling_price) }}</td>
                <td><span class="status {{ strtolower($o->status) }}">{{ $o->status }}</span></td>
                <td>{{ $o->created_at?->format('d/m/Y H:i') }}</td>
                <td>
                    @if(in_array(strtolower((string)$o->status), ['active','pending'], true))
                        <form method="POST" action="{{ route('admin.orders.cancel', $o) }}" onsubmit="return confirm('Batalkan order #{{ $o->id }} untuk {{ $o->user?->email ?? 'pengguna' }}? Provider akan diperiksa terlebih dahulu.')">
                            @csrf
                            <button class="admin-order-cancel" type="submit">Batalkan</button>
                        </form>
                    @else
                        <span class="muted">Tidak tersedia</span>
                    @endif
                </td>
            </tr>
        @empty
            <tr><td colspan="7" class="empty">Belum ada order yang cocok.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>

<div class="admin-order-mobile">
    @forelse($orders as $o)
        <article class="panel admin-order-card">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
                <strong>Order #{{ $o->id }}</strong>
                <span class="status {{ strtolower($o->status) }}">{{ $o->status }}</span>
            </div>
            <p><b>User:</b> {{ $o->user?->name ?? 'Pengguna dihapus' }} ({{ $o->user?->email ?? '-' }})</p>
            <p><b>Layanan:</b> {{ $o->service_name ?: $o->service_id }}</p>
            <p><b>Nomor:</b> {{ $o->phone_number ?: '-' }}</p>
            <p><b>ID provider:</b> {{ $o->provider_order_id ?: '-' }}</p>
            <p><b>Harga:</b> {{ rupiah($o->selling_price) }}</p>
            <p><b>Waktu:</b> {{ $o->created_at?->format('d/m/Y H:i') }}</p>
            @if(in_array(strtolower((string)$o->status), ['active','pending'], true))
                <form method="POST" action="{{ route('admin.orders.cancel', $o) }}" onsubmit="return confirm('Batalkan order #{{ $o->id }}? Provider akan diperiksa terlebih dahulu.')">
                    @csrf
                    <button class="admin-order-cancel" type="submit" style="width:100%">Batalkan Order</button>
                </form>
            @endif
        </article>
    @empty
        <div class="panel" style="padding:16px">Belum ada order yang cocok.</div>
    @endforelse
</div>

<div class="admin-order-pagination">{{ $orders->links() }}</div>
@endsection
