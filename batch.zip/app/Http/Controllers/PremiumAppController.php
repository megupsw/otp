<?php

namespace App\Http\Controllers;

use App\Models\PremiumAppOrder;
use App\Models\User;
use App\Models\WalletTransaction;
use App\Services\SimuruClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use RuntimeException;

class PremiumAppController extends Controller
{
    public function index(Request $request, SimuruClient $api)
    {
        try {
            $categories = $api->premiumCatalog();
            $error = null;
        } catch (\Throwable $e) {
            Log::warning('Katalog Premium SIMURU gagal dimuat.', [
                'exception' => get_class($e),
            ]);
            $categories = [];
            $error = 'Katalog sedang tidak tersedia. Silakan coba kembali.';
        }

        $search = trim((string) $request->query('q', ''));

        if ($search !== '') {
            $categories = array_map(function ($category) use ($search) {
                $items = array_values(array_filter(
                    $category['items'] ?? [],
                    fn ($item) =>
                        stripos((string) ($item['app'] ?? ''), $search) !== false
                        || stripos((string) ($item['nama'] ?? ''), $search) !== false
                        || stripos((string) ($item['nama_penuh'] ?? ''), $search) !== false
                ));

                if (stripos((string) ($category['app'] ?? ''), $search) !== false) {
                    return $category;
                }

                $category['items'] = $items;
                return $category;
            }, $categories);

            $categories = array_values(array_filter(
                $categories,
                fn ($category) => !empty($category['items'])
            ));
        }

        return view('premium.index', compact('categories', 'error', 'search'));
    }

    public function purchase(Request $request, SimuruClient $api)
    {
        $data = $request->validate([
            'app_id' => ['required', 'integer', 'min:1'],
            'email' => ['nullable', 'email', 'max:190'],
        ]);

        try {
            // Harga, stok, dan kewajiban email selalu diperiksa ulang dari katalog.
            $categories = $api->premiumCatalog();
            $item = null;
            $categoryName = 'Aplikasi Premium';

            foreach ($categories as $category) {
                foreach (($category['items'] ?? []) as $candidate) {
                    if ((int) ($candidate['id'] ?? 0) === (int) $data['app_id']) {
                        $item = $candidate;
                        $categoryName = (string) ($category['app'] ?? $candidate['app'] ?? $categoryName);
                        break 2;
                    }
                }
            }

            if (!$item) {
                return back()->withErrors(['premium' => 'Paket tidak ditemukan. Muat ulang katalog.']);
            }

            $price = (int) ($item['harga'] ?? 0);
            if ($price < 1) {
                return back()->withErrors(['premium' => 'Harga paket tidak valid.']);
            }

            if (isset($item['stok']) && $item['stok'] !== null && (int) $item['stok'] < 1) {
                return back()->withErrors(['premium' => 'Stok paket sedang habis.']);
            }

            $needsEmail = (bool) ($item['butuh_email'] ?? false);
            $email = trim((string) ($data['email'] ?? ''));

            if ($needsEmail && $email === '') {
                return back()->withErrors(['email' => 'Paket ini memerlukan email tujuan.'])->withInput();
            }

            $requestId = (string) Str::uuid();

            // Cadangkan saldo dan simpan identitas request sebelum menghubungi provider.
            $order = DB::transaction(function () use ($request, $item, $categoryName, $price, $email, $requestId) {
                $user = User::whereKey($request->user()->id)->lockForUpdate()->firstOrFail();

                if ($user->role !== 'admin' && (int) $user->balance < $price) {
                    throw new RuntimeException('Saldo akun tidak mencukupi.');
                }

                $order = PremiumAppOrder::create([
                    'user_id' => $user->id,
                    'app_id' => (int) $item['id'],
                    'app_name' => $categoryName,
                    'package_name' => (string) ($item['nama'] ?? $item['app'] ?? 'Paket Premium'),
                    'request_id' => $requestId,
                    'email' => $email !== '' ? $email : null,
                    'price' => $price,
                    'status' => 'initiated',
                ]);

                if ($user->role !== 'admin') {
                    $user->decrement('balance', $price);

                    WalletTransaction::create([
                        'user_id' => $user->id,
                        'topup_id' => null,
                        'type' => 'premium_purchase',
                        'amount' => $price,
                        'description' => 'Pembelian ' . $order->app_name . ' - ' . $order->package_name,
                    ]);
                }

                return $order;
            });

            // Jangan kirim request kedua jika request pertama mengalami timeout.
            // Status initiated akan dipertahankan untuk pemeriksaan manual.
            try {
                $response = $api->createPremiumOrder(
                    $order->app_id,
                    $order->request_id,
                    $order->email
                );

                $providerData = $response['data'] ?? [];
                $providerId = $providerData['order_id'] ?? null;
                $status = strtolower((string) ($providerData['status'] ?? 'processing'));

                $order->provider_order_id = $providerId !== null ? (string) $providerId : null;
                $order->provider_payload = $providerData;
                $order->status = in_array($status, ['pending', 'processing', 'completed', 'error', 'canceled', 'refunded'], true)
                    ? $status
                    : 'processing';
                $order->account_details = isset($providerData['account']) && is_string($providerData['account'])
                    ? $providerData['account']
                    : null;

                if ($order->status === 'completed') {
                    $order->completed_at = now();
                }

                $order->save();
            } catch (\Throwable $e) {
                $order->update(['status' => 'unknown']);

                Log::error('Status pembelian premium belum dapat dipastikan.', [
                    'order_id' => $order->id,
                    'user_id' => $request->user()->id,
                    'exception' => get_class($e),
                ]);

                return redirect()->route('premium.history')
                    ->with('warning', 'Permintaan sudah dicatat, tetapi status provider belum dapat dipastikan. Jangan memesan ulang. Periksa riwayat atau hubungi admin.');
            }

            return redirect()->route('premium.history')
                ->with('success', 'Permintaan pembelian tercatat. Pantau statusnya di riwayat premium.');
        } catch (RuntimeException $e) {
            return back()->withErrors(['premium' => $e->getMessage()]);
        } catch (\Throwable $e) {
            Log::error('Pembelian premium gagal.', [
                'user_id' => $request->user()->id,
                'exception' => get_class($e),
            ]);

            return back()->withErrors(['premium' => 'Pembelian belum dapat diproses. Hubungi admin sebelum mencoba kembali.']);
        }
    }

    public function history(Request $request)
    {
        $orders = PremiumAppOrder::where('user_id', $request->user()->id)
            ->latest()
            ->paginate(15);

        return view('premium.history', compact('orders'));
    }
}
