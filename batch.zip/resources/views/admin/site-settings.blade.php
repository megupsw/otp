@extends('layouts.app')

@section('title', 'Identitas Website')

@section('content')
<div class="page-heading">
    <div>
        <h1>Identitas Website</h1>
        <p>Atur nama website dan teks branding Digistore OTP.</p>
    </div>
</div>

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

@if($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="card">
    <form method="POST" action="{{ route('admin.site-settings.save') }}" enctype="multipart/form-data">
        @csrf

        <div class="form-group">
            <label for="site_name">Nama website</label>
            <input id="site_name" name="site_name" type="text"
                   value="{{ old('site_name', $settings['site_name']) }}"
                   maxlength="100" required>
            <small>Dipakai sebagai identitas utama dan judul tab browser.</small>
        </div>

        <div class="form-group">
            <label for="brand_name">Nama brand pendek</label>
            <input id="brand_name" name="brand_name" type="text"
                   value="{{ old('brand_name', $settings['brand_name']) }}"
                   maxlength="60" required>
            <small>Dipakai pada header dan sidebar.</small>
        </div>

        <div class="form-group">
            <label for="login_title">Judul halaman login</label>
            <input id="login_title" name="login_title" type="text"
                   value="{{ old('login_title', $settings['login_title']) }}"
                   maxlength="100" required>
        </div>

        <div class="form-group">
            <label for="footer_name">Nama footer</label>
            <input id="footer_name" name="footer_name" type="text"
                   value="{{ old('footer_name', $settings['footer_name']) }}"
                   maxlength="120" required>
        </div>

        <div class="form-group">
            <label for="cs_whatsapp">Nomor WhatsApp CS</label>
            <input id="cs_whatsapp" name="cs_whatsapp" type="tel"
                   value="{{ old('cs_whatsapp', $settings['cs_whatsapp']) }}"
                   placeholder="6281234567890" pattern="628[0-9]{7,13}" maxlength="15">
            <small>Nomor khusus untuk tombol Chat WhatsApp pengguna. Format 628xxxxxxxxxx tanpa tanda +, spasi, atau strip. Kosongkan jika belum tersedia.</small>
        </div>

        <div class="form-group">
            <label for="favicon">Favicon website</label>

            @if(!empty($settings['favicon_path']))
                <div style="margin:10px 0;">
                    <img
                        src="{{ asset($settings['favicon_path']) }}?v={{ setting('favicon_updated_at', '1') }}"
                        alt="Favicon saat ini"
                        width="48"
                        height="48"
                        style="object-fit:contain;border:1px solid #ddd;border-radius:8px;padding:5px;"
                    >
                    <small style="display:block;">Favicon yang sedang digunakan.</small>
                </div>
            @endif

            <input
                id="favicon"
                name="favicon"
                type="file"
                accept=".png,.jpg,.jpeg,.ico,image/png,image/jpeg,image/x-icon"
            >
            <small>Format PNG, JPG, JPEG, atau ICO. Maksimal 2 MB. Kosongkan jika tidak ingin mengganti favicon.</small>
        </div>


        <hr style="margin:24px 0;border-color:var(--border,#e2e8f0)">
        <h3 style="margin-bottom:6px">Pengumuman halaman Order OTP</h3>
        <p class="muted" style="margin-bottom:18px">Informasi ini tampil di atas formulir pemesanan OTP.</p>

        <div class="form-group">
            <label for="otp_notice_title">Judul pengumuman</label>
            <input id="otp_notice_title" name="otp_notice_title" type="text"
                   value="{{ old('otp_notice_title', $settings['otp_notice_title']) }}"
                   maxlength="120" placeholder="Informasi Penting">
        </div>

        <div class="form-group">
            <label for="otp_notice_message">Isi pengumuman</label>
            <textarea id="otp_notice_message" name="otp_notice_message"
                      rows="4" maxlength="2000"
                      placeholder="Tulis informasi untuk pengguna...">{{ old('otp_notice_message', $settings['otp_notice_message']) }}</textarea>
            <small>Hingga 2.000 karakter. Baris baru akan dipertahankan.</small>
        </div>

        <div class="form-group">
            <label style="display:flex;align-items:center;gap:10px">
                <input type="checkbox" name="otp_notice_enabled" value="1"
                       style="width:auto"
                       @checked(old('otp_notice_enabled', $settings['otp_notice_enabled']) === '1')>
                Tampilkan pengumuman kepada pengguna
            </label>
        </div>


        <hr style="margin:28px 0;border-color:var(--border,#e2e8f0)">
        <h3 style="margin-bottom:6px">Panduan halaman Top Up</h3>
        <p class="muted" style="margin-bottom:18px">
            Ubah judul dan isi panduan yang tampil di panel kanan halaman Top Up.
        </p>

        <div class="form-group">
            <label for="topup_guide_title">Judul panduan</label>
            <input id="topup_guide_title" name="topup_guide_title" type="text"
                   maxlength="120"
                   value="{{ old('topup_guide_title', $settings['topup_guide_title']) }}">
        </div>

        <div class="form-group">
            <label style="display:flex;align-items:center;gap:10px">
                <input type="checkbox" name="topup_guide_enabled" value="1"
                       style="width:auto"
                       @checked((string) old('topup_guide_enabled', $settings['topup_guide_enabled']) === '1')>
                Tampilkan panduan Top Up kepada pengguna
            </label>
        </div>

        <div class="form-group">
            <label for="topup_guide_step1_title">Langkah 1 — judul</label>
            <input id="topup_guide_step1_title" name="topup_guide_step1_title"
                   type="text" maxlength="120"
                   value="{{ old('topup_guide_step1_title', $settings['topup_guide_step1_title']) }}">
        </div>
        <div class="form-group">
            <label for="topup_guide_step1_text">Langkah 1 — penjelasan</label>
            <textarea id="topup_guide_step1_text"
                      name="topup_guide_step1_text" rows="3" maxlength="1000">{{ old('topup_guide_step1_text', $settings['topup_guide_step1_text']) }}</textarea>
        </div>

        <div class="form-group">
            <label for="topup_guide_step2_title">Langkah 2 — judul</label>
            <input id="topup_guide_step2_title" name="topup_guide_step2_title"
                   type="text" maxlength="120"
                   value="{{ old('topup_guide_step2_title', $settings['topup_guide_step2_title']) }}">
        </div>
        <div class="form-group">
            <label for="topup_guide_step2_text">Langkah 2 — penjelasan</label>
            <textarea id="topup_guide_step2_text"
                      name="topup_guide_step2_text" rows="3" maxlength="1000">{{ old('topup_guide_step2_text', $settings['topup_guide_step2_text']) }}</textarea>
        </div>

        <div class="form-group">
            <label for="topup_guide_step3_title">Langkah 3 — judul</label>
            <input id="topup_guide_step3_title" name="topup_guide_step3_title"
                   type="text" maxlength="120"
                   value="{{ old('topup_guide_step3_title', $settings['topup_guide_step3_title']) }}">
        </div>
        <div class="form-group">
            <label for="topup_guide_step3_text">Langkah 3 — penjelasan</label>
            <textarea id="topup_guide_step3_text"
                      name="topup_guide_step3_text" rows="3" maxlength="1000">{{ old('topup_guide_step3_text', $settings['topup_guide_step3_text']) }}</textarea>
        </div>

        <div class="form-group">
            <label for="topup_guide_step4_title">Langkah 4 — judul</label>
            <input id="topup_guide_step4_title" name="topup_guide_step4_title"
                   type="text" maxlength="120"
                   value="{{ old('topup_guide_step4_title', $settings['topup_guide_step4_title']) }}">
        </div>
        <div class="form-group">
            <label for="topup_guide_step4_text">Langkah 4 — penjelasan</label>
            <textarea id="topup_guide_step4_text"
                      name="topup_guide_step4_text" rows="3" maxlength="1000">{{ old('topup_guide_step4_text', $settings['topup_guide_step4_text']) }}</textarea>
        </div>

        <div class="form-group">
            <label for="topup_guide_step5_title">Langkah 5 — judul</label>
            <input id="topup_guide_step5_title" name="topup_guide_step5_title"
                   type="text" maxlength="120"
                   value="{{ old('topup_guide_step5_title', $settings['topup_guide_step5_title']) }}">
        </div>
        <div class="form-group">
            <label for="topup_guide_step5_text">Langkah 5 — penjelasan</label>
            <textarea id="topup_guide_step5_text"
                      name="topup_guide_step5_text" rows="3" maxlength="1000">{{ old('topup_guide_step5_text', $settings['topup_guide_step5_text']) }}</textarea>
        </div>

        <hr style="margin:28px 0;border-color:var(--border,#e2e8f0)">
        <h3 style="margin-bottom:6px">Popup informasi setelah login</h3>
        <p class="muted" style="margin-bottom:18px">
            Informasi ini akan muncul sebagai popup untuk pengguna biasa setelah berhasil login.
            Admin dapat mengubah isi dan mengaktifkan atau menonaktifkannya di sini.
        </p>

        <div class="form-group">
            <label for="login_popup_title">Judul popup</label>
            <input id="login_popup_title" name="login_popup_title" type="text"
                   maxlength="120"
                   value="{{ old('login_popup_title', $settings['login_popup_title']) }}"
                   placeholder="Informasi Terbaru">
        </div>

        <div class="form-group">
            <label for="login_popup_message">Isi informasi</label>
            <textarea id="login_popup_message" name="login_popup_message"
                      rows="5" maxlength="3000"
                      placeholder="Tulis informasi yang ingin disampaikan kepada pengguna...">{{ old('login_popup_message', $settings['login_popup_message']) }}</textarea>
            <small>Maksimal 3.000 karakter. Baris baru akan dipertahankan.</small>
        </div>

        <div class="form-group">
            <label style="display:flex;align-items:center;gap:10px">
                <input type="checkbox" name="login_popup_enabled" value="1"
                       style="width:auto"
                       @checked((string) old('login_popup_enabled', $settings['login_popup_enabled']) === '1')>
                Aktifkan popup informasi untuk pengguna
            </label>
        </div>

        <button type="submit" class="btn btn-primary">
            <i class="bi bi-check2-circle"></i> Simpan identitas
        </button>
    </form>
</div>
@endsection
