<?php

namespace App\Providers;
use App\Services\SimuruClient;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\URL;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        URL::forceScheme('https');

        View::composer('layouts.app', function ($view) {
            $simuruBalance = null;

            if (Auth::check() && Auth::user()->role === 'admin') {
                try {
                    $simuruBalance = app(SimuruClient::class)->balance();
                } catch (\Throwable $e) {
                    report($e);
                }
            }

            $view->with('simuruBalance', $simuruBalance);
        });


        //
    }
}
