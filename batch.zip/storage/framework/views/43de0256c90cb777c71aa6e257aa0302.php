<?php $__env->startSection('title', 'Pengaturan Akun'); ?>
<?php $__env->startSection('crumb', 'AKUN'); ?>
<?php $__env->startSection('heading', 'Pengaturan Akun'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:800px;margin:0 auto;display:grid;gap:20px">

    <?php if(session('success')): ?>
        <div class="panel" style="border-color:#16a34a;color:#16a34a">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="panel" style="border-color:#dc2626;color:#dc2626">
            <strong>Periksa kembali:</strong>
            <ul style="margin:8px 0 0;padding-left:20px">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <h2 style="margin-top:0">Profil Saya</h2>
        <p class="muted">Ubah nama, email, dan nomor WhatsApp akun kamu.</p>

        <form method="POST" action="<?php echo e(route('account.profile')); ?>"
              style="display:grid;gap:14px">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label for="name">Nama</label>
                <input id="name" name="name" type="text"
                       value="<?php echo e(old('name', $user->name)); ?>"
                       maxlength="100" required
                       autocomplete="name"
                       style="width:100%;margin-top:6px">
            </div>

            <div>
                <label for="email">Email</label>
                <input id="email" name="email" type="email"
                       value="<?php echo e(old('email', $user->email)); ?>"
                       maxlength="255" required
                       autocomplete="email"
                       style="width:100%;margin-top:6px">
            </div>

            <div>
                <label for="whatsapp_phone">Nomor WhatsApp untuk notifikasi OTP</label>
                <input id="whatsapp_phone" name="whatsapp_phone" type="tel"
                       inputmode="numeric" pattern="628[0-9]{7,13}" maxlength="16"
                       placeholder="6281234567890"
                       value="<?php echo e(old('whatsapp_phone', $user->whatsapp_phone)); ?>"
                       style="width:100%;margin-top:6px">
                <small class="muted">Opsional. Gunakan format 628..., tanpa tanda + atau spasi. Kode OTP baru akan dikirim ke nomor ini.</small>
            </div>

            <div>
                <label for="profile_current_password">Password saat ini</label>
                <input id="profile_current_password"
                       name="current_password" type="password"
                       required autocomplete="current-password"
                       style="width:100%;margin-top:6px">
                <small class="muted">Diperlukan untuk mengonfirmasi perubahan profil.</small>
            </div>

            <button class="btn primary" type="submit">Simpan Profil</button>
        </form>
    </div>

    <div class="panel">
        <h2 style="margin-top:0">Ubah Password</h2>
        <p class="muted">Gunakan password minimal 8 karakter, berisi huruf dan angka.</p>

        <form method="POST" action="<?php echo e(route('account.password')); ?>"
              style="display:grid;gap:14px">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label for="password_current">Password saat ini</label>
                <input id="password_current" name="current_password"
                       type="password" required
                       autocomplete="current-password"
                       style="width:100%;margin-top:6px">
            </div>

            <div>
                <label for="password">Password baru</label>
                <input id="password" name="password"
                       type="password" required minlength="8"
                       autocomplete="new-password"
                       style="width:100%;margin-top:6px">
            </div>

            <div>
                <label for="password_confirmation">Konfirmasi password baru</label>
                <input id="password_confirmation" name="password_confirmation"
                       type="password" required minlength="8"
                       autocomplete="new-password"
                       style="width:100%;margin-top:6px">
            </div>

            <button class="btn primary" type="submit">Ubah Password</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/account/edit.blade.php ENDPATH**/ ?>