<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('topups', function (Blueprint $table) {
            $table->unsignedBigInteger('deposit_id')->nullable()->unique();
            $table->text('qr_string')->nullable();
            $table->timestamp('expired_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('topups', function (Blueprint $table) {
            $table->dropUnique(['deposit_id']);
            $table->dropColumn(['deposit_id', 'qr_string', 'expired_at']);
        });
    }
};
