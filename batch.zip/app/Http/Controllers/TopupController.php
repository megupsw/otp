<?php

namespace App\Http\Controllers;

use App\Models\Topup;
use App\Models\User;
use App\Models\WalletTransaction;
use App\Services\FonnteNotifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class TopupController extends Controller
{
    public function index(Request $request)
    {
        return view('topup.index', [
            'topups' => $request->user()->topups()->latest()->paginate(15),
        ]);
    }

    public function store(Request $request)
    {
        abort_unless(
            (string) setting('topup_qris_enabled', '1') === '1',
            403,
            'Pembayaran QRIS sedang dinonaktifkan.'
        );
        $data = $request->validate([
            'amount' => ['required', 'integer', 'min:2000', 'max:2000000'],
        ]);

        $topup = Topup::create([
            'user_id' => $request->user()->id,
            'order_id' => 'DSOTP-' . strtoupper(Str::random(16)),
            'amount' => (int) $data['amount'],
            'status' => 'pending',
            'payment_type' => 'manual_qris',
            'payload' => ['gateway' => 'manual_qris'],
        ]);

        app(FonnteNotifier::class)->sendAdmin(
            "🔔 TOP UP BARU - DEPUKA OTP\n".
            "Nama: " . $request->user()->name . "\n".
            "Nominal: Rp" . number_format((int) $topup->amount, 0, ',', '.') . "\n".
            "Order ID: " . $topup->order_id . "\n".
            "Status: Menunggu pembayaran dan bukti."
        );

        return redirect()->route('topup')
            ->with('success', 'Permintaan top up dibuat. Bayar melalui QRIS dan unggah bukti pembayaran.');
    }

    public function submitProof(Request $request, Topup $topup)
    {
        abort_unless(
            (string) setting('topup_qris_enabled', '1') === '1',
            403,
            'Pembayaran QRIS sedang dinonaktifkan.'
        );
        abort_unless((int) $topup->user_id === (int) $request->user()->id, 404);

        if ($topup->payment_type !== 'manual_qris' || $topup->status !== 'pending') {
            return back()->withErrors(['proof' => 'Transaksi ini tidak menerima bukti pembayaran baru.']);
        }

        $data = $request->validate([
            'payment_reference' => ['nullable', 'string', 'max:150'],
            'proof' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        $path = $request->file('proof')->store('topup-proofs', 'local');

        if ($topup->proof_path) {
            Storage::disk('local')->delete($topup->proof_path);
        }

        $topup->update([
            'payment_reference' => $data['payment_reference'] ?? null,
            'proof_path' => $path,
        ]);

        app(FonnteNotifier::class)->sendAdmin(
            "🧾 BUKTI TOP UP MASUK - DEPUKA OTP\n".
            "Nama: " . $request->user()->name . "\n".
            "Nominal: Rp" . number_format((int) $topup->amount, 0, ',', '.') . "\n".
            "Order ID: " . $topup->order_id . "\n".
            "Referensi: " . ($data['payment_reference'] ?? '-') . "\n".
            "Silakan periksa bukti di panel admin."
        );

        return back()->with('success', 'Bukti pembayaran terkirim. Saldo menunggu verifikasi admin.');
    }

    public function status(Request $request, Topup $topup)
    {
        abort_unless(
            (int) $topup->user_id === (int) $request->user()->id,
            404
        );

        // Ambil status Top Up terbaru dari database.
        $topup->refresh();
        $user = $request->user()->fresh();

        return response()->json([
            'status' => $topup->status,
            'message' => match ($topup->status) {
                'paid' => 'Pembayaran disetujui.',
                'rejected', 'failed' => 'Pembayaran ditolak atau gagal.',
                default => 'Menunggu pemeriksaan admin.',
            },
            'order_id' => $topup->order_id,
            'amount' => (int) $topup->amount,
            'payment_type' => $topup->payment_type,
            'balance' => (int) $user->balance,
        ])->header(
            'Cache-Control',
            'no-store, no-cache, must-revalidate, max-age=0'
        )->header('Pragma', 'no-cache');
    }
}
