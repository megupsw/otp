<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PremiumAppOrder extends Model
{
    protected $fillable = [
        'user_id',
        'app_id',
        'app_name',
        'package_name',
        'request_id',
        'provider_order_id',
        'email',
        'price',
        'status',
        'provider_payload',
        'account_details',
        'completed_at',
    ];

    protected function casts(): array
    {
        return [
            'app_id' => 'integer',
            'price' => 'integer',
            'provider_payload' => 'array',
            'completed_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
