<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#080f20">
    <title>404 - Halaman Tidak Ditemukan | <?php echo e(setting('site_name', 'DigiStore OTP')); ?></title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            overflow: hidden;
            font-family: Inter, system-ui, -apple-system, sans-serif;
            color: #fff;
            background:
                radial-gradient(ellipse at 50% 35%, rgba(37,99,235,.19), transparent 55%),
                linear-gradient(145deg, #080f20, #101b35 55%, #080f20);
        }

        .error-card {
            position: relative;
            width: 100%;
            max-width: 540px;
            padding: 48px 35px;
            text-align: center;
            border: 1px solid rgba(148,163,184,.16);
            border-radius: 25px;
            background: rgba(17,27,48,.88);
            box-shadow: 0 25px 80px rgba(0,0,0,.35);
            backdrop-filter: blur(18px);
            animation: appear .6s ease both;
        }

        .error-icon {
            width: 76px;
            height: 76px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            border: 1px solid rgba(96,165,250,.25);
            border-radius: 23px;
            color: #60a5fa;
            background: rgba(37,99,235,.14);
            font-size: 35px;
        }

        .error-number {
            font-size: clamp(100px, 22vw, 155px);
            line-height: 1;
            font-weight: 900;
            letter-spacing: -9px;
            background: linear-gradient(135deg, #93c5fd, #3b82f6 55%, #6366f1);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            filter: drop-shadow(0 8px 25px rgba(59,130,246,.2));
        }

        h1 {
            margin-top: 22px;
            font-size: clamp(21px, 5vw, 27px);
            font-weight: 750;
            letter-spacing: -.6px;
        }

        .description {
            max-width: 390px;
            margin: 13px auto 28px;
            color: #94a3b8;
            font-size: 14px;
            line-height: 1.8;
        }

        .actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        .btn {
            min-height: 47px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 12px 21px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            transition: .2s ease;
        }

        .btn-primary {
            color: #fff;
            border: 1px solid #60a5fa;
            background: linear-gradient(135deg, #2563eb, #3b82f6);
            box-shadow: 0 7px 20px rgba(37,99,235,.25);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 27px rgba(37,99,235,.4);
        }

        .btn-secondary {
            color: #cbd5e1;
            border: 1px solid rgba(148,163,184,.23);
            background: rgba(255,255,255,.04);
        }

        .btn-secondary:hover {
            background: rgba(255,255,255,.1);
        }

        .footer {
            margin-top: 38px;
            padding-top: 20px;
            border-top: 1px solid rgba(148,163,184,.12);
            color: #64748b;
            font-size: 11px;
            letter-spacing: 2px;
            font-weight: 700;
        }

        .footer span {
            color: #60a5fa;
        }

        @keyframes appear {
            from { opacity: 0; transform: translateY(20px) scale(.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @media(max-width: 480px) {
            .error-card { padding: 38px 20px; }
            .actions { flex-direction: column; }
            .btn { width: 100%; }
        }
    </style>
</head>
<body>
    <main class="error-card">
        <div class="error-icon">⌕</div>

        <div class="error-number">404</div>

        <h1>Oops! Halaman Tidak Ditemukan</h1>

        <p class="description">
            Sepertinya halaman yang kamu cari tidak tersedia.
            Mungkin alamatnya salah atau halaman tersebut sudah dipindahkan.
            Jangan khawatir, kamu bisa kembali ke halaman utama.
        </p>

        <div class="actions">
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
                        ← Kembali ke Dashboard
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">
                        ← Kembali ke Dashboard
                    </a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">
                    ← Kembali ke Beranda
                </a>
            <?php endif; ?>

            <button type="button" onclick="history.back()" class="btn btn-secondary">
                Kembali Sebelumnya
            </button>
        </div>

        <div class="footer">
            <span><?php echo e(setting('brand_name', 'DigiStore')); ?></span> OTP
            <br><br>
            YOUR DIGITAL SOLUTION
        </div>
    </main>
</body>
</html>
<?php /**PATH /root/digistore-project/digistore-otp/resources/views/errors/404.blade.php ENDPATH**/ ?>