<?php $__env->startSection('content'); ?>
<div class="premium-page">
    <div class="premium-heading">
        <div>
            <h1>Riwayat App Premium</h1>
            <p>Pantau status pesanan aplikasi premium kamu.</p>
        </div>
        <a href="<?php echo e(route('premium.index')); ?>">Kembali ke katalog</a>
    </div>

    <?php if(session('success')): ?>
        <div class="premium-notice"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('warning')): ?>
        <div class="premium-notice"><?php echo e(session('warning')); ?></div>
    <?php endif; ?>

    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="premium-card" style="margin-bottom:12px">
            <h3><?php echo e($order->app_name); ?> — <?php echo e($order->package_name); ?></h3>
            <p>Order: #<?php echo e($order->id); ?></p>
            <p>Harga: Rp <?php echo e(number_format($order->price, 0, ',', '.')); ?></p>
            <p>Status: <strong><?php echo e(strtoupper($order->status)); ?></strong></p>
            <?php if($order->email): ?>
                <p>Email tujuan: <?php echo e($order->email); ?></p>
            <?php endif; ?>
            <?php if($order->status === 'completed' && $order->account_details): ?>
                <p>Detail akun:</p>
                <pre style="white-space:pre-wrap;overflow-wrap:anywhere"><?php echo e($order->account_details); ?></pre>
            <?php endif; ?>
            <p class="premium-meta"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></p>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="premium-empty">Belum ada pesanan App Premium.</div>
    <?php endif; ?>

    <?php echo e($orders->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/digistore-project/digistore-otp/resources/views/premium/history.blade.php ENDPATH**/ ?>