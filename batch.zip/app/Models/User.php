<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;
class User extends Authenticatable {
    use HasFactory, Notifiable;
    protected $fillable = ['name','email','password','role','is_blocked','balance','theme','whatsapp_phone'];
    protected $hidden = ['password','remember_token'];
    protected function casts(): array { return ['email_verified_at'=>'datetime','password'=>'hashed','is_blocked'=>'boolean','balance'=>'integer']; }
    public function topups(): HasMany { return $this->hasMany(Topup::class); }
    public function orders(): HasMany { return $this->hasMany(OtpOrder::class); }
    public function supportTickets(): HasMany { return $this->hasMany(\App\Models\SupportTicket::class); }
}
