@extends('layouts.app')
@section('title','Top Up')
@section('crumb','WALLET')
@section('heading','Top Up Saldo')

@section('content')

@php
    $noticeOrderId = request()->query('order');
    $noticeTopup = $noticeOrderId
        ? \App\Models\Topup::where('order_id', $noticeOrderId)
            ->where('user_id', auth()->id())
            ->first()
        : null;
@endphp

@if($noticeTopup)
    <div id="topup-order-notice"
         data-topup-id="{{ $noticeTopup->id }}"
         role="status" aria-live="polite"
         style="margin-bottom:18px;padding:18px;border-radius:18px;
         border:1px solid rgba(16,185,129,.4);
         background:linear-gradient(135deg,rgba(16,185,129,.13),rgba(59,130,246,.07));
         box-shadow:0 10px 30px rgba(0,0,0,.08)">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
            <div style="width:42px;height:42px;display:flex;align-items:center;
                        justify-content:center;border-radius:14px;
                        background:rgba(16,185,129,.16);color:#10b981;font-size:22px">✓</div>
            <div>
                <strong style="display:block;font-size:16px">Pesanan top up berhasil dibuat</strong>
                <span class="muted" style="font-size:12px">Selesaikan transfer sesuai nominal berikut.</span>
            </div>
        </div>
        <div style="padding:15px;border-radius:13px;background:rgba(127,127,127,.08);
                    border:1px dashed rgba(127,127,127,.3);margin-bottom:12px">
            <span class="muted" style="display:block;font-size:12px">Nominal transfer</span>
            <strong style="display:block;font-size:26px;line-height:1.5;color:#10b981">
                {{ rupiah($noticeTopup->payment_amount ?? $noticeTopup->amount) }}
            </strong>
            <span style="font-size:12px" class="muted">
                Metode: {{ $noticeTopup->payment_type === 'payhook_shopeepay' ? 'ShopeePay' : 'GoPay' }}
            </span>
        </div>
        <div style="font-size:13px;line-height:1.8">
            <div>ID pesanan: <strong>{{ $noticeTopup->order_id }}</strong></div>
            <div>Batas pembayaran:
                <strong>{{ $noticeTopup->expired_at?->format('d/m/Y H:i') ?? '-' }}</strong>
            </div>
            <div>Status:
                <span class="status {{ $noticeTopup->status }}">{{ $noticeTopup->status }}</span>
            </div>
        </div>
    </div>
@endif

<div class="panel topup-panel" style="margin:0 0 20px">
    <h2>Isi Saldo</h2>
    <p class="muted">Pilih metode pembayaran terlebih dahulu, lalu ikuti petunjuknya.</p>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:18px 0">
        @if((string) setting('topup_qris_enabled', '1') === '1')
        <button type="button" class="btn secondary topup-method-choice" data-method="qris">
            ◈ QRIS Manual
            <small style="display:block">Bayar dan unggah bukti</small>
        </button>
        @else
        <div class="panel" style="padding:14px">
            <strong>QRIS Manual</strong>
            <p class="muted">QRIS sedang dalam perbaikan.</p>
        </div>
        @endif

        @if((string) setting('topup_gopay_enabled', '1') === '1' || (string) setting('topup_shopeepay_enabled', '1') === '1')
        <button type="button" class="btn secondary topup-method-choice" data-method="transfer">
            ↗ Transfer Otomatis
            <small style="display:block">GoPay / ShopeePay</small>
        </button>
        @endif

        @if((string) setting('topup_gopay_enabled', '1') !== '1')
        <div class="panel" style="padding:14px">
            <strong>GoPay</strong>
            <p class="muted">GoPay sedang dalam perbaikan.</p>
        </div>
        @endif

        @if((string) setting('topup_shopeepay_enabled', '1') !== '1')
        <div class="panel" style="padding:14px">
            <strong>ShopeePay</strong>
            <p class="muted">ShopeePay sedang dalam perbaikan.</p>
        </div>
        @endif
    </div>

    @if((string) setting('topup_qris_enabled', '1') !== '1' &&
        (string) setting('topup_gopay_enabled', '1') !== '1' &&
        (string) setting('topup_shopeepay_enabled', '1') !== '1')
        <div class="alert error">Semua metode Top Up sedang dinonaktifkan. Silakan coba lagi nanti.</div>
    @endif

    <div class="panel" style="padding:14px 16px;margin:0 0 16px;border:1px solid rgba(96,165,250,.35);background:rgba(37,99,235,.10)">
        <strong style="display:block;margin-bottom:4px">Informasi Top Up</strong>
        <p class="muted" style="margin:0">Minimal top up <strong>Rp2.000</strong> per transaksi.</p>
    </div>

    <div id="topup-method-qris" style="display:none">
        <hr>
        <h3>QRIS Manual</h3>
        <p class="muted">Bayar menggunakan QRIS resmi. Saldo masuk setelah bukti pembayaran diverifikasi admin.</p>

        @if(file_exists(public_path('images/qris.png')))
            <div style="text-align:center;margin:16px 0">
                <img src="{{ asset('images/qris.png') }}" alt="QRIS pembayaran DigiStore"
                     style="width:100%;max-width:320px;height:auto;border-radius:12px">
            </div>
        @else
            <div class="alert error">QRIS belum dipasang. Admin perlu menempatkan gambar resmi di public/images/qris.png.</div>
        @endif

        <div style="padding:16px;border-radius:14px;background:rgba(37,99,235,.1);margin:16px 0">
            <b>Minimal Rp2.000</b>
            <div class="muted">Maksimal Rp2.000.000 per transaksi</div>
        </div>

        <form method="POST" action="{{ route('topup.store') }}">
            @csrf
            <label>Nominal saldo (Rp)</label>
            <input type="number" name="amount" id="amount-manual" min="2000" max="2000000"
                   step="1000" value="{{ old('amount',25000) }}" required>
            <div class="amount-presets">
                @foreach([10000,25000,50000,100000] as $v)
                    <button type="button" class="btn secondary"
                        onclick="document.getElementById('amount-manual').value={{ $v }}">
                        {{ rupiah($v) }}
                    </button>
                @endforeach
            </div>
            <button class="btn primary full" type="submit">Buat Top Up QRIS</button>
        </form>
        <p class="secure-note">Setelah membayar, unggah bukti pada bagian Riwayat Top Up.</p>
    </div>

    <div id="topup-method-transfer" style="display:none">
        <hr>
        <h3>Transfer Otomatis</h3>
        <p class="muted">Pilih penyedia transfer. Ikuti nominal unik dan batas waktu yang diberikan sistem.</p>

        @if((string) setting('topup_gopay_enabled', '1') === '1')
        <div class="panel" style="margin:14px 0;padding:16px">
            <h3>GoPay</h3>
            <p class="muted">Transfer sesuai nominal unik. Pesanan berlaku selama 30 menit.</p>
            <div style="margin:12px 0">
                <b>Tujuan transfer</b>
                <div>Nomor: {{ config('services.gopay.destination_phone') ?: 'Belum dikonfigurasi admin' }}</div>
                <div>Nama penerima: {{ config('services.gopay.account_name') ?: 'Belum dikonfigurasi admin' }}</div>
            </div>
            <form method="POST" action="{{ route('topup.payhook-gopay') }}">
                @csrf
                <label>Nominal saldo yang ingin diterima (Rp)</label>
                <input type="number" name="amount" id="amount-payhook" min="2000" max="2000000"
                       step="1000" value="{{ old('amount',25000) }}" required>
                <div class="amount-presets">
                    @foreach([10000,25000,50000,100000] as $v)
                        <button type="button" class="btn secondary"
                            onclick="document.getElementById('amount-payhook').value={{ $v }}">
                            {{ rupiah($v) }}
                        </button>
                    @endforeach
                </div>
                <button class="btn primary full" type="submit">Buat Pesanan GoPay</button>
            </form>
        </div>
        @endif

        @if((string) setting('topup_shopeepay_enabled', '1') === '1')
        <div class="panel" style="margin:14px 0;padding:16px">
            <h3>ShopeePay</h3>
            <p class="muted">Transfer sesuai nominal unik. Pesanan berlaku selama 30 menit.</p>
            <div style="margin:12px 0">
                <b>Tujuan transfer</b>
                <div>Nomor: {{ config('services.shopeepay.destination_phone') ?: 'Belum dikonfigurasi admin' }}</div>
                <div>Nama penerima: {{ config('services.shopeepay.account_name') ?: 'Belum dikonfigurasi admin' }}</div>
            </div>
            <form method="POST" action="{{ route('topup.payhook-shopeepay') }}">
                @csrf
                <label>Nominal saldo yang ingin diterima (Rp)</label>
                <input type="number" name="amount" id="amount-shopeepay" min="2000" max="2000000"
                       step="1000" value="{{ old('amount',25000) }}" required>
                <div class="amount-presets">
                    @foreach([10000,25000,50000,100000] as $v)
                        <button type="button" class="btn secondary"
                            onclick="document.getElementById('amount-shopeepay').value={{ $v }}">
                            {{ rupiah($v) }}
                        </button>
                    @endforeach
                </div>
                <button class="btn primary full" type="submit">Buat Pesanan ShopeePay</button>
            </form>
        </div>
        @endif

        <p class="secure-note">Jangan mengirim PIN, kata sandi, atau kode OTP kepada siapa pun.</p>
    </div>
</div>

<script>
(() => {
    // Pasang satu kali, tetap aktif setelah navigasi AJAX.
    if (window.__digistoreTopupMethodReady) return;
    window.__digistoreTopupMethodReady = true;

    document.addEventListener('click', function (event) {
        const button = event.target.closest('.topup-method-choice');
        if (!button) return;

        const panels = {
            qris: document.getElementById('topup-method-qris'),
            transfer: document.getElementById('topup-method-transfer')
        };

        Object.values(panels).forEach(function (panel) {
            if (panel) panel.style.display = 'none';
        });

        const selected = panels[button.dataset.method];

        if (selected) {
            selected.style.display = 'block';
            selected.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
})();
</script>


@if((string) setting('topup_guide_enabled', '1') === '1')
    <div class="panel how-panel">
        <h3>{{ setting('topup_guide_title', 'Bagaimana cara top up?') }}</h3>
        @for($i = 1; $i <= 5; $i++)
            @php
                $guideTitle = setting('topup_guide_step' . $i . '_title', '');
                $guideText = setting('topup_guide_step' . $i . '_text', '');
            @endphp
            @if(trim((string) $guideTitle) !== '' || trim((string) $guideText) !== '')
                <div class="step">
                    <span>{{ $i }}</span>
                    <div>
                        <b>{{ $guideTitle }}</b>
                        <small style="white-space:pre-line">{{ $guideText }}</small>
                    </div>
                </div>
            @endif
        @endfor
    </div>
    @endif
</div>



<div class="section-head" style="margin:24px 0 16px !important;padding:0;position:static;top:auto;display:flex;justify-content:center;text-align:center">
    <div style="width:100%;text-align:center">
        <h2 style="margin:0;text-align:center">Riwayat Top Up</h2>
        <p class="muted" style="margin:6px 0 0;text-align:center">Status permintaan dan pembayaran kamu</p>
    </div>
</div>

<div class="panel table-wrap topup-history-wrap" style="margin-top:0 !important">
    <table class="topup-history-table">
        <thead>
            <tr>
                <th>ID Pembayaran</th>
                <th>Tanggal</th>
                <th>Nominal</th>
                <th>Status</th>
                <th>Bukti Pembayaran</th>
            </tr>
        </thead>
        <tbody>
        @forelse($topups as $t)
            <tr data-topup-id="{{ $t->id }}">
                <td data-label="ID Pembayaran" class="topup-order-id">
                    <b>{{ $t->order_id }}</b>
                </td>
                <td data-label="Tanggal" class="topup-date">
                    {{ $t->created_at?->format('d/m/Y H:i') }}
                </td>
                <td data-label="Nominal" class="topup-amount">
                    <b>{{ rupiah($t->amount) }}</b>
                    @if(in_array($t->payment_type, ['payhook_gopay', 'payhook_dana', 'payhook_shopeepay'], true) && $t->status === 'pending')
                        <small style="display:block;margin-top:6px;color:var(--blue)">
                            Transfer tepat: {{ rupiah($t->payment_amount ?? $t->amount) }}
                        </small>
                        @if($t->expired_at)
                            <small class="muted" style="display:block">
                                Kedaluwarsa: {{ $t->expired_at->format('d/m/Y H:i') }}
                            </small>
                        @endif
                    @endif
                </td>
                <td data-label="Status" class="topup-status">
                    <span class="status {{ $t->status }}">{{ $t->status }}</span>
                    @if($t->rejection_reason)
                        <small class="topup-rejection">Alasan: {{ $t->rejection_reason }}</small>
                    @endif
                </td>
                <td data-label="Bukti Pembayaran" class="topup-proof">
                    @if($t->payment_type === 'manual_qris' && $t->status === 'pending')
                        @if($t->proof_path)
                            <span class="muted">Bukti terkirim — menunggu admin</span>
                        @else
                            <form method="POST" action="{{ route('topup.proof', $t) }}" enctype="multipart/form-data">
                                @csrf
                                <label>Foto bukti pembayaran (maks. 4 MB)</label>
                                <input type="file" name="proof" accept="image/jpeg,image/png,image/webp" required>
                                <button class="btn primary" type="submit" style="margin-top:8px">Kirim Bukti</button>
                            </form>
                        @endif
                    @elseif($t->payment_type === 'manual_qris')
                        <span class="muted">{{ $t->status === 'paid' ? 'Pembayaran disetujui' : 'Tidak ada tindakan' }}</span>
                    @elseif(in_array($t->payment_type, ['payhook_gopay', 'payhook_dana', 'payhook_shopeepay'], true))
                        @if($t->status === 'paid')
                            <span class="muted">Pembayaran otomatis terkonfirmasi</span>
                        @elseif($t->status === 'pending')
                            <span class="muted">Menunggu pembayaran {{ $t->payment_type === 'payhook_shopeepay' ? 'ShopeePay' : 'DANA' }}</span>
                        @else
                            <span class="muted">Status: {{ $t->status }}</span>
                        @endif
                    @else
                        <span class="muted">Transaksi lama</span>
                    @endif
                </td>
            </tr>
        @empty
            <tr><td colspan="5" class="empty">Belum ada transaksi top up.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>


<div id="topup-realtime-toast" role="status" aria-live="polite"
     style="display:none;position:fixed;top:18px;right:18px;left:auto;
     z-index:999999;width:calc(100% - 36px);max-width:360px;box-sizing:border-box;
     background:linear-gradient(145deg,#102b21,#0b1d18);color:#effff6;
     border:1px solid rgba(52,211,153,.55);padding:18px;border-radius:18px;
     box-shadow:0 16px 45px rgba(0,0,0,.38);">
    <div style="display:flex;align-items:flex-start;gap:12px">
        <div style="width:42px;height:42px;flex:0 0 42px;border-radius:14px;
                    display:flex;align-items:center;justify-content:center;
                    background:rgba(52,211,153,.15);color:#34d399;font-size:23px;
                    font-weight:800">✓</div>
        <div style="flex:1;min-width:0">
            <strong id="topup-realtime-title"
                    style="display:block;font-size:15px;line-height:1.4;margin-bottom:5px">
                Top up berhasil!
            </strong>
            <span id="topup-realtime-message"
                  style="display:block;color:#c9e8d9;font-size:13px;line-height:1.6">
            </span>
        </div>
        <button type="button" id="topup-realtime-close" aria-label="Tutup notifikasi"
                style="border:0;background:transparent;color:#b6d8c7;font-size:22px;
                       line-height:1;cursor:pointer;padding:0 2px">×</button>
    </div>
    <div style="height:3px;background:rgba(255,255,255,.09);border-radius:5px;
                margin-top:16px;overflow:hidden">
        <div id="topup-realtime-progress"
             style="height:100%;width:100%;background:#34d399;border-radius:5px"></div>
    </div>
</div>


<style id="topup-toast-animation">
#topup-realtime-toast {
    animation: topupToastIn .35s cubic-bezier(.2,.8,.2,1) both;
}
@keyframes topupToastIn {
    from { opacity:0; transform:translateY(-12px); }
    to   { opacity:1; transform:translateY(0); }
}
@media (max-width:480px) {
    #topup-realtime-toast {
        top:12px !important;
        right:12px !important;
        width:calc(100% - 24px) !important;
        max-width:none !important;
    }
}
</style>
<script>
(() => {
    console.log('[TopUp realtime] Script aktif');

    const rows = Array.from(document.querySelectorAll(
        '.topup-history-table tbody tr[data-topup-id]'
    ));
    console.log('[TopUp realtime] Jumlah baris:', rows.length);

    const notice = document.getElementById('topup-order-notice');
    const noticeId = notice?.dataset.topupId;

    if (!rows.length && !noticeId) return;

    const key = 'digistore_topup_paid_seen';
    let seen = new Set();
    try {
        seen = new Set(JSON.parse(sessionStorage.getItem(key) || '[]'));
    } catch (e) {
        console.warn('[TopUp realtime] sessionStorage tidak tersedia', e);
    }

    const toast = document.getElementById('topup-realtime-toast');
    const message = document.getElementById('topup-realtime-message');
    const close = document.getElementById('topup-realtime-close');

    const popupReady = !!(toast && message && close);

    if (!popupReady) {
        console.warn('[TopUp realtime] Popup tidak lengkap; polling tetap berjalan');
    } else {
        close.addEventListener('click', () => {
            toast.style.display = 'none';
        });
    }

    const rupiah = n => new Intl.NumberFormat('id-ID', {
        style: 'currency', currency: 'IDR', maximumFractionDigits: 0
    }).format(n);

    function popup(amount) {
        if (!popupReady) return;

        const title = document.getElementById('topup-realtime-title');
        if (title) title.textContent = 'Top up berhasil!';
        message.textContent = 'Saldo bertambah ' + rupiah(amount) + '.';
        toast.style.display = 'block';

        // Reset timer dan animasi setiap popup muncul.
        if (window.topupToastTimer) {
            window.clearTimeout(window.topupToastTimer);
        }

        const progress = document.getElementById('topup-realtime-progress');
        if (progress) {
            progress.style.transition = 'none';
            progress.style.width = '100%';

            requestAnimationFrame(() => {
                progress.style.transition = 'width 5s linear';
                progress.style.width = '0%';
            });
        }

        window.topupToastTimer = window.setTimeout(() => {
            toast.style.display = 'none';
        }, 5000);
    }

    async function check(row) {
        const id = row.dataset.topupId;
        const statusCell = row.querySelector('.topup-status');
        if (!id || !statusCell) return;

        const endpoint = window.location.origin + '/topup/' +
            encodeURIComponent(id) + '/status?_=' + Date.now();

        try {
            const response = await fetch(endpoint, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin',
                cache: 'no-store'
            });

            if (!response.ok) {
                console.warn('[TopUp realtime] HTTP', response.status, endpoint);
                return;
            }

            const data = await response.json();
            console.log('[TopUp realtime] Status pesanan', id, data.status);

            const balanceElement = document.getElementById('realtime-wallet-balance');
            const isAdminWallet = balanceElement?.dataset.walletSource === 'simuru';

            if (!isAdminWallet && balanceElement && Number.isFinite(Number(data.balance))) {
                const nextBalance = Number(data.balance);
                const previousBalance = Number(balanceElement.dataset.balance);
                balanceElement.textContent = rupiah(nextBalance);
                balanceElement.dataset.balance = String(nextBalance);

                if (nextBalance > previousBalance && data.status === 'paid') {
                    console.log('[TopUp realtime] Saldo terbaru diterima dari server');
                }
            }

            const badge = statusCell.querySelector('.status');
            const oldStatus = (badge?.textContent || '').trim().toLowerCase();

            if (badge && data.status && oldStatus !== data.status) {
                badge.textContent = data.status;
                badge.className = 'status ' + data.status;
            }

            const proofCell = row.querySelector('.topup-proof');

            if (data.status === 'paid') {
                if (proofCell) {
                    proofCell.textContent = 'Pembayaran otomatis terkonfirmasi';
                }

                if (oldStatus !== 'paid' && !seen.has(id)) {
                    seen.add(id);
                    try {
                        sessionStorage.setItem(key, JSON.stringify(Array.from(seen)));
                    } catch (_) {}
                    popup(Number(data.amount || 0));
                }
            } else if (data.status === 'rejected' || data.status === 'failed') {
                if (proofCell) proofCell.textContent = data.message || 'Pembayaran gagal';
            }
        } catch (error) {
            console.error('[TopUp realtime] Gagal memeriksa status:', error);
        }
    }

    async function checkPaymentNotice() {
        if (!notice || !noticeId) return;

        try {
            const response = await fetch(
                window.location.origin + '/topup/' +
                encodeURIComponent(noticeId) +
                '/status?_=' + Date.now(),
                {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    credentials: 'same-origin',
                    cache: 'no-store'
                }
            );

            if (!response.ok) {
                console.warn('[TopUp realtime] Kartu pembayaran HTTP',
                    response.status);
                return;
            }

            const data = await response.json();
            const badge = notice.querySelector('.status');

            if (badge && data.status) {
                badge.textContent = data.status;
                badge.className = 'status ' + data.status;
            }

            if (data.status === 'paid') {
                const heading = notice.querySelector('strong');
                const description = notice.querySelector('.muted');

                if (heading) heading.textContent = 'Top up berhasil!';
                if (description) {
                    description.textContent =
                        'Pembayaran berhasil dikonfirmasi. Saldo sudah masuk.';
                }

                console.log('[TopUp realtime] Status kartu pembayaran paid');
            } else if (data.status === 'expired' ||
                       data.status === 'rejected' ||
                       data.status === 'failed') {
                const description = notice.querySelector('.muted');
                if (description) description.textContent = data.message ||
                    'Pembayaran tidak berhasil.';
            }
        } catch (error) {
            console.error('[TopUp realtime] Gagal memperbarui kartu:',
                error);
        }
    }

    const run = () => {
        rows.forEach(row => check(row));
        checkPaymentNotice();
    };

    run();
    window.setInterval(run, 3000);
})();
</script>

<style>
/* Riwayat top up: desktop tetap tabel, mobile menjadi kartu */
.topup-history-wrap {
    width: 100%;
    min-width: 0;
    overflow: hidden;
}
.topup-history-table {
    width: 100%;
    table-layout: fixed;
    border-collapse: collapse;
}
.topup-history-table th,
.topup-history-table td {
    overflow-wrap: anywhere;
    word-break: normal;
    vertical-align: top;
}
.topup-history-table .topup-order-id {
    overflow-wrap: anywhere;
    word-break: break-word;
}
.topup-history-table .topup-proof {
    min-width: 0;
}
.topup-history-table .topup-proof form {
    width: 100%;
    min-width: 0;
}
.topup-history-table .topup-proof input {
    box-sizing: border-box;
    width: 100%;
    max-width: 100%;
    min-width: 0;
}
.topup-history-table .topup-rejection {
    display: block;
    margin-top: 6px;
    overflow-wrap: anywhere;
}
@media (max-width: 640px) {
    .topup-history-wrap {
        padding: 10px;
        border-radius: 16px;
    }
    .topup-history-table,
    .topup-history-table tbody {
        display: block;
        width: 100%;
    }
    .topup-history-table thead {
        display: none;
    }
    .topup-history-table tbody tr {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
        gap: 12px 10px;
        width: 100%;
        box-sizing: border-box;
        padding: 14px 12px;
        margin-bottom: 12px;
        border: 1px solid var(--border, #263449);
        border-radius: 12px;
        background: var(--panel, transparent);
    }
    .topup-history-table tbody tr:last-child {
        margin-bottom: 0;
    }
    .topup-history-table tbody td {
        display: block;
        width: auto;
        min-width: 0;
        padding: 0;
        border: 0;
        text-align: left;
        font-size: 13px;
        overflow-wrap: anywhere;
    }
    .topup-history-table tbody td::before {
        content: attr(data-label);
        display: block;
        margin-bottom: 5px;
        color: var(--muted, #94a3b8);
        font-size: 10px;
        line-height: 1.4;
        font-weight: 700;
        letter-spacing: .04em;
        text-transform: uppercase;
    }
    .topup-history-table tbody td.topup-order-id,
    .topup-history-table tbody td.topup-proof {
        grid-column: 1 / -1;
    }
    .topup-history-table tbody td.topup-order-id b {
        display: block;
        font-size: 13px;
        line-height: 1.5;
        overflow-wrap: anywhere;
        word-break: break-word;
    }
    .topup-history-table tbody td.topup-proof form {
        display: grid;
        gap: 8px;
    }
    .topup-history-table tbody td.topup-proof label {
        margin-top: 4px;
    }
    .topup-history-table tbody td.topup-proof input[type="file"] {
        font-size: 12px;
    }
    .topup-history-table tbody td.topup-proof button {
        width: 100%;
    }
    .topup-history-table tbody td.empty {
        grid-column: 1 / -1;
        text-align: center;
    }
}
</style>
{{ $topups->links() }}

<style>
/* TOPUP-RESPONSIVE-CARDS-V1 */
.topup-history-wrap {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    box-sizing: border-box;
}

.topup-history-table {
    width: 100%;
    table-layout: fixed;
}

.topup-history-table th,
.topup-history-table td {
    overflow-wrap: anywhere;
    word-break: normal;
}

.topup-history-table .topup-order-id {
    overflow-wrap: anywhere;
    word-break: break-word;
}

@media (max-width: 640px) {
    .topup-history-wrap {
        padding: 10px !important;
        overflow: visible !important;
    }

    .topup-history-table,
    .topup-history-table tbody {
        display: block !important;
        width: 100% !important;
        min-width: 0 !important;
    }

    .topup-history-table thead {
        display: none !important;
    }

    .topup-history-table tbody tr {
        display: block !important;
        width: 100% !important;
        min-width: 0 !important;
        box-sizing: border-box;
        margin: 0 0 12px;
        padding: 8px 12px;
        border: 1px solid var(--border, #293449);
        border-radius: 12px;
        background: var(--panel, #111827);
        overflow: hidden;
    }

    .topup-history-table tbody td {
        display: grid !important;
        grid-template-columns: minmax(88px, 34%) minmax(0, 1fr);
        align-items: start;
        gap: 8px;
        width: 100% !important;
        min-width: 0 !important;
        box-sizing: border-box;
        padding: 10px 0 !important;
        border: 0 !important;
        border-bottom: 1px solid var(--border, #293449) !important;
        white-space: normal !important;
        overflow-wrap: anywhere;
    }

    .topup-history-table tbody td:last-child {
        border-bottom: 0 !important;
    }

    .topup-history-table tbody td::before {
        content: attr(data-label);
        display: block;
        min-width: 0;
        color: var(--muted, #94a3b8);
        font-size: 11px;
        font-weight: 700;
        line-height: 1.5;
    }

    .topup-history-table .topup-order-id b {
        overflow-wrap: anywhere;
        word-break: break-all;
    }

    .topup-history-table .topup-amount {
        font-weight: 700;
    }

    .topup-history-table .topup-proof form {
        min-width: 0;
        width: 100%;
    }

    .topup-history-table .topup-proof input,
    .topup-history-table .topup-proof button,
    .topup-history-table .topup-proof select {
        width: 100%;
        max-width: 100%;
        min-width: 0;
        box-sizing: border-box;
    }

    .topup-history-table .topup-proof input[type="file"] {
        font-size: 12px;
    }

    .topup-history-table .topup-status .status {
        display: inline-block;
        max-width: 100%;
        overflow-wrap: anywhere;
    }
}

/* FIX-TOPUP-LIGHT-MODE-20261030 */
html[data-theme="light"] .topup-history-wrap,
html[data-theme="light"] .topup-history-table {
    background: #ffffff !important;
    color: #1e293b !important;
    border-color: #e2e8f0 !important;
}

html[data-theme="light"] .topup-history-table thead,
html[data-theme="light"] .topup-history-table tbody tr,
html[data-theme="light"] .topup-history-table tbody td {
    background-color: #ffffff !important;
    color: #1e293b !important;
    border-color: #e2e8f0 !important;
}

html[data-theme="light"] .topup-history-table th,
html[data-theme="light"] .topup-history-table td,
html[data-theme="light"] .topup-history-table td b,
html[data-theme="light"] .topup-history-table .topup-order-id,
html[data-theme="light"] .topup-history-table .topup-proof,
html[data-theme="light"] .topup-history-table .topup-rejection {
    color: #334155 !important;
}

html[data-theme="light"] .topup-history-table tbody td::before {
    color: #64748b !important;
}

html[data-theme="light"] .topup-history-table .topup-status .status {
    color: #166534 !important;
    background-color: #dcfce7 !important;
    border-color: #bbf7d0 !important;
}

html[data-theme="light"] .topup-history-table input,
html[data-theme="light"] .topup-history-table select {
    background-color: #ffffff !important;
    color: #1e293b !important;
    border-color: #cbd5e1 !important;
}
/* END FIX-TOPUP-LIGHT-MODE-20261030 */

</style>

@endsection



<style id="topup-status-colors-fix">
.topup-history-table .topup-status .status.pending,
html[data-theme="light"] .topup-history-table .topup-status .status.pending {
    color: #9a3412 !important;
    background-color: #ffedd5 !important;
    border: 1px solid #fdba74 !important;
}

.topup-history-table .topup-status .status.paid,
html[data-theme="light"] .topup-history-table .topup-status .status.paid {
    color: #166534 !important;
    background-color: #dcfce7 !important;
    border: 1px solid #bbf7d0 !important;
}

.topup-history-table .topup-status .status.expired,
.topup-history-table .topup-status .status.failed,
html[data-theme="light"] .topup-history-table .topup-status .status.expired,
html[data-theme="light"] .topup-history-table .topup-status .status.failed {
    color: #991b1b !important;
    background-color: #fee2e2 !important;
    border: 1px solid #fca5a5 !important;
}
</style>
