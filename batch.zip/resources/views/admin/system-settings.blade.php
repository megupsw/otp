@extends('layouts.app')

@section('title', 'Pengaturan Sistem')

@section('content')
<div class="page-heading">
    <div>
        <h1>Pengaturan Sistem</h1>
        <p>Ringkasan domain, koneksi provider, dan URL callback Digistore OTP.</p>
    </div>
</div>

<div class="card">
    <h3>Domain Website</h3>
    <div class="form-group">
        <label>APP_URL aktif</label>
        <input type="text" value="{{ $appUrl }}" readonly>
        <small class="muted">Nilai ini berasal dari konfigurasi Laravel. Mengubahnya saja tidak mengubah DNS atau sertifikat SSL.</small>
    </div>
</div>

<div class="card" style="margin-top:18px">
    <h3>Provider SIMURU</h3>
    <div class="form-group">
        <label>Base URL API</label>
        <input type="text" value="{{ $simuruUrl }}" readonly>
    </div>
    <p>Status API key: <strong>{{ $simuruConfigured ? 'Sudah diatur' : 'Belum diatur' }}</strong></p>
</div>

<div class="card" style="margin-top:18px">
    <h3>PayHook</h3>
    <p>Token: <strong>{{ $payhookTokenConfigured ? 'Sudah diatur' : 'Belum diatur' }}</strong></p>
    <p>Secret: <strong>{{ $payhookSecretConfigured ? 'Sudah diatur' : 'Belum diatur' }}</strong></p>
    <div class="form-group">
        <label>URL callback yang terdaftar di aplikasi</label>
        <input type="text" value="{{ $payhookCallback }}" readonly>
    </div>
</div>

<div class="card" style="margin-top:18px">
    <h3>Midtrans</h3>
    <div class="form-group">
        <label>Base URL</label>
        <input type="text" value="{{ $midtransUrl }}" readonly>
    </div>
    <p>Server key: <strong>{{ $midtransServerKeyConfigured ? 'Sudah diatur' : 'Belum diatur' }}</strong></p>
    <p>Client key: <strong>{{ $midtransClientKeyConfigured ? 'Sudah diatur' : 'Belum diatur' }}</strong></p>
    <p>Mode: <strong>{{ $midtransProduction ? 'Production' : 'Sandbox / non-production' }}</strong></p>
    <div class="form-group">
        <label>URL notifikasi Midtrans</label>
        <input type="text" value="{{ $midtransCallback }}" readonly>
    </div>
</div>

<div class="card" style="margin-top:18px">
    <h3>Catatan Keamanan</h3>
    <p class="muted">Halaman ini hanya menampilkan konfigurasi yang aktif. Tidak ada API key, token, atau secret yang ditampilkan. Pengubahan konfigurasi provider belum diaktifkan agar transaksi dan callback yang sedang berjalan tidak terganggu.</p>
</div>
@endsection
