<?php

namespace App\Console\Commands;

use App\Models\Topup;
use Illuminate\Console\Command;

class ExpirePendingTopups extends Command
{
    protected $signature = 'topup:expire-pending';

    protected $description = 'Tandai top up otomatis yang sudah melewati batas pembayaran sebagai expired';

    public function handle(): int
    {
        $count = Topup::query()
            ->where('status', 'pending')
            ->whereIn('payment_type', [
                'payhook_gopay',
                'payhook_shopeepay',
            ])
            ->whereNotNull('expired_at')
            ->where('expired_at', '<=', now())
            ->update(['status' => 'expired']);

        $this->info("Top up kedaluwarsa: {$count}");

        return self::SUCCESS;
    }
}
