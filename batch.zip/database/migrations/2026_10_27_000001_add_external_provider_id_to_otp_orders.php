<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('otp_orders', function (Blueprint $table) {
            $table->string('external_provider_order_id')
                ->nullable()
                ->index();
        });
    }

    public function down(): void
    {
        Schema::table('otp_orders', function (Blueprint $table) {
            $table->dropIndex(['external_provider_order_id']);
            $table->dropColumn('external_provider_order_id');
        });
    }
};
