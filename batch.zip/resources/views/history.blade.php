@extends('layouts.app')
@section('title','Riwayat')@section('crumb','ACTIVITY')@section('heading','Riwayat Transaksi')
@section('content')
<div class="section-head"><div><h2>Riwayat order OTP</h2><p class="muted">Daftar transaksi nomor dan layanan.</p></div></div><div class="panel table-wrap"><table><thead><tr><th>Layanan</th><th>Negara</th><th>Nomor</th><th>Harga</th><th>Status</th><th>Tanggal</th></tr></thead><tbody>@forelse($orders as $o)<tr><td>{{ $o->service_name }}</td><td>{{ $o->country_name }}</td><td>{{ $o->phone_number ?? '—' }}</td><td>{{ rupiah($o->selling_price) }}</td><td><span class="status {{ $o->status }}">{{ $o->status }}</span></td><td>{{ $o->created_at->format('d/m/y H:i') }}</td></tr>@empty<tr><td colspan="6" class="empty">Belum ada order.</td></tr>@endforelse</tbody></table></div>{{ $orders->onEachSide(1)->links() }}
<div class="section-head"><div><h2>Riwayat top up</h2><p class="muted">Transaksi saldo masuk</p></div></div><div class="panel table-wrap"><table><thead><tr><th>ID pembayaran</th><th>Nominal</th><th>Status</th><th>Tanggal</th></tr></thead><tbody>@forelse($topups as $t)<tr><td>{{ $t->order_id }}</td><td>{{ rupiah($t->amount) }}</td><td><span class="status {{ $t->status }}">{{ $t->status }}</span></td><td>{{ $t->created_at->format('d/m/y H:i') }}</td></tr>@empty<tr><td colspan="4" class="empty">Belum ada top up.</td></tr>@endforelse</tbody></table></div>{{ $topups->onEachSide(1)->links() }}

<div class="section-head">
    <div>
        <h2>Riwayat Perubahan Saldo</h2>
        <p class="muted">Top up admin, refund, dan transaksi saldo lainnya.</p>
    </div>
</div>
<div class="panel table-wrap">
    <table>
        <thead>
            <tr>
                <th>Jenis Transaksi</th>
                <th>Nominal</th>
                <th>Keterangan</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
        @forelse($walletTransactions as $transaction)
            <tr>
                <td>
                    @switch($transaction->type)
                        @case('admin_credit')
                            Top Up Admin
                            @break
                        @case('refund')
                            Refund Saldo
                            @break
                        @case('credit')
                            Top Up
                            @break
                        @case('admin_debit')
                            Pengurangan Saldo
                            @break
                        @default
                            {{ ucwords(str_replace('_', ' ', $transaction->type)) }}
                    @endswitch
                </td>
                <td>
                    <span style="color:{{ in_array($transaction->type, ['admin_debit'], true) ? '#f87171' : '#34d399' }};font-weight:700">
                        {{ in_array($transaction->type, ['admin_debit'], true) ? '−' : '+' }}{{ rupiah($transaction->amount) }}
                    </span>
                </td>
                <td>{{ $transaction->description ?: '—' }}</td>
                <td>{{ $transaction->created_at?->format('d/m/Y H:i') ?? '—' }}</td>
            </tr>
        @empty
            <tr><td colspan="4" class="empty">Belum ada riwayat perubahan saldo.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
<div>{{ $walletTransactions->onEachSide(1)->links() }}</div>

@endsection
