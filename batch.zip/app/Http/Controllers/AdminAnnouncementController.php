<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminAnnouncementController extends Controller
{
    public function index()
    {
        return view('admin.announcements.index', [
            'announcements' => Announcement::with('users')->latest()->paginate(15),
        ]);
    }

    public function searchUsers(Request $request)
    {
        $validated = $request->validate([
            'q' => 'required|string|min:2|max:100',
        ]);

        $keyword = trim($validated['q']);

        $users = User::query()
            ->where('role', '!=', 'admin')
            ->where(function ($query) use ($keyword) {
                $query->where('name', 'like', '%' . $keyword . '%')
                    ->orWhere('email', 'like', '%' . $keyword . '%');
            })
            ->orderBy('name')
            ->limit(20)
            ->get(['id', 'name', 'email']);

        return response()->json([
            'users' => $users,
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);

        DB::transaction(function () use ($data) {
            $userIds = $data['user_ids'] ?? [];
            unset($data['user_ids']);

            $announcement = Announcement::create($data);

            if ($announcement->target_type === 'selected') {
                $announcement->users()->sync($userIds);
            }
        });

        return back()->with('success', 'Pengumuman berhasil dibuat.');
    }

    public function update(Request $request, Announcement $announcement)
    {
        $data = $this->validated($request);

        DB::transaction(function () use ($data, $announcement) {
            $userIds = $data['user_ids'] ?? [];
            unset($data['user_ids']);

            $announcement->update($data);

            if ($announcement->target_type === 'selected') {
                $announcement->users()->sync($userIds);
            } else {
                $announcement->users()->detach();
            }
        });

        return back()->with('success', 'Pengumuman berhasil diperbarui.');
    }

    public function destroy(Announcement $announcement)
    {
        $announcement->delete();

        return back()->with('success', 'Pengumuman berhasil dihapus.');
    }

    public function toggle(Announcement $announcement)
    {
        $announcement->update(['is_active' => !$announcement->is_active]);

        return back()->with('success', 'Status pengumuman berhasil diubah.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'title' => 'required|string|max:150',
            'message' => 'required|string|max:5000',
            'type' => 'required|in:info,success,warning,danger',
            'target_type' => 'required|in:all,selected',
            'is_active' => 'nullable|boolean',
            'starts_at' => 'nullable|date',
            'ends_at' => 'nullable|date|after_or_equal:starts_at',
            'user_ids' => 'required_if:target_type,selected|array',
            'user_ids.*' => 'integer|exists:users,id',
        ]);
    }
}
