(() => {
    if (window.__digistoreAjaxReady) return;
    window.__digistoreAjaxReady = true;

    const loader = document.createElement('div');
    loader.className = 'ajax-loading-indicator';
    loader.innerHTML = '<span class="ajax-loader-bar"></span><span class="ajax-loader-spinner"></span>';
    document.body.appendChild(loader);

    const mainSelector = 'main.main';
    let navigating = false;

    function getMain(html) {
        const doc = new DOMParser().parseFromString(html, 'text/html');
        return doc.querySelector(mainSelector);
    }

    function updatePage(html, url, push = true) {
        const nextMain = getMain(html);
        const currentMain = document.querySelector(mainSelector);

        if (!nextMain || !currentMain) {
            window.location.href = url;
            return;
        }

        currentMain.classList.add('ajax-page-leaving');

        requestAnimationFrame(() => {
            // Perbarui judul dan isi halaman
            const nextTitle = new DOMParser()
                .parseFromString(html, 'text/html').querySelector('title');

            if (nextTitle) document.title = nextTitle.textContent;

            currentMain.innerHTML = nextMain.innerHTML;
            currentMain.classList.remove('ajax-page-leaving');
            currentMain.classList.add('ajax-page-entering');

            // Perbarui status navigasi sidebar
            const nextDoc = new DOMParser().parseFromString(html, 'text/html');
            const nextSidebar = nextDoc.querySelector('.sidebar nav');
            const sidebar = document.querySelector('.sidebar nav');

            if (nextSidebar && sidebar) {
                sidebar.innerHTML = nextSidebar.innerHTML;
            }

            // Perbarui navigasi bawah
            const nextBottom = nextDoc.querySelector('#userBottomNav');
            const bottom = document.querySelector('#userBottomNav');

            if (nextBottom && bottom) {
                bottom.innerHTML = nextBottom.innerHTML;
            }

            if (push) history.pushState({ ajax: true }, '', url);

            document.body.classList.remove('nav-open');
            window.scrollTo({ top: 0, behavior: 'instant' });

            // Jalankan ulang script inline dari halaman baru
            currentMain.querySelectorAll('script').forEach(oldScript => {
                const script = document.createElement('script');

                for (const attr of oldScript.attributes) {
                    script.setAttribute(attr.name, attr.value);
                }

                script.textContent = oldScript.textContent;
                oldScript.replaceWith(script);
            });

            // Beri sinyal untuk inisialisasi fitur halaman
            document.dispatchEvent(new CustomEvent('digistore:page-loaded', {
                detail: { url }
            }));

            setTimeout(() => {
                currentMain.classList.remove('ajax-page-entering');
            }, 350);

        });
    }

    async function navigate(url, push = true) {
        if (navigating) return;

        navigating = true;
        document.body.classList.add('ajax-loading');
        loader.classList.add('is-active');

        try {
            const response = await fetch(url, {
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'text/html'
                }
            });

            if (!response.ok) {
                console.warn('[Digistore AJAX] HTTP gagal:', response.status, url);
                throw new Error('HTTP ' + response.status);
            }

            const contentType = response.headers.get('content-type') || '';
            const html = await response.text();

            if (!contentType.includes('text/html')) {
                console.warn('[Digistore AJAX] Bukan HTML:', contentType, response.url);
                throw new Error('Response bukan HTML');
            }

            if (!getMain(html)) {
                console.warn('[Digistore AJAX] Elemen main tidak ditemukan:', response.url);
                console.warn('[Digistore AJAX] Isi awal response:', html.slice(0, 500));
                throw new Error('Konten halaman tidak ditemukan');
            }

            if (response.redirected) {
                console.warn('[Digistore AJAX] Redirect terdeteksi:', response.url);
            }

            updatePage(html, url, push);
        } catch (error) {
            console.error('[Digistore AJAX] Navigasi gagal:', url, error);
            window.location.href = url;
        } finally {
            setTimeout(() => {
                navigating = false;
                document.body.classList.remove('ajax-loading');
                loader.classList.remove('is-active');
            }, 250);
        }
    }

    // Navigasi link internal dengan GET saja
    document.addEventListener('click', event => {
        const link = event.target.closest('a[href]');
        if (!link) return;

        if (
            event.defaultPrevented ||
            event.button !== 0 ||
            event.ctrlKey ||
            event.metaKey ||
            event.shiftKey ||
            event.altKey ||
            link.target === '_blank' ||
            link.hasAttribute('download') ||
            link.getAttribute('href')?.startsWith('#')
        ) return;

        const url = new URL(link.href, window.location.href);

        if (
            url.origin !== window.location.origin ||
            url.pathname === window.location.pathname && url.search === window.location.search
        ) return;

        event.preventDefault();
        navigate(url.href);
    });

    // Tombol Back dan Forward browser
    window.addEventListener('popstate', () => {
        navigate(window.location.href, false);
    });

    history.replaceState({ ajax: true }, '', window.location.href);
})();
