@extends('layouts.app')
@section('title', 'Inbox OTP')
@section('crumb', 'INBOX OTP')
@section('heading', 'Inbox OTP')

@section('content')
<div class="page-intro">
    <div>
        <h2>Riwayat OTP</h2>
        <p class="muted">OTP yang sudah kedaluwarsa, selesai, atau dibatalkan tersimpan di sini.</p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn secondary" href="{{ route('otp') }}">OTP Aktif</a>
        <a class="btn primary" href="{{ route('order') }}">＋ Order baru</a>
    </div>
</div>

<div class="otp-grid">
@forelse($orders as $o)
    @php
        $expiredAt = data_get($o->provider_payload, 'expired_at');
        $timeExpired = false;
        if ($expiredAt) {
            try {
                $timeExpired = \Illuminate\Support\Carbon::parse($expiredAt)->isPast();
            } catch (\Throwable $e) {
                $timeExpired = false;
            }
        }
        $displayStatus = $timeExpired && in_array(strtolower((string)$o->status), ['active','pending'], true)
            ? 'expired'
            : strtolower((string)$o->status);
    @endphp

    <div class="panel otp-card">
        <div class="otp-card-top">
            <span class="service-logo">{{ strtoupper(substr($o->service_name, 0, 1)) }}</span>
            <span class="status {{ $displayStatus }}">{{ $displayStatus }}</span>
        </div>

        <h3>{{ $o->service_name }}</h3>
        <p class="muted">{{ $o->country_name }}</p>
        <div class="phone-number">{{ $o->phone_number ?? 'Nomor tidak tersedia' }}</div>

        <div class="otp-details">
            <div><small>Harga</small><b>{{ rupiah($o->selling_price) }}</b></div>
            <div><small>ID Order</small><b>#{{ $o->id }}</b></div>
        </div>

        <div class="code-box">
            <small>KODE OTP</small>
            <strong>{{ $o->sms_code ?: 'Tidak ada kode OTP' }}</strong>
            @if($o->sms_code)
                <button class="icon-btn" type="button"
                    onclick="navigator.clipboard.writeText(@js($o->sms_code))"
                    title="Salin kode OTP">⧉</button>
            @endif
        </div>

        @if(is_array($o->sms_data) && count($o->sms_data))
            <div class="sms-data">
                @foreach($o->sms_data as $sms)
                    <p>{{ is_array($sms) ? ($sms['text'] ?? json_encode($sms)) : $sms }}</p>
                @endforeach
            </div>
        @else
            <p class="muted">Tidak ada isi SMS yang tersimpan.</p>
        @endif

        <p class="muted" style="font-size:12px">
            Dibuat: {{ $o->created_at?->format('d-m-Y H:i') ?? '—' }}
        </p>
    </div>
@empty
    <div class="panel empty-panel">
        <div class="empty-symbol">▤</div>
        <h3>Inbox masih kosong</h3>
        <p class="muted">OTP yang kedaluwarsa atau selesai akan tampil di sini.</p>
        <a class="btn primary" href="{{ route('otp') }}">Lihat OTP aktif</a>
    </div>
@endforelse
</div>

@if ($orders->lastPage() > 1)
    <nav class="inbox-pagination" aria-label="Navigasi halaman Inbox OTP">
        <div class="inbox-pagination-info">
            Halaman <strong>{{ $orders->currentPage() }}</strong>
            dari <strong>{{ $orders->lastPage() }}</strong>
            <span>· Maksimal 5 order per halaman</span>
        </div>

        <div class="inbox-pagination-controls">
            @if ($orders->onFirstPage())
                <span class="inbox-page-btn is-disabled" aria-disabled="true">‹ Sebelumnya</span>
            @else
                <a class="inbox-page-btn" href="{{ $orders->previousPageUrl() }}">‹ Sebelumnya</a>
            @endif

            @for ($page = 1; $page <= $orders->lastPage(); $page++)
                @if ($page === $orders->currentPage())
                    <span class="inbox-page-number is-current" aria-current="page">{{ $page }}</span>
                @else
                    <a class="inbox-page-number" href="{{ $orders->url($page) }}">{{ $page }}</a>
                @endif
            @endfor

            @if ($orders->hasMorePages())
                <a class="inbox-page-btn" href="{{ $orders->nextPageUrl() }}">Berikutnya ›</a>
            @else
                <span class="inbox-page-btn is-disabled" aria-disabled="true">Berikutnya ›</span>
            @endif
        </div>
    </nav>
@endif
@endsection
