<?php

namespace App\Console\Commands;

use App\Models\OtpOrder;
use App\Services\SimuruClient;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class FinalizeExpiredOtpOrders extends Command
{
    protected $signature = 'otp:finalize-expired';
    protected $description = 'Selesaikan order OTP kedaluwarsa dan sinkronkan dengan SIMURU';

    public function handle(SimuruClient $api): int
    {
        $orders = OtpOrder::query()
            ->whereIn('status', ['active', 'pending'])
            ->get();

        $completed = 0;
        $expired = 0;
        $failed = 0;

        foreach ($orders as $order) {
            // Order simulasi tidak dikirim ke SIMURU.
            // Tangani OTP simulasi secara lokal, tanpa memanggil SIMURU.
if (str_starts_with((string) $order->provider_order_id, 'TEST-')) {
    $simulationExpiredAt = $order->created_at
        ? $order->created_at->copy()->addSeconds(600)
        : null;

    if (!$simulationExpiredAt || !$simulationExpiredAt->isPast()) {
        continue;
    }

    $hasCode = preg_match(
        '/^\d{4,8}$/',
        trim((string) $order->sms_code)
    ) === 1;

    $order->update([
        'status' => $hasCode ? 'completed' : 'expired',
        'remaining_seconds' => 0,
    ]);

    if ($hasCode) {
        $completed++;
    } else {
        $expired++;
    }

    continue;
}

            $expiredAt = data_get($order->provider_payload, 'expired_at');

            if (!$expiredAt) {
                continue;
            }

            try {
                if (!Carbon::parse($expiredAt)->isPast()) {
                    continue;
                }
            } catch (\Throwable $e) {
                continue;
            }

            $hasCode = preg_match(
                '/^\d{4,8}$/',
                trim((string) $order->sms_code)
            ) === 1;

            if (!$hasCode) {
                $order->update(['status' => 'expired']);
                $expired++;
                continue;
            }

            try {
                $result = $api->finish((int) $order->provider_order_id);

                if (($result['success'] ?? false) !== true) {
                    throw new \RuntimeException(
                        $result['message'] ?? 'SIMURU belum mengonfirmasi penyelesaian order.'
                    );
                }
            } catch (\Throwable $e) {
                $failed++;

                Log::warning('Finish SIMURU gagal; status lokal tetap dipaksa completed karena OTP valid dan waktu habis', [
                    'order_id' => $order->id,
                    'provider_order_id' => $order->provider_order_id,
                    'error' => $e->getMessage(),
                ]);
            }

            // OTP valid sudah diterima dan waktu habis.
            // Status lokal tetap completed meskipun SIMURU gagal merespons.
            $order->update(['status' => 'completed']);
            $completed++;
        }

        $this->info("Completed: {$completed}");
        $this->info("Expired tanpa OTP: {$expired}");
        $this->info("Gagal diselesaikan di SIMURU: {$failed}");

        return self::SUCCESS;
    }
}
